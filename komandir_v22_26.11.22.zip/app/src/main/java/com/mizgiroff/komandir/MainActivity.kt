package com.mizgiroff.komandir

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.provider.OpenableColumns
import android.content.ClipData
import android.content.ClipboardManager
import android.widget.Toast
import android.widget.VideoView
import androidx.core.view.WindowInsetsControllerCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowCompat
import android.widget.FrameLayout
import android.view.ViewGroup
import android.view.Gravity
import android.app.Activity
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.pdf.PdfRenderer
import android.media.MediaPlayer
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Info
import android.media.ExifInterface
import android.os.ParcelFileDescriptor
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.filled.Audiotrack
import androidx.compose.material.icons.filled.Save
import androidx.compose.ui.text.font.FontFamily
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.border
import androidx.compose.foundation.Image
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.Computer
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.CreateNewFolder
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DriveFileMove
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.InsertDriveFile
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ViewColumn
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material.icons.filled.Check
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.layout.offset
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.unit.IntOffset
import kotlin.math.roundToInt
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class MainActivity : ComponentActivity() {
    private val oauthCodeState = mutableStateOf<String?>(null)
    private val liveViewState = mutableStateOf<Pair<Uri, String?>?>(null)
    private val liveShareState = mutableStateOf<List<Uri>>(emptyList())

    private fun extractIncomingIntent(intent: Intent?) {
        if (intent == null) return
        val data = intent.data
        if (data?.scheme == "com.mizgiroff.komandir" && data.path == "/oauth2redirect") {
            oauthCodeState.value = data.getQueryParameter("code")
            return
        }
        when (intent.action) {
            Intent.ACTION_VIEW -> {
                if (data != null) liveViewState.value = data to intent.type
            }
            Intent.ACTION_SEND -> {
                @Suppress("DEPRECATION")
                val u = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    intent.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
                } else {
                    intent.getParcelableExtra(Intent.EXTRA_STREAM)
                }
                if (u != null) liveShareState.value = listOf(u)
            }
            Intent.ACTION_SEND_MULTIPLE -> {
                @Suppress("DEPRECATION")
                val list = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    intent.getParcelableArrayListExtra(Intent.EXTRA_STREAM, Uri::class.java)
                } else {
                    intent.getParcelableArrayListExtra(Intent.EXTRA_STREAM)
                }
                if (!list.isNullOrEmpty()) liveShareState.value = list
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        extractIncomingIntent(intent)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val isPickMode = intent?.action in listOf(
            Intent.ACTION_GET_CONTENT,
            Intent.ACTION_OPEN_DOCUMENT,
            Intent.ACTION_PICK
        )
        val viewUri = if (intent?.action == Intent.ACTION_VIEW) intent?.data else null
        val viewMime = if (intent?.action == Intent.ACTION_VIEW) intent?.type else null
        extractIncomingIntent(intent)
        setContent {
            KomandirApp(
                isPickMode = isPickMode,
                initialViewUri = viewUri,
                initialViewMime = viewMime,
                liveViewEvent = liveViewState.value,
                onLiveViewHandled = { liveViewState.value = null },
                incomingShareUris = liveShareState.value,
                onShareHandled = { liveShareState.value = emptyList() },
                oauthCode = oauthCodeState.value,
                onOAuthHandled = { oauthCodeState.value = null },
                onPickFile = { file ->
                    val uri = FileProvider.getUriForFile(
                        this,
                        "${packageName}.fileprovider",
                        file
                    )
                    val res = Intent().apply {
                        data = uri
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    setResult(RESULT_OK, res)
                    finish()
                },
                onCancelPick = {
                    setResult(RESULT_CANCELED)
                    finish()
                }
            )
        }
    }
}

private val BrandBlue = Color(0xFF0057B7)
private fun Modifier.paperTexture(enabled: Boolean): Modifier = if (!enabled) this else this.drawBehind {
    drawRect(
        brush = Brush.verticalGradient(
            colors = listOf(
                Color(0xFFF8EED1),
                Color(0xFFF3E7C4),
                Color(0xFFEDE0B8)
            )
        )
    )
    val step = 28f
    var seed = 1337
    var y = 0f
    while (y < size.height) {
        var x = 0f
        while (x < size.width) {
            seed = (seed * 1103515245 + 12345) and 0x7fffffff
            val ox = (seed % 23).toFloat()
            seed = (seed * 1103515245 + 12345) and 0x7fffffff
            val oy = (seed % 23).toFloat()
            val dotColor = if ((seed and 1) == 0) Color(0x168A6E36) else Color(0x18FFFFFF)
            drawCircle(color = dotColor, radius = 1.2f, center = Offset(x + ox, y + oy))
            if ((seed % 5) == 0) {
                drawLine(
                    color = Color(0x118A6E36),
                    start = Offset(x + ox, y + oy),
                    end = Offset((x + ox + 14f).coerceAtMost(size.width), y + oy + 1.5f),
                    strokeWidth = 0.8f
                )
            }
            x += step
        }
        y += step
    }
}

private val BrandYellow = Color(0xFFFFDD00)

@Composable
fun KomandirApp(
    isPickMode: Boolean = false,
    initialViewUri: Uri? = null,
    initialViewMime: String? = null,
    liveViewEvent: Pair<Uri, String?>? = null,
    onLiveViewHandled: () -> Unit = {},
    incomingShareUris: List<Uri> = emptyList(),
    onShareHandled: () -> Unit = {},
    oauthCode: String? = null,
    onOAuthHandled: () -> Unit = {},
    onPickFile: (File) -> Unit = {},
    onCancelPick: () -> Unit = {}
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var themeMode by remember { mutableStateOf(KomandirPrefs.getTheme(context)) }
    var appLang by remember { mutableStateOf(KomandirPrefs.getLang(context)) }
    var showLangPrompt by remember { mutableStateOf(!KomandirPrefs.isLangChosen(context)) }
    var showDefaultPrompt by remember { mutableStateOf(!KomandirPrefs.isDefaultPromptShown(context)) }

    val isDark = when (themeMode) {
        AppThemeMode.DARK -> true
        AppThemeMode.LIGHT -> false
        AppThemeMode.SYSTEM -> isSystemInDarkTheme()
    }

    val colorScheme = if (isDark) {
        darkColorScheme(
            primary = Color(0xFF7C83FD),
            background = Color(0xFF121216),
            surface = Color(0xFF1C1C22),
            surfaceVariant = Color(0xFF26262E)
        )
    } else {
        lightColorScheme(
            primary = BrandBlue,
            background = Color(0xFFF3E7C4),
            surface = Color(0xFFF8EED1),
            surfaceVariant = Color(0xFFE9DAB0),
            onBackground = Color(0xFF2B2214),
            onSurface = Color(0xFF2B2214),
            onSurfaceVariant = Color(0xFF5A4B32),
            outlineVariant = Color(0xFFD5C496)
        )
    }

    MaterialTheme(colorScheme = colorScheme) {
        val t = remember(appLang) { stringsFor(appLang) }
        val (appVerCode, appVerName) = remember {
            runCatching {
                val pInfo = context.packageManager.getPackageInfo(context.packageName, 0)
                val code = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) pInfo.longVersionCode.toInt() else @Suppress("DEPRECATION") pInfo.versionCode
                val name = pInfo.versionName ?: "22_26.11.22"
                code to name
            }.getOrDefault(12 to "16_26.11.22")
        }

        var customStorages by remember { mutableStateOf(KomandirPrefs.getCustomStorages(context)) }
        val builtInStorages = remember(appLang) {
            val phoneRoot = Environment.getExternalStorageDirectory().absolutePath
            listOf(
                StorageSource("phone", t.phoneName, StorageKind.LOCAL, phoneRoot)
            )
        }
        val allStorages = builtInStorages + customStorages

        var dualPane by remember { mutableStateOf(false) }
        var activePane by remember { mutableIntStateOf(0) }

        var leftStorageId by remember { mutableStateOf("phone") }
        var rightStorageId by remember { mutableStateOf("phone") }

        var leftPath by remember { mutableStateOf(Environment.getExternalStorageDirectory().absolutePath) }
        var rightPath by remember { mutableStateOf(Environment.getExternalStorageDirectory().absolutePath) }

        var leftSelected by remember { mutableStateOf(setOf<String>()) }
        var rightSelected by remember { mutableStateOf(setOf<String>()) }
        var leftEntries by remember { mutableStateOf<List<FileEntry>>(emptyList()) }
        var rightEntries by remember { mutableStateOf<List<FileEntry>>(emptyList()) }

        var searchOpen by remember { mutableStateOf(false) }
        var searchQuery by remember { mutableStateOf("") }

        var showVersionDialog by remember { mutableStateOf(false) }
        var showSettingsDialog by remember { mutableStateOf(false) }
        var showAddStorageDialog by remember { mutableStateOf(false) }
        var showNewFolderDialog by remember { mutableStateOf(false) }
        var showRenameDialog by remember { mutableStateOf<FileEntry?>(null) }
        var showCreateZipDialog by remember { mutableStateOf(false) }
        var viewerImageFile by remember { mutableStateOf<File?>(null) }
        var viewerImageGallery by remember { mutableStateOf<List<File>>(emptyList()) }
        var viewerExternalUri by remember {
            mutableStateOf<Uri?>(
                if (initialViewUri != null && (initialViewMime?.startsWith("image/") == true || isImageFileName(initialViewUri.toString()))) initialViewUri else null
            )
        }
        var viewerVideoFile by remember { mutableStateOf<File?>(null) }
        var viewerVideoGallery by remember { mutableStateOf<List<File>>(emptyList()) }
        var viewerExternalVideoUri by remember {
            mutableStateOf<Uri?>(
                if (initialViewUri != null && (initialViewMime?.startsWith("video/") == true || isVideoFileName(initialViewUri.toString()))) initialViewUri else null
            )
        }
        var viewerPdfFile by remember { mutableStateOf<File?>(null) }
        var viewerExternalPdfUri by remember {
            mutableStateOf<Uri?>(
                if (initialViewUri != null && (initialViewMime == "application/pdf" || isPdfFileName(initialViewUri.toString()))) initialViewUri else null
            )
        }
        var viewerAudioFile by remember { mutableStateOf<File?>(null) }
        var viewerAudioGallery by remember { mutableStateOf<List<File>>(emptyList()) }
        var viewerExternalAudioUri by remember {
            mutableStateOf<Uri?>(
                if (initialViewUri != null && (initialViewMime?.startsWith("audio/") == true || isAudioFileName(initialViewUri.toString()))) initialViewUri else null
            )
        }
        var viewerTextFile by remember { mutableStateOf<File?>(null) }
        var viewerHexFile by remember { mutableStateOf<File?>(null) }
        var viewerExternalTextUri by remember {
            mutableStateOf<Uri?>(
                if (initialViewUri != null && (initialViewMime == "text/plain" || isTextFileName(initialViewUri.toString()))) initialViewUri else null
            )
        }
        var viewerHtmlFile by remember { mutableStateOf<File?>(null) }
        var viewerExternalHtmlUri by remember {
            mutableStateOf<Uri?>(
                if (initialViewUri != null && (initialViewMime == "text/html" || initialViewMime == "image/svg+xml" || isHtmlOrSvgFileName(initialViewUri.toString()))) initialViewUri else null
            )
        }

        LaunchedEffect(liveViewEvent) {
            val ev = liveViewEvent ?: return@LaunchedEffect
            val u = ev.first
            val m = ev.second
            val s = u.toString()
            when {
                m?.startsWith("image/") == true || isImageFileName(s) -> viewerExternalUri = u
                m?.startsWith("video/") == true || isVideoFileName(s) -> viewerExternalVideoUri = u
                m?.startsWith("audio/") == true || isAudioFileName(s) -> viewerExternalAudioUri = u
                m == "application/pdf" || isPdfFileName(s) -> viewerExternalPdfUri = u
                m == "text/html" || m == "image/svg+xml" || isHtmlOrSvgFileName(s) -> viewerExternalHtmlUri = u
                m == "text/plain" || isTextFileName(s) -> viewerExternalTextUri = u
                m?.contains("zip") == true || isZipFileName(s) -> zipViewerUri = u
            }
            onLiveViewHandled()
        }
        var zipViewerFile by remember { mutableStateOf<File?>(null) }
        var zipViewerUri by remember {
            mutableStateOf<Uri?>(
                if (initialViewUri != null && (initialViewMime?.contains("zip") == true || initialViewUri.toString().lowercase().endsWith(".zip"))) initialViewUri else null
            )
        }

        var refreshTick by remember { mutableIntStateOf(0) }
        var hasPermissionState by remember { mutableStateOf(false) }

        var leftPaneBounds by remember { mutableStateOf<Rect?>(null) }
        var rightPaneBounds by remember { mutableStateOf<Rect?>(null) }
        var draggingFromPane by remember { mutableStateOf<Int?>(null) }
        var draggingItems by remember { mutableStateOf<List<FileEntry>>(emptyList()) }
        var dragPointerRoot by remember { mutableStateOf(Offset.Zero) }
        var pendingDrop by remember { mutableStateOf<Triple<Int, Int, List<FileEntry>>?>(null) }

        fun hasStoragePermission(): Boolean {
            return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                Environment.isExternalStorageManager()
            } else {
                ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.READ_EXTERNAL_STORAGE
                ) == PackageManager.PERMISSION_GRANTED
            }
        }

        val lifecycleOwner = LocalLifecycleOwner.current
        DisposableEffect(lifecycleOwner) {
            hasPermissionState = hasStoragePermission()
            val observer = LifecycleEventObserver { _, event ->
                if (event == Lifecycle.Event.ON_RESUME) {
                    hasPermissionState = hasStoragePermission()
                    refreshTick++
                }
            }
            lifecycleOwner.lifecycle.addObserver(observer)
            onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
        }

        fun performTransfer(
            srcSource: StorageSource,
            dstSource: StorageSource,
            srcPath: String,
            dstPath: String,
            items: List<FileEntry>,
            isMove: Boolean,
            srcPaneIdx: Int
        ) {
            val srcKind = srcSource.kind
            val dstKind = dstSource.kind
            scope.launch(Dispatchers.IO) {
                var count = 0
                when {
                    srcKind == StorageKind.LOCAL && dstKind == StorageKind.LOCAL -> {
                        val dstDir = File(dstPath)
                        items.forEach { entry ->
                            val src = File(entry.path)
                            val dst = File(dstDir, src.name)
                            if (isMove) {
                                if (!src.renameTo(dst)) {
                                    if (src.isDirectory) src.copyRecursively(dst, overwrite = true) else src.copyTo(dst, overwrite = true)
                                    src.deleteRecursively()
                                }
                            } else {
                                if (src.isDirectory) src.copyRecursively(dst, overwrite = true) else src.copyTo(dst, overwrite = true)
                            }
                            count++
                        }
                    }
                    srcKind == StorageKind.GDRIVE_API && dstKind == StorageKind.LOCAL -> {
                        val dstDir = File(dstPath)
                        items.forEach { entry ->
                            val c = downloadGoogleDriveEntry(context, entry, dstDir)
                            count += c
                            if (isMove && c > 0) deleteGoogleDriveEntry(context, entry.id)
                        }
                    }
                    srcKind == StorageKind.LOCAL && dstKind == StorageKind.GDRIVE_API -> {
                        items.forEach { entry ->
                            val f = File(entry.path)
                            val c = uploadFileToGoogleDrive(context, f, dstPath)
                            count += c
                            if (isMove && c > 0) f.deleteRecursively()
                        }
                    }
                    srcKind == StorageKind.GDRIVE_API && dstKind == StorageKind.GDRIVE_API -> {
                        items.forEach { entry ->
                            count += if (isMove) {
                                moveGoogleDriveEntry(context, entry, srcPath, dstPath)
                            } else {
                                copyGoogleDriveEntry(context, entry, dstPath)
                            }
                        }
                    }
                    srcKind == StorageKind.WEBDAV && dstKind == StorageKind.LOCAL -> {
                        val dstDir = File(dstPath)
                        items.forEach { entry ->
                            val c = downloadWebDavEntry(srcSource, entry, dstDir)
                            count += c
                            if (isMove && c > 0) deleteWebDavEntry(srcSource, entry.path)
                        }
                    }
                    srcKind == StorageKind.LOCAL && dstKind == StorageKind.WEBDAV -> {
                        items.forEach { entry ->
                            val f = File(entry.path)
                            val c = uploadFileToWebDav(dstSource, f, dstPath)
                            count += c
                            if (isMove && c > 0) f.deleteRecursively()
                        }
                    }
                    srcKind == StorageKind.FTP && dstKind == StorageKind.LOCAL -> {
                        val dstDir = File(dstPath)
                        items.forEach { entry ->
                            val c = downloadFtpEntry(srcSource, entry, dstDir)
                            count += c
                            if (isMove && c > 0) deleteFtpEntry(srcSource, entry)
                        }
                    }
                    srcKind == StorageKind.LOCAL && dstKind == StorageKind.FTP -> {
                        items.forEach { entry ->
                            val f = File(entry.path)
                            val c = uploadFileToFtp(dstSource, f, dstPath)
                            count += c
                            if (isMove && c > 0) f.deleteRecursively()
                        }
                    }
                    srcKind == StorageKind.SMB && dstKind == StorageKind.LOCAL -> {
                        val dstDir = File(dstPath)
                        items.forEach { entry ->
                            val c = downloadSmbEntry(srcSource, entry, dstDir)
                            count += c
                            if (isMove && c > 0) deleteSmbEntry(srcSource, entry)
                        }
                    }
                    srcKind == StorageKind.LOCAL && dstKind == StorageKind.SMB -> {
                        items.forEach { entry ->
                            val f = File(entry.path)
                            val c = uploadFileToSmb(dstSource, f, dstPath)
                            count += c
                            if (isMove && c > 0) f.deleteRecursively()
                        }
                    }
                }
                withContext(Dispatchers.Main) {
                    if (srcPaneIdx == 0) leftSelected = emptySet() else rightSelected = emptySet()
                    refreshTick++
                    val msg = if (count > 0) "Готово: $count" else "Не удалось выполнить перенос"
                    Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                }
            }
        }

        fun requestStoragePermission() {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION).apply {
                    data = Uri.parse("package:${context.packageName}")
                }
                context.startActivity(intent)
            } else {
                Toast.makeText(context, t.permissionTitle, Toast.LENGTH_SHORT).show()
            }
        }

        fun grantFileAccess() {
            if (hasStoragePermission()) {
                Toast.makeText(context, t.accessGrantedMsg, Toast.LENGTH_SHORT).show()
            } else {
                requestStoragePermission()
            }
        }

        val leftSource = allStorages.firstOrNull { it.id == leftStorageId } ?: allStorages.first()
        val rightSource = allStorages.firstOrNull { it.id == rightStorageId } ?: allStorages.first()
        val currentPaneStorageId = if (activePane == 0) leftStorageId else rightStorageId
        val currentSelection = if (activePane == 0) leftSelected else rightSelected

        val hoverTargetPane = when (draggingFromPane) {
            0 -> if (rightPaneBounds?.contains(dragPointerRoot) == true) 1 else null
            1 -> if (leftPaneBounds?.contains(dragPointerRoot) == true) 0 else null
            else -> null
        }

        Box(modifier = Modifier.fillMaxSize().paperTexture(!isDark)) {
        Scaffold(
            containerColor = if (!isDark) Color.Transparent else MaterialTheme.colorScheme.background,
            bottomBar = {
                Column {
                    KomandirBottomBar(
                        strings = t,
                        selectedCount = currentSelection.size,
                    onCopy = {
                        if (!dualPane) {
                            Toast.makeText(context, t.needDualPaneMsg, Toast.LENGTH_SHORT).show()
                        } else if (currentSelection.isEmpty()) {
                            Toast.makeText(context, t.selectFirstMsg, Toast.LENGTH_SHORT).show()
                        } else {
                            val srcSource = if (activePane == 0) leftSource else rightSource
                            val dstSource = if (activePane == 0) rightSource else leftSource
                            val dstPath = if (activePane == 0) rightPath else leftPath
                            val srcList = if (activePane == 0) leftEntries else rightEntries
                            val items = srcList.filter { it.id in currentSelection }
                            performTransfer(srcSource, dstSource, if (activePane == 0) leftPath else rightPath, dstPath, items, isMove = false, srcPaneIdx = activePane)
                        }
                    },
                    onMove = {
                        if (!dualPane) {
                            Toast.makeText(context, t.needDualPaneMsg, Toast.LENGTH_SHORT).show()
                        } else if (currentSelection.isEmpty()) {
                            Toast.makeText(context, t.selectFirstMsg, Toast.LENGTH_SHORT).show()
                        } else {
                            val srcSource = if (activePane == 0) leftSource else rightSource
                            val dstSource = if (activePane == 0) rightSource else leftSource
                            val dstPath = if (activePane == 0) rightPath else leftPath
                            val srcList = if (activePane == 0) leftEntries else rightEntries
                            val items = srcList.filter { it.id in currentSelection }
                            performTransfer(srcSource, dstSource, if (activePane == 0) leftPath else rightPath, dstPath, items, isMove = true, srcPaneIdx = activePane)
                        }
                    },
                    onNewFolder = { showNewFolderDialog = true },
                    onZip = {
                        if (currentSelection.isEmpty()) {
                            Toast.makeText(context, t.selectFirstMsg, Toast.LENGTH_SHORT).show()
                        } else if (currentPaneStorageId == "phone") {
                            showCreateZipDialog = true
                        } else {
                            Toast.makeText(context, t.zipLocalOnlyMsg, Toast.LENGTH_LONG).show()
                        }
                    },
                    onRename = {
                        val first = currentSelection.firstOrNull()
                        if (first == null) {
                            Toast.makeText(context, t.selectFirstMsg, Toast.LENGTH_SHORT).show()
                        } else {
                            val list = if (activePane == 0) leftEntries else rightEntries
                            val matched = list.firstOrNull { it.id == first }
                            if (matched != null) {
                                showRenameDialog = matched
                            } else {
                                val f = File(first)
                                showRenameDialog = FileEntry(first, f.name, first, f.isDirectory, f.length(), f.lastModified())
                            }
                        }
                    },
                    onDelete = {
                        if (currentSelection.isEmpty()) {
                            Toast.makeText(context, t.selectFirstMsg, Toast.LENGTH_SHORT).show()
                        } else {
                            val activeSrc = if (activePane == 0) leftSource else rightSource
                            val list = if (activePane == 0) leftEntries else rightEntries
                            val selectedEntries = list.filter { it.id in currentSelection }
                            scope.launch(Dispatchers.IO) {
                                var delCount = 0
                                when (activeSrc.kind) {
                                    StorageKind.LOCAL -> {
                                        currentSelection.forEach { p ->
                                            if (File(p).deleteRecursively()) delCount++
                                        }
                                    }
                                    StorageKind.GDRIVE_API -> {
                                        selectedEntries.forEach { e ->
                                            if (deleteGoogleDriveEntry(context, e.id)) delCount++
                                        }
                                    }
                                    StorageKind.WEBDAV -> {
                                        selectedEntries.forEach { e ->
                                            if (deleteWebDavEntry(activeSrc, e.path)) delCount++
                                        }
                                    }
                                    StorageKind.FTP -> {
                                        selectedEntries.forEach { e ->
                                            if (deleteFtpEntry(activeSrc, e)) delCount++
                                        }
                                    }
                                    StorageKind.SMB -> {
                                        selectedEntries.forEach { e ->
                                            if (deleteSmbEntry(activeSrc, e)) delCount++
                                        }
                                    }
                                    else -> {}
                                }
                                withContext(Dispatchers.Main) {
                                    if (activePane == 0) leftSelected = emptySet() else rightSelected = emptySet()
                                    refreshTick++
                                    if (delCount > 0) Toast.makeText(context, "Удалено: $delCount", Toast.LENGTH_SHORT).show()
                                }
                            }
                        }
                    }
                )
                KomandirHeader(
                    versionCode = appVerCode,
                    dualPane = dualPane,
                    onVersionClick = { showVersionDialog = true },
                    onToggleDualPane = {
                        dualPane = !dualPane
                        if (!dualPane) activePane = 0
                    },
                    onToggleSearch = {
                        searchOpen = !searchOpen
                        if (!searchOpen) searchQuery = ""
                    },
                    onOpenSettings = { showSettingsDialog = true }
                )
                }
            }
        ) { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (isPickMode) {
                    Surface(
                        color = BrandBlue,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = t.pickModeBanner,
                                color = Color.White,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.weight(1f)
                            )
                            Text(
                                text = t.cancelBtn,
                                color = BrandYellow,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier
                                    .clickable { onCancelPick() }
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }
                if (searchOpen) {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        placeholder = { Text(t.searchHint, fontSize = 13.sp) },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    )
                }

                // Лента источников (Телефон, Google Диск, Веб-диски, Сеть LAN)
                Surface(
                    color = MaterialTheme.colorScheme.surface,
                    tonalElevation = 1.dp
                ) {
                    Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = t.storagesHeader.uppercase(),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = t.addDisk,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .clickable { showAddStorageDialog = true }
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(allStorages, key = { it.id }) { st ->
                                val selected = st.id == currentPaneStorageId
                                Surface(
                                    shape = RoundedCornerShape(10.dp),
                                    color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                                    border = BorderStroke(1.dp, if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant),
                                    modifier = Modifier.clickable {
                                        if (activePane == 0) {
                                            leftStorageId = st.id
                                            leftPath = st.rootPath
                                            leftSelected = emptySet()
                                        } else {
                                            rightStorageId = st.id
                                            rightPath = st.rootPath
                                            rightSelected = emptySet()
                                        }
                                    }
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(5.dp)
                                    ) {
                                        Icon(
                                            imageVector = when (st.kind) {
                                                StorageKind.LOCAL -> Icons.Default.PhoneAndroid
                                                StorageKind.GDRIVE_API, StorageKind.SAF_CLOUD -> Icons.Default.Cloud
                                                StorageKind.WEBDAV -> Icons.Default.Language
                                                StorageKind.SMB, StorageKind.FTP -> Icons.Default.Computer
                                            },
                                            contentDescription = null,
                                            tint = if (selected) Color.White else MaterialTheme.colorScheme.onSurface,
                                            modifier = Modifier.size(15.dp)
                                        )
                                        Text(
                                            text = st.title,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            color = if (selected) Color.White else MaterialTheme.colorScheme.onSurface
                                        )
                                        if (st.isCustom) {
                                            Icon(
                                                imageVector = Icons.Default.Close,
                                                contentDescription = "Remove",
                                                tint = if (selected) Color.White.copy(alpha = 0.85f) else MaterialTheme.colorScheme.onSurfaceVariant,
                                                modifier = Modifier
                                                    .size(14.dp)
                                                    .clickable {
                                                        KomandirPrefs.removeCustomStorage(context, st.id)
                                                        customStorages = KomandirPrefs.getCustomStorages(context)
                                                        if (leftStorageId == st.id) {
                                                            leftStorageId = "phone"
                                                            leftPath = Environment.getExternalStorageDirectory().absolutePath
                                                        }
                                                        if (rightStorageId == st.id) {
                                                            rightStorageId = "phone"
                                                            rightPath = Environment.getExternalStorageDirectory().absolutePath
                                                        }
                                                    }
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // Панели файлов (1 или 2)
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .padding(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilePaneView(
                        modifier = Modifier
                            .weight(1f)
                            .onGloballyPositioned { leftPaneBounds = it.boundsInRoot() },
                        source = leftSource,
                        currentPath = leftPath,
                        selectedIds = leftSelected,
                        isActive = !dualPane || activePane == 0,
                        isDropTarget = hoverTargetPane == 0,
                        dualPane = dualPane,
                        searchQuery = searchQuery,
                        hasPermission = hasPermissionState,
                        refreshTick = refreshTick,
                        strings = t,
                        onActivate = { activePane = 0 },
                        onEntriesLoaded = { leftEntries = it },
                        onRequestPermission = { requestStoragePermission() },
                        onDragStart = { items, startOffset ->
                            activePane = 0
                            draggingFromPane = 0
                            draggingItems = items
                            dragPointerRoot = startOffset
                        },
                        onDragMove = { delta ->
                            dragPointerRoot += delta
                        },
                        onDragEnd = {
                            val droppedInRight = rightPaneBounds?.contains(dragPointerRoot) == true
                            if (droppedInRight && draggingItems.isNotEmpty()) {
                                pendingDrop = Triple(0, 1, draggingItems)
                            }
                            draggingFromPane = null
                            draggingItems = emptyList()
                        },
                        onNavigate = { newPath ->
                            activePane = 0
                            leftPath = newPath
                            leftSelected = emptySet()
                        },
                        onToggleSelect = { id ->
                            activePane = 0
                            leftSelected = if (id in leftSelected) leftSelected - id else leftSelected + id
                        },
                        onOpenFile = { entry ->
                            if (leftSource.kind == StorageKind.LOCAL) {
                                val f = File(entry.path)
                                if (isPickMode) {
                                    onPickFile(f)
                                } else if (isImageFileName(entry.name)) {
                                    val siblings = f.parentFile?.listFiles()?.filter { !it.isDirectory && isImageFileName(it.name) }?.sortedBy { it.name.lowercase() } ?: listOf(f)
                                    viewerImageGallery = siblings
                                    viewerImageFile = f
                                } else if (isVideoFileName(entry.name)) {
                                    val siblings = f.parentFile?.listFiles()?.filter { !it.isDirectory && isVideoFileName(it.name) }?.sortedBy { it.name.lowercase() } ?: listOf(f)
                                    viewerVideoGallery = siblings
                                    viewerVideoFile = f
                                } else if (isAudioFileName(entry.name)) {
                                    val siblings = f.parentFile?.listFiles()?.filter { !it.isDirectory && isAudioFileName(it.name) }?.sortedBy { it.name.lowercase() } ?: listOf(f)
                                    viewerAudioGallery = siblings
                                    viewerAudioFile = f
                                } else if (isPdfFileName(entry.name)) {
                                    viewerPdfFile = f
                                } else if (isHtmlOrSvgFileName(entry.name)) {
                                    viewerHtmlFile = f
                                } else if (isTextFileName(entry.name)) {
                                    viewerTextFile = f
                                } else if (isZipFileName(entry.name)) {
                                    zipViewerFile = f
                                } else {
                                    runCatching {
                                        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", f)
                                        val low = f.name.lowercase()
                                        val mime = when {
                                            low.endsWith(".apk") -> "application/vnd.android.package-archive"
                                            low.endsWith(".pdf") -> "application/pdf"
                                            low.endsWith(".txt") || low.endsWith(".log") -> "text/plain"
                                            low.endsWith(".mp4") || low.endsWith(".mkv") -> "video/*"
                                            low.endsWith(".mp3") || low.endsWith(".wav") -> "audio/*"
                                            else -> "*/*"
                                        }
                                        val intent = Intent(Intent.ACTION_VIEW).apply {
                                            setDataAndType(uri, mime)
                                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                        }
                                        context.startActivity(intent)
                                    }
                                }
                            }
                        }
                    )

                    if (dualPane) {
                        FilePaneView(
                            modifier = Modifier
                                .weight(1f)
                                .onGloballyPositioned { rightPaneBounds = it.boundsInRoot() },
                            source = rightSource,
                            currentPath = rightPath,
                            selectedIds = rightSelected,
                            isActive = activePane == 1,
                            isDropTarget = hoverTargetPane == 1,
                            dualPane = dualPane,
                            searchQuery = searchQuery,
                            hasPermission = hasPermissionState,
                            refreshTick = refreshTick,
                            strings = t,
                            onActivate = { activePane = 1 },
                            onEntriesLoaded = { rightEntries = it },
                            onRequestPermission = { requestStoragePermission() },
                            onDragStart = { items, startOffset ->
                                activePane = 1
                                draggingFromPane = 1
                                draggingItems = items
                                dragPointerRoot = startOffset
                            },
                            onDragMove = { delta ->
                                dragPointerRoot += delta
                            },
                            onDragEnd = {
                                val droppedInLeft = leftPaneBounds?.contains(dragPointerRoot) == true
                                if (droppedInLeft && draggingItems.isNotEmpty()) {
                                    pendingDrop = Triple(1, 0, draggingItems)
                                }
                                draggingFromPane = null
                                draggingItems = emptyList()
                            },
                            onNavigate = { newPath ->
                                activePane = 1
                                rightPath = newPath
                                rightSelected = emptySet()
                            },
                            onToggleSelect = { id ->
                                activePane = 1
                                rightSelected = if (id in rightSelected) rightSelected - id else rightSelected + id
                            },
                            onOpenFile = { entry ->
                                if (rightSource.kind == StorageKind.LOCAL) {
                                val f = File(entry.path)
                                if (isPickMode) {
                                    onPickFile(f)
                                } else if (isImageFileName(entry.name)) {
                                    val siblings = f.parentFile?.listFiles()?.filter { !it.isDirectory && isImageFileName(it.name) }?.sortedBy { it.name.lowercase() } ?: listOf(f)
                                    viewerImageGallery = siblings
                                    viewerImageFile = f
                                } else if (isVideoFileName(entry.name)) {
                                    val siblings = f.parentFile?.listFiles()?.filter { !it.isDirectory && isVideoFileName(it.name) }?.sortedBy { it.name.lowercase() } ?: listOf(f)
                                    viewerVideoGallery = siblings
                                    viewerVideoFile = f
                                } else if (isAudioFileName(entry.name)) {
                                    val siblings = f.parentFile?.listFiles()?.filter { !it.isDirectory && isAudioFileName(it.name) }?.sortedBy { it.name.lowercase() } ?: listOf(f)
                                    viewerAudioGallery = siblings
                                    viewerAudioFile = f
                                } else if (isPdfFileName(entry.name)) {
                                    viewerPdfFile = f
                                } else if (isHtmlOrSvgFileName(entry.name)) {
                                    viewerHtmlFile = f
                                } else if (isTextFileName(entry.name)) {
                                    viewerTextFile = f
                                } else if (isZipFileName(entry.name)) {
                                    zipViewerFile = f
                                } else {
                                    runCatching {
                                        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", f)
                                        val low = f.name.lowercase()
                                        val mime = when {
                                            low.endsWith(".apk") -> "application/vnd.android.package-archive"
                                            low.endsWith(".pdf") -> "application/pdf"
                                            low.endsWith(".txt") || low.endsWith(".log") -> "text/plain"
                                            low.endsWith(".mp4") || low.endsWith(".mkv") -> "video/*"
                                            low.endsWith(".mp3") || low.endsWith(".wav") -> "audio/*"
                                            else -> "*/*"
                                        }
                                        val intent = Intent(Intent.ACTION_VIEW).apply {
                                            setDataAndType(uri, mime)
                                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                        }
                                        context.startActivity(intent)
                                    }
                                }
                                }
                            }
                        )
                    }
                }
            }
        }

        // Окно полной версии по тапу на "v.4 by mizgiroff"
        if (showVersionDialog) {
            val changelog = listOf(
                "v22 (26.11.22)" to "Полный цикл операций для SMB/FTP/WebDAV, копирование/перемещение/удаление внутри Google Диска, встроенный HEX-просмотрщик, тёмная адаптивная иконка, просмотр EXIF фото и отправка фото с EXIF в ветку Gemini.",
                "v21 (26.11.22)" to "Иммерсивный полноэкранный видеоплеер, интеграция в систему (приём файлов через «Поделиться», live-обработка onNewIntent, кнопка «Открывать по умолчанию» в Настройках).",
                "v20 (26.11.22)" to "Основной язык при запуске — Українська (порядок: Українська, English, Русский), выбор темы добавлен в стартовое окно.",
                "v19 (26.11.22)" to "Исправлена компиляция KomandirDocumentsProvider (lastModified и MIME-тип).",
                "v18 (26.11.22)" to "1. Добавлен DocumentsProvider — Komandir теперь отображается как источник файлов в боковом меню ≡ системного окна «Файлы» (Телефон и Google Диск).",
                "v17 (26.11.22)" to "В окно просмотра ZIP-архивов добавлена кнопка «В Загрузки» для сохранения архива в папку Download без распаковки.",
                "v16 (26.11.22)" to "Светлая тема оформлена в стиле светло-жёлтой фактурной бумаги, добавлены встроенные просмотрщики (видео, аудио, PDF, текст/код, HTML/SVG), починено создание новой папки, исправлен запуск .apk и поворот экрана в фото, добавлено листание фото свайпами.",
                "v15 (26.11.22)" to "Лента мини-фоток и автопросмотр в фотопросмотрщике, реальное копирование файлов и папок между Google Диском и Телефоном, подсказка про архивацию на Диске, полный журнал версий.",
                "v14 (26.11.22)" to "Восстановлены переменные состояния и прав памяти, успешная Release-сборка.",
                "v13 (26.11.22)" to "Прямой Google Drive API v3 с вшитым Desktop Client ID и OAuth2 127.0.0.1 loopback.",
                "v12 (26.11.21)" to "Динамическая версия из PackageManager, выход из просмотра фото свайпом назад, встроенная кнопка Google Cloud и копирование SHA-1.",
                "v11 (26.11.21)" to "Исправлен SMB-клиент (NetworkClients.kt).",
                "v10 (26.11.21)" to "Настоящие сетевые клиенты (SMB, FTP, WebDAV, SAF), жесты назад и свайп влево, исправлен Drag & Drop.",
                "v9 (26.11.21)" to "Передача параметров просмотра внешних файлов и архивации.",
                "v8 (26.11.21)" to "Добавлены состояния просмотрщика фото и ZIP.",
                "v7 (26.11.21)" to "Восстановлены импорты Compose для просмотрщика и архиватора.",
                "v6 (26.11.21)" to "Встроенный ZIP-архиватор, полноэкранный просмотрщик фото и фильтры ACTION_VIEW.",
                "v5 (26.11.21)" to "Исправлен порядок функций прав доступа в MainActivity.",
                "v4 (26.11.21)" to "Режим выбора файлов для других приложений (GET_CONTENT) и постоянная цифровая подпись komandir.keystore.",
                "v3 (26.11.21)" to "Отображение только подключённых дисков, пошаговый мастер подключения, кнопка «Разрешить», плотные строки папок, сине-жёлтый перелив шапки.",
                "v2 (26.11.21)" to "Нижняя шапка в стиле MedAssist, перетаскивание между панелями (Drag & Drop).",
                "v1 (26.11.21)" to "Базовый каркас Komandir by mizgiroff (1/2 панели, темы, RU/UA/EN)."
            )
            AlertDialog(
                onDismissRequest = { showVersionDialog = false },
                title = { Text("Komandir · v.$appVerCode by mizgiroff", fontWeight = FontWeight.Bold) },
                text = {
                    Column(
                        modifier = Modifier
                            .heightIn(max = 400.dp)
                            .verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text("${t.versionFullLabel} v$appVerName (код $appVerCode)", fontWeight = FontWeight.SemiBold)
                        Text("${t.versionAuthorLabel} mizgiroff", fontSize = 12.sp)
                        Text(t.versionDesc, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
                        Text("Журнал версий", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                        changelog.forEach { (ver, desc) ->
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant
                            ) {
                                Column(modifier = Modifier.fillMaxWidth().padding(8.dp)) {
                                    Text(ver, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    Text(desc, fontSize = 11.sp, lineHeight = 15.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    }
                },
                confirmButton = {
                    Button(onClick = { showVersionDialog = false }) { Text(t.okBtn) }
                }
            )
        }

        // Окно настроек (Тема + Язык)
        if (showSettingsDialog) {
            AlertDialog(
                onDismissRequest = { showSettingsDialog = false },
                title = { Text(t.settingsTitle, fontWeight = FontWeight.Bold) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text(t.themeLabel, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf(
                                AppThemeMode.LIGHT to t.themeLight,
                                AppThemeMode.DARK to t.themeDark,
                                AppThemeMode.SYSTEM to t.themeSystem
                            ).forEach { (mode, label) ->
                                val active = themeMode == mode
                                OutlinedButton(
                                    onClick = {
                                        themeMode = mode
                                        KomandirPrefs.setTheme(context, mode)
                                    },
                                    modifier = Modifier.weight(1f),
                                    contentPadding = PaddingValues(horizontal = 4.dp, vertical = 6.dp),
                                    colors = ButtonDefaults.outlinedButtonColors(
                                        containerColor = if (active) MaterialTheme.colorScheme.primary else Color.Transparent,
                                        contentColor = if (active) Color.White else MaterialTheme.colorScheme.onSurface
                                    )
                                ) {
                                    Text(label, fontSize = 11.sp, maxLines = 1)
                                }
                            }
                        }

                        Text(t.langLabel, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            AppLang.entries.forEach { lang ->
                                val active = appLang == lang
                                OutlinedButton(
                                    onClick = {
                                        appLang = lang
                                        KomandirPrefs.setLang(context, lang)
                                    },
                                    modifier = Modifier.weight(1f),
                                    contentPadding = PaddingValues(horizontal = 4.dp, vertical = 6.dp),
                                    colors = ButtonDefaults.outlinedButtonColors(
                                        containerColor = if (active) MaterialTheme.colorScheme.primary else Color.Transparent,
                                        contentColor = if (active) Color.White else MaterialTheme.colorScheme.onSurface
                                    )
                                ) {
                                    Text(lang.label, fontSize = 11.sp, maxLines = 1)
                                }
                            }
                        }
                        OutlinedButton(
                            onClick = { grantFileAccess() },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(t.allowBtn, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        }
                        OutlinedButton(
                            onClick = {
                                val defIntent = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                                    Intent(Settings.ACTION_APP_OPEN_BY_DEFAULT_SETTINGS, Uri.parse("package:${context.packageName}"))
                                } else {
                                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${context.packageName}"))
                                }
                                runCatching { context.startActivity(defIntent) }.onFailure {
                                    runCatching {
                                        context.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${context.packageName}")))
                                    }
                                }
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Открывать по умолчанию", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }
                },
                confirmButton = {
                    Button(onClick = { showSettingsDialog = false }) { Text(t.done) }
                }
            )
        }

        // Первый запуск: выбор языка (UK -> EN -> RU) и темы
        if (showLangPrompt) {
            AlertDialog(
                onDismissRequest = {},
                title = { Text(t.chooseLangTitle, fontWeight = FontWeight.Bold) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        AppLang.entries.forEach { lang ->
                            val active = appLang == lang
                            OutlinedButton(
                                onClick = {
                                    appLang = lang
                                    KomandirPrefs.setLang(context, lang)
                                },
                                modifier = Modifier.fillMaxWidth(),
                                colors = ButtonDefaults.outlinedButtonColors(
                                    containerColor = if (active) MaterialTheme.colorScheme.primary else Color.Transparent,
                                    contentColor = if (active) Color.White else MaterialTheme.colorScheme.onSurface
                                )
                            ) {
                                Text(lang.label, fontWeight = if (active) FontWeight.Bold else FontWeight.Normal)
                            }
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(t.themeLabel, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf(
                                AppThemeMode.LIGHT to t.themeLight,
                                AppThemeMode.DARK to t.themeDark,
                                AppThemeMode.SYSTEM to t.themeSystem
                            ).forEach { (mode, label) ->
                                val active = themeMode == mode
                                OutlinedButton(
                                    onClick = {
                                        themeMode = mode
                                        KomandirPrefs.setTheme(context, mode)
                                    },
                                    modifier = Modifier.weight(1f),
                                    contentPadding = PaddingValues(horizontal = 4.dp, vertical = 6.dp),
                                    colors = ButtonDefaults.outlinedButtonColors(
                                        containerColor = if (active) MaterialTheme.colorScheme.primary else Color.Transparent,
                                        contentColor = if (active) Color.White else MaterialTheme.colorScheme.onSurface
                                    )
                                ) {
                                    Text(label, fontSize = 11.sp, maxLines = 1)
                                }
                            }
                        }
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            KomandirPrefs.setLang(context, appLang)
                            KomandirPrefs.setTheme(context, themeMode)
                            showLangPrompt = false
                        }
                    ) { Text(t.done) }
                }
            )
        }

        // Пошаговый мастер подключения реальных дисков (Google Диск/SAF, WebDAV, SMB, FTP)
        if (showAddStorageDialog) {
            var step by remember { mutableIntStateOf(1) }
            var selectedPreset by remember { mutableStateOf("saf") }
            var newName by remember { mutableStateOf("") }
            var newHost by remember { mutableStateOf("") }
            var newShare by remember { mutableStateOf("") }
            var newLogin by remember { mutableStateOf("") }
            var newPass by remember { mutableStateOf("") }

            val safLauncher = rememberLauncherForActivityResult(
                contract = ActivityResultContracts.OpenDocumentTree()
            ) { treeUri ->
                if (treeUri != null) {
                    runCatching {
                        val flags = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                        context.contentResolver.takePersistableUriPermission(treeUri, flags)
                    }
                    val docName = androidx.documentfile.provider.DocumentFile.fromTreeUri(context, treeUri)?.name
                    val src = StorageSource(
                        id = "saf_${System.currentTimeMillis()}",
                        title = newName.ifBlank { docName ?: "Google Диск" },
                        kind = StorageKind.SAF_CLOUD,
                        rootPath = treeUri.toString(),
                        host = treeUri.toString(),
                        isCustom = true
                    )
                    KomandirPrefs.addCustomStorage(context, src)
                    customStorages = KomandirPrefs.getCustomStorages(context)
                    if (activePane == 0) {
                        leftStorageId = src.id
                        leftPath = src.rootPath
                        leftSelected = emptySet()
                    } else {
                        rightStorageId = src.id
                        rightPath = src.rootPath
                        rightSelected = emptySet()
                    }
                    showAddStorageDialog = false
                }
            }

            var gdClientId by remember { mutableStateOf(KomandirPrefs.getGdClientId(context)) }
            val presets = listOf(
                Triple("gdrive_api", "Google Диск (API — весь диск)", StorageKind.GDRIVE_API),
                Triple("saf", "Папка на телефоне / SD (SAF)", StorageKind.SAF_CLOUD),
                Triple("webdav", "WebDAV (Nextcloud / Яндекс)", StorageKind.WEBDAV),
                Triple("smb", "Сеть LAN — SMB (Windows / NAS)", StorageKind.SMB),
                Triple("ftp", "FTP сервер (Роутер / NAS)", StorageKind.FTP)
            )

            AlertDialog(
                onDismissRequest = { showAddStorageDialog = false },
                title = {
                    Text(
                        text = if (step == 1) t.addStorageTitle else (presets.firstOrNull { it.first == selectedPreset }?.second ?: t.addStorageTitle),
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                },
                text = {
                    if (step == 1) {
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(t.wizardStep1, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            presets.forEach { (key, title, kind) ->
                                Surface(
                                    shape = RoundedCornerShape(10.dp),
                                    color = MaterialTheme.colorScheme.surfaceVariant,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            selectedPreset = key
                                            newName = when (key) {
                                                "gdrive_api" -> "Google Диск"
                                                "saf" -> "Папка SAF"
                                                "webdav" -> "WebDAV"
                                                "smb" -> "Home NAS"
                                                else -> "FTP"
                                            }
                                            newHost = when (key) {
                                                "webdav" -> "https://cloud.example.com/remote.php/dav/files/user/"
                                                "smb" -> "192.168.1.50"
                                                "ftp" -> "192.168.88.1:21"
                                                else -> ""
                                            }
                                            newShare = if (key == "smb") "Public" else ""
                                            step = 2
                                        }
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(title, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                                        Text(kind.badge, fontSize = 10.sp, color = MaterialTheme.colorScheme.primary)
                                    }
                                }
                            }
                        }
                    } else {
                        Column(
                            modifier = Modifier.verticalScroll(rememberScrollState()),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            val hintText = when (selectedPreset) {
                                "gdrive_api" -> "Вставьте Android Client ID из Google Cloud Console и нажмите «Войти через Google»."
                                "saf" -> t.safHint
                                "webdav" -> t.webdavHint
                                "smb" -> t.smbHint
                                else -> t.ftpHint
                            }
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = MaterialTheme.colorScheme.primary.copy(alpha = 0.1f)
                            ) {
                                Text(
                                    text = hintText,
                                    fontSize = 11.sp,
                                    lineHeight = 15.sp,
                                    modifier = Modifier.padding(8.dp)
                                )
                            }
                            OutlinedTextField(
                                value = newName,
                                onValueChange = { newName = it },
                                label = { Text(t.storageNameLabel) },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                            if (selectedPreset == "gdrive_api") {
                                Surface(
                                    shape = RoundedCornerShape(10.dp),
                                    color = MaterialTheme.colorScheme.surfaceVariant
                                ) {
                                    Column(modifier = Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                        Text(
                                            text = "1. Откройте Google Cloud → создайте проект и включите Google Drive API.\n2. В Audience добавьте свой Gmail в Test users.\n3. В Clients создайте Android Client ID:\n• Package: com.mizgiroff.komandir\n• SHA-1: A2:91:2F:AD:EC:86:E9:A1:9B:85:CA:49:6B:C9:54:F0:9F:3B:5D:D6",
                                            fontSize = 11.sp,
                                            lineHeight = 15.sp
                                        )
                                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                            OutlinedButton(
                                                onClick = {
                                                    val url = "https://console.cloud.google.com/auth/clients"
                                                    context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                                                },
                                                modifier = Modifier.weight(1f),
                                                contentPadding = PaddingValues(horizontal = 6.dp, vertical = 4.dp)
                                            ) {
                                                Text("Google Cloud", fontSize = 11.sp, maxLines = 1)
                                            }
                                            OutlinedButton(
                                                onClick = {
                                                    val cm = context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as ClipboardManager
                                                    val txt = "com.mizgiroff.komandir\nA2:91:2F:AD:EC:86:E9:A1:9B:85:CA:49:6B:C9:54:F0:9F:3B:5D:D6"
                                                    cm.setPrimaryClip(ClipData.newPlainText("Komandir OAuth", txt))
                                                    Toast.makeText(context, "Package и SHA-1 скопированы", Toast.LENGTH_SHORT).show()
                                                },
                                                modifier = Modifier.weight(1f),
                                                contentPadding = PaddingValues(horizontal = 6.dp, vertical = 4.dp)
                                            ) {
                                                Text("Копировать SHA-1", fontSize = 11.sp, maxLines = 1)
                                            }
                                        }
                                    }
                                }
                                OutlinedTextField(
                                    value = gdClientId,
                                    onValueChange = { gdClientId = it },
                                    label = { Text("Google OAuth Client ID") },
                                    placeholder = { Text("123456-abc.apps.googleusercontent.com") },
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth()
                                )
                                Button(
                                    onClick = {
                                        val cid = gdClientId.trim().ifBlank { KomandirPrefs.DEFAULT_GD_CLIENT_ID }
                                        KomandirPrefs.setGdClientId(context, cid)
                                        scope.launch(Dispatchers.IO) {
                                            val tokens = runGoogleOAuthLoopback(
                                                clientId = cid,
                                                clientSecret = if (cid == KomandirPrefs.DEFAULT_GD_CLIENT_ID) KomandirPrefs.DEFAULT_GD_CLIENT_SECRET else "",
                                                onOpenUrl = { url ->
                                                    context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                                                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                                    })
                                                }
                                            )
                                            withContext(Dispatchers.Main) {
                                                if (tokens != null) {
                                                    KomandirPrefs.saveGdTokens(context, tokens.first, tokens.second)
                                                    if (customStorages.none { it.kind == StorageKind.GDRIVE_API }) {
                                                        val gd = StorageSource(
                                                            id = "gdrive_api",
                                                            title = "Google Диск",
                                                            kind = StorageKind.GDRIVE_API,
                                                            rootPath = "root",
                                                            isCustom = true
                                                        )
                                                        KomandirPrefs.addCustomStorage(context, gd)
                                                        customStorages = KomandirPrefs.getCustomStorages(context)
                                                    }
                                                    if (activePane == 0) {
                                                        leftStorageId = "gdrive_api"
                                                        leftPath = "root"
                                                        leftSelected = emptySet()
                                                    } else {
                                                        rightStorageId = "gdrive_api"
                                                        rightPath = "root"
                                                        rightSelected = emptySet()
                                                    }
                                                    showAddStorageDialog = false
                                                    Toast.makeText(context, "Google Диск подключён ✓", Toast.LENGTH_SHORT).show()
                                                } else {
                                                    Toast.makeText(context, "Ошибка авторизации Google Drive", Toast.LENGTH_SHORT).show()
                                                }
                                            }
                                        }
                                    },
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text("Войти через Google")
                                }
                            } else if (selectedPreset == "saf") {
                                Button(
                                    onClick = { safLauncher.launch(null) },
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text(t.safPickBtn)
                                }
                            } else {
                                OutlinedTextField(
                                    value = newHost,
                                    onValueChange = { newHost = it },
                                    label = { Text(t.storageHostLabel) },
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth()
                                )
                                if (selectedPreset == "smb") {
                                    OutlinedTextField(
                                        value = newShare,
                                        onValueChange = { newShare = it },
                                        label = { Text(t.shareLabel) },
                                        singleLine = true,
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                }
                                OutlinedTextField(
                                    value = newLogin,
                                    onValueChange = { newLogin = it },
                                    label = { Text(t.storageLoginLabel) },
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth()
                                )
                                OutlinedTextField(
                                    value = newPass,
                                    onValueChange = { newPass = it },
                                    label = { Text(t.storagePassLabel) },
                                    visualTransformation = PasswordVisualTransformation(),
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                        }
                    }
                },
                confirmButton = {
                    if (step == 2 && selectedPreset != "saf" && selectedPreset != "gdrive_api") {
                        Button(onClick = {
                            val kind = presets.firstOrNull { it.first == selectedPreset }?.third ?: StorageKind.SMB
                            val initialPath = when (kind) {
                                StorageKind.WEBDAV -> newHost.trim()
                                else -> "/"
                            }
                            val src = StorageSource(
                                id = "net_${System.currentTimeMillis()}",
                                title = newName.ifBlank { kind.badge },
                                kind = kind,
                                rootPath = initialPath,
                                host = newHost.trim(),
                                shareName = newShare.trim(),
                                username = newLogin.trim(),
                                password = newPass,
                                isCustom = true
                            )
                            KomandirPrefs.addCustomStorage(context, src)
                            customStorages = KomandirPrefs.getCustomStorages(context)
                            if (activePane == 0) {
                                leftStorageId = src.id
                                leftPath = src.rootPath
                                leftSelected = emptySet()
                            } else {
                                rightStorageId = src.id
                                rightPath = src.rootPath
                                rightSelected = emptySet()
                            }
                            showAddStorageDialog = false
                        }) {
                            Text(t.wizardConnect)
                        }
                    }
                },
                dismissButton = {
                    if (step == 2) {
                        TextButton(onClick = { step = 1 }) { Text(t.wizardBack) }
                    } else {
                        TextButton(onClick = { showAddStorageDialog = false }) { Text(t.cancelBtn) }
                    }
                }
            )
        }

        // Диалог при отпускании файла в другую панель (Копировать / Переместить)
        pendingDrop?.let { (srcPane, dstPane, items) ->
            val srcSource = if (srcPane == 0) leftSource else rightSource
            val dstSource = if (dstPane == 0) leftSource else rightSource
            val dstPath = if (dstPane == 0) leftPath else rightPath
            AlertDialog(
                onDismissRequest = { pendingDrop = null },
                title = { Text(t.dropTitle, fontWeight = FontWeight.Bold) },
                text = { Text(t.dropMessage(items.size, dstSource.title)) },
                confirmButton = {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Button(onClick = {
                            performTransfer(srcSource, dstSource, if (srcPane == 0) leftPath else rightPath, dstPath, items, isMove = false, srcPaneIdx = srcPane)
                            pendingDrop = null
                        }) {
                            Text(t.actCopy)
                        }
                        OutlinedButton(onClick = {
                            performTransfer(srcSource, dstSource, if (srcPane == 0) leftPath else rightPath, dstPath, items, isMove = true, srcPaneIdx = srcPane)
                            pendingDrop = null
                        }) {
                            Text(t.actMove)
                        }
                    }
                },
                dismissButton = {
                    TextButton(onClick = { pendingDrop = null }) { Text(t.cancelBtn) }
                }
            )
        }

        // Создание новой папки
        if (showNewFolderDialog) {
            var folderName by remember { mutableStateOf("") }
            AlertDialog(
                onDismissRequest = { showNewFolderDialog = false },
                title = { Text(t.actNewFolder, fontWeight = FontWeight.Bold) },
                text = {
                    OutlinedTextField(
                        value = folderName,
                        onValueChange = { folderName = it },
                        singleLine = true,
                        placeholder = { Text("Новая папка") },
                        modifier = Modifier.fillMaxWidth()
                    )
                },
                confirmButton = {
                    Button(onClick = {
                        val cleanName = folderName.trim()
                        if (cleanName.isNotEmpty()) {
                            val activeSrc = if (activePane == 0) leftSource else rightSource
                            val activeDir = if (activePane == 0) leftPath else rightPath
                            when (activeSrc.kind) {
                                StorageKind.LOCAL -> {
                                    val dir = File(activeDir, cleanName)
                                    val ok = dir.exists() || dir.mkdirs()
                                    if (ok) {
                                        refreshTick++
                                        Toast.makeText(context, "Папка создана: $cleanName", Toast.LENGTH_SHORT).show()
                                    } else {
                                        Toast.makeText(context, "Не удалось создать папку", Toast.LENGTH_SHORT).show()
                                    }
                                }
                                StorageKind.GDRIVE_API -> {
                                    scope.launch(Dispatchers.IO) {
                                        val createdId = createGoogleDriveFolder(context, cleanName, activeDir.ifBlank { "root" })
                                        withContext(Dispatchers.Main) {
                                            if (createdId != null) {
                                                refreshTick++
                                                Toast.makeText(context, "Папка создана на Диске: $cleanName", Toast.LENGTH_SHORT).show()
                                            } else {
                                                Toast.makeText(context, "Не удалось создать папку на Диске", Toast.LENGTH_SHORT).show()
                                            }
                                        }
                                    }
                                }
                                StorageKind.WEBDAV -> {
                                    scope.launch(Dispatchers.IO) {
                                        val ok = createWebDavFolder(activeSrc, activeDir, cleanName)
                                        withContext(Dispatchers.Main) {
                                            if (ok) refreshTick++
                                            Toast.makeText(context, if (ok) "Папка создана: $cleanName" else "Ошибка WebDAV", Toast.LENGTH_SHORT).show()
                                        }
                                    }
                                }
                                StorageKind.FTP -> {
                                    scope.launch(Dispatchers.IO) {
                                        val ok = createFtpFolder(activeSrc, activeDir, cleanName)
                                        withContext(Dispatchers.Main) {
                                            if (ok) refreshTick++
                                            Toast.makeText(context, if (ok) "Папка создана: $cleanName" else "Ошибка FTP", Toast.LENGTH_SHORT).show()
                                        }
                                    }
                                }
                                StorageKind.SMB -> {
                                    scope.launch(Dispatchers.IO) {
                                        val ok = createSmbFolder(activeSrc, activeDir, cleanName)
                                        withContext(Dispatchers.Main) {
                                            if (ok) refreshTick++
                                            Toast.makeText(context, if (ok) "Папка создана: $cleanName" else "Ошибка SMB", Toast.LENGTH_SHORT).show()
                                        }
                                    }
                                }
                                else -> {
                                    Toast.makeText(context, "Не поддерживается для этого диска", Toast.LENGTH_SHORT).show()
                                }
                            }
                        }
                        showNewFolderDialog = false
                    }) { Text(t.okBtn) }
                },
                dismissButton = {
                    TextButton(onClick = { showNewFolderDialog = false }) { Text(t.cancelBtn) }
                }
            )
        }

        // Переименование
        showRenameDialog?.let { entry ->
            var newName by remember { mutableStateOf(entry.name) }
            AlertDialog(
                onDismissRequest = { showRenameDialog = null },
                title = { Text(t.renameTitle) },
                text = {
                    OutlinedTextField(
                        value = newName,
                        onValueChange = { newName = it },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                },
                confirmButton = {
                    Button(onClick = {
                        val clean = newName.trim()
                        if (clean.isNotBlank()) {
                            val activeSrc = if (activePane == 0) leftSource else rightSource
                            scope.launch(Dispatchers.IO) {
                                val ok = when (activeSrc.kind) {
                                    StorageKind.LOCAL -> File(entry.path).renameTo(File(File(entry.path).parentFile, clean))
                                    StorageKind.GDRIVE_API -> renameGoogleDriveEntry(context, entry.id, clean)
                                    StorageKind.WEBDAV -> renameWebDavEntry(activeSrc, entry.path, clean)
                                    StorageKind.FTP -> renameFtpEntry(activeSrc, entry.path, clean)
                                    StorageKind.SMB -> renameSmbEntry(activeSrc, entry, clean)
                                    else -> false
                                }
                                withContext(Dispatchers.Main) {
                                    if (activePane == 0) leftSelected = emptySet() else rightSelected = emptySet()
                                    if (ok) refreshTick++
                                    Toast.makeText(context, if (ok) "Переименовано" else "Не удалось переименовать", Toast.LENGTH_SHORT).show()
                                }
                            }
                        }
                        showRenameDialog = null
                    }) { Text(t.okBtn) }
                },
                dismissButton = {
                    TextButton(onClick = { showRenameDialog = null }) { Text(t.cancelBtn) }
                }
            )
        }

        // Создание ZIP-архива
        if (showCreateZipDialog) {
            var zipName by remember { mutableStateOf("archive.zip") }
            AlertDialog(
                onDismissRequest = { showCreateZipDialog = false },
                title = { Text(t.zipCreateTitle, fontWeight = FontWeight.Bold) },
                text = {
                    OutlinedTextField(
                        value = zipName,
                        onValueChange = { zipName = it },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                },
                confirmButton = {
                    Button(onClick = {
                        val finalName = if (zipName.lowercase().endsWith(".zip")) zipName.trim() else "${zipName.trim()}.zip"
                        val targetDir = File(if (activePane == 0) leftPath else rightPath)
                        val sources = currentSelection.map { File(it) }
                        scope.launch(Dispatchers.IO) {
                            createZipArchive(sources, File(targetDir, finalName))
                            withContext(Dispatchers.Main) {
                                if (activePane == 0) leftSelected = emptySet() else rightSelected = emptySet()
                                refreshTick++
                                Toast.makeText(context, t.zipDoneMsg(finalName), Toast.LENGTH_SHORT).show()
                            }
                        }
                        showCreateZipDialog = false
                    }) { Text(t.okBtn) }
                },
                dismissButton = {
                    TextButton(onClick = { showCreateZipDialog = false }) { Text(t.cancelBtn) }
                }
            )
        }

        // Просмотрщик и распаковщик ZIP-архивов
        if (zipViewerFile != null || zipViewerUri != null) {
            BackHandler(enabled = true) {
                zipViewerFile = null
                zipViewerUri = null
            }
            var zipEntries by remember { mutableStateOf<List<ZipItemInfo>>(emptyList()) }
            LaunchedEffect(zipViewerFile, zipViewerUri) {
                zipEntries = withContext(Dispatchers.IO) {
                    when {
                        zipViewerFile != null -> runCatching { listZipEntries(zipViewerFile!!) }.getOrDefault(emptyList())
                        zipViewerUri != null -> runCatching { listZipEntriesFromUri(context, zipViewerUri!!) }.getOrDefault(emptyList())
                        else -> emptyList()
                    }
                }
            }
            AlertDialog(
                onDismissRequest = { zipViewerFile = null; zipViewerUri = null },
                title = { Text(zipViewerFile?.name ?: t.zipTitle, fontWeight = FontWeight.Bold, fontSize = 15.sp) },
                text = {
                    LazyColumn(modifier = Modifier.heightIn(max = 360.dp)) {
                        items(zipEntries) { ze ->
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(ze.name, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                                if (!ze.isDirectory) {
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(formatFileSize(ze.sizeBytes), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                            HorizontalDivider(thickness = 0.5.dp)
                        }
                    }
                },
                confirmButton = {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = {
                            val fRef = zipViewerFile
                            val uRef = zipViewerUri
                            scope.launch(Dispatchers.IO) {
                                val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                                if (!downloadsDir.exists()) downloadsDir.mkdirs()
                                val fileName = when {
                                    fRef != null -> fRef.name
                                    uRef != null -> {
                                        var resolved: String? = null
                                        runCatching {
                                            context.contentResolver.query(uRef, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                                                if (c.moveToFirst()) resolved = c.getString(0)
                                            }
                                        }
                                        val raw = resolved ?: uRef.lastPathSegment ?: "archive_${System.currentTimeMillis()}.zip"
                                        if (raw.lowercase().endsWith(".zip")) raw else "$raw.zip"
                                    }
                                    else -> "archive.zip"
                                }
                                val destFile = File(downloadsDir, fileName)
                                val ok = runCatching {
                                    when {
                                        fRef != null -> fRef.copyTo(destFile, overwrite = true)
                                        uRef != null -> {
                                            context.contentResolver.openInputStream(uRef)?.use { inp ->
                                                destFile.outputStream().use { out -> inp.copyTo(out) }
                                            }
                                        }
                                    }
                                    true
                                }.getOrDefault(false)
                                withContext(Dispatchers.Main) {
                                    refreshTick++
                                    val msg = if (ok) "Сохранено в Загрузки: $fileName" else "Ошибка сохранения в Загрузки"
                                    Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
                                }
                            }
                            zipViewerFile = null
                            zipViewerUri = null
                        }) { Text("В Загрузки") }

                        Button(onClick = {
                            val destBase = File(if (activePane == 0) leftPath else rightPath)
                            val folderName = (zipViewerFile?.nameWithoutExtension ?: "Extracted")
                            val destDir = File(destBase, folderName)
                            val fRef = zipViewerFile
                            val uRef = zipViewerUri
                            scope.launch(Dispatchers.IO) {
                                val count = when {
                                    fRef != null -> extractZipFile(fRef, destDir)
                                    uRef != null -> extractZipFromUri(context, uRef, destDir)
                                    else -> 0
                                }
                                withContext(Dispatchers.Main) {
                                    refreshTick++
                                    Toast.makeText(context, t.unzipDoneMsg(count), Toast.LENGTH_SHORT).show()
                                }
                            }
                            zipViewerFile = null
                            zipViewerUri = null
                        }) { Text(t.zipExtractBtn) }
                    }
                },
                dismissButton = {
                    TextButton(onClick = { zipViewerFile = null; zipViewerUri = null }) { Text(t.cancelBtn) }
                }
            )
        }

        // Полноэкранный просмотрщик фото: максимальный размер, автопросмотр и лента миниатюр
        if (viewerImageFile != null || viewerExternalUri != null) {
            var isSlideshow by remember { mutableStateOf(false) }
            var showExifPanel by remember { mutableStateOf(false) }
            var showGeminiDialog by remember { mutableStateOf(false) }
            val exifSummary = remember(viewerImageFile) {
                val f = viewerImageFile ?: return@remember ""
                runCatching {
                    val exif = ExifInterface(f.absolutePath)
                    val sb = StringBuilder()
                    sb.append("Файл: ").append(f.name).append("\n")
                    exif.getAttribute(ExifInterface.TAG_DATETIME_ORIGINAL)?.let { sb.append("Дата: ").append(it).append("\n") }
                    val make = exif.getAttribute(ExifInterface.TAG_MAKE) ?: ""
                    val model = exif.getAttribute(ExifInterface.TAG_MODEL) ?: ""
                    if (make.isNotBlank() || model.isNotBlank()) sb.append("Камера: ").append("$make $model".trim()).append("\n")
                    val w = exif.getAttribute(ExifInterface.TAG_IMAGE_WIDTH)
                    val h = exif.getAttribute(ExifInterface.TAG_IMAGE_LENGTH)
                    if (!w.isNullOrBlank() && !h.isNullOrBlank()) sb.append("Размер: ").append("${w}x${h}").append("\n")
                    val fnum = exif.getAttribute(ExifInterface.TAG_F_NUMBER)
                    val exp = exif.getAttribute(ExifInterface.TAG_EXPOSURE_TIME)
                    val iso = exif.getAttribute(ExifInterface.TAG_ISO_SPEED_RATINGS)
                    val focal = exif.getAttribute(ExifInterface.TAG_FOCAL_LENGTH)
                    val params = listOfNotNull(
                        fnum?.let { "f/$it" },
                        exp?.let { "${it}s" },
                        iso?.let { "ISO $it" },
                        focal?.let { "${it}mm" }
                    )
                    if (params.isNotEmpty()) sb.append("Параметры: ").append(params.joinToString(", ")).append("\n")
                    val latLong = FloatArray(2)
                    @Suppress("DEPRECATION")
                    if (exif.getLatLong(latLong)) {
                        sb.append("GPS: ${latLong[0]}, ${latLong[1]}\n")
                        sb.append("Карта: https://maps.google.com/?q=${latLong[0]},${latLong[1]}\n")
                    }
                    sb.toString().trim()
                }.getOrDefault("Файл: ${f.name}")
            }
            BackHandler(enabled = true) {
                isSlideshow = false
                viewerImageFile = null
                viewerExternalUri = null
            }
            var scale by remember { mutableStateOf(1f) }
            var offset by remember { mutableStateOf(Offset.Zero) }
            val bitmap = remember(viewerImageFile, viewerExternalUri) {
                scale = 1f
                offset = Offset.Zero
                when {
                    viewerImageFile != null -> decodeSampledBitmap(viewerImageFile!!)
                    viewerExternalUri != null -> decodeSampledBitmapFromUri(context, viewerExternalUri!!)
                    else -> null
                }
            }
            val currentIdx = viewerImageFile?.let { f -> viewerImageGallery.indexOfFirst { it.absolutePath == f.absolutePath } } ?: -1
            val thumbListState = rememberLazyListState()

            LaunchedEffect(currentIdx) {
                if (currentIdx >= 0) {
                    runCatching { thumbListState.animateScrollToItem(currentIdx) }
                }
            }

            LaunchedEffect(isSlideshow, currentIdx, viewerImageGallery) {
                if (isSlideshow && viewerImageGallery.size > 1 && currentIdx >= 0) {
                    kotlinx.coroutines.delay(3000L)
                    val nextIdx = if (currentIdx < viewerImageGallery.lastIndex) currentIdx + 1 else 0
                    viewerImageFile = viewerImageGallery[nextIdx]
                }
            }

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black)
            ) {
                // Компактная верхняя панель (имя, автопросмотр, закрыть)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color.Black.copy(alpha = 0.75f))
                        .padding(horizontal = 10.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = viewerImageFile?.name ?: "Photo",
                        color = Color.White,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    if (viewerImageFile != null) {
                        IconButton(
                            onClick = { showExifPanel = !showExifPanel },
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(
                                Icons.Default.Info,
                                contentDescription = "EXIF",
                                tint = if (showExifPanel) BrandYellow else Color.White
                            )
                        }
                        IconButton(
                            onClick = { showGeminiDialog = true },
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(
                                Icons.Default.Share,
                                contentDescription = "Gemini EXIF",
                                tint = BrandYellow
                            )
                        }
                    }
                    if (viewerImageGallery.size > 1) {
                        IconButton(
                            onClick = { isSlideshow = !isSlideshow },
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(
                                imageVector = if (isSlideshow) Icons.Default.Pause else Icons.Default.PlayArrow,
                                contentDescription = "Slideshow",
                                tint = if (isSlideshow) BrandYellow else Color.White
                            )
                        }
                    }
                    IconButton(
                        onClick = {
                            isSlideshow = false
                            viewerImageFile = null
                            viewerExternalUri = null
                        },
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White)
                    }
                }

                // Максимально большая область самого фото + зум + листание короткими свайпами
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .pointerInput(viewerImageFile, viewerExternalUri, viewerImageGallery) {
                            detectTransformGestures { _, pan, zoom, _ ->
                                scale = (scale * zoom).coerceIn(1f, 5f)
                                if (scale > 1f) {
                                    offset += pan
                                } else {
                                    offset = Offset.Zero
                                }
                            }
                        }
                        .pointerInput(currentIdx, viewerImageGallery) {
                            var totalX = 0f
                            detectHorizontalDragGestures(
                                onDragStart = { totalX = 0f },
                                onHorizontalDrag = { _, dragAmount ->
                                    if (scale <= 1.05f) totalX += dragAmount
                                },
                                onDragEnd = {
                                    if (scale <= 1.05f && viewerImageGallery.size > 1 && currentIdx >= 0) {
                                        if (totalX < -50f && currentIdx < viewerImageGallery.lastIndex) {
                                            isSlideshow = false
                                            viewerImageFile = viewerImageGallery[currentIdx + 1]
                                        } else if (totalX > 50f && currentIdx > 0) {
                                            isSlideshow = false
                                            viewerImageFile = viewerImageGallery[currentIdx - 1]
                                        }
                                    }
                                }
                            )
                        }
                ) {
                    if (bitmap != null) {
                        Image(
                            bitmap = bitmap.asImageBitmap(),
                            contentDescription = viewerImageFile?.name,
                            contentScale = ContentScale.Fit,
                            modifier = Modifier
                                .fillMaxSize()
                                .graphicsLayer(
                                    scaleX = scale,
                                    scaleY = scale,
                                    translationX = offset.x,
                                    translationY = offset.y
                                )
                        )
                    }

                if (showExifPanel && exifSummary.isNotBlank()) {
                    Text(
                        text = exifSummary,
                        color = Color(0xFFEAEAF0),
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color(0xFF1A1A22).copy(alpha = 0.92f))
                            .padding(horizontal = 12.dp, vertical = 8.dp)
                    )
                }
                if (showGeminiDialog && viewerImageFile != null) {
                    var branchUrl by remember { mutableStateOf(KomandirPrefs.getGeminiBranchUrl(context)) }
                    AlertDialog(
                        onDismissRequest = { showGeminiDialog = false },
                        title = { Text("Фото с EXIF в Gemini", fontWeight = FontWeight.Bold) },
                        text = {
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedTextField(
                                    value = branchUrl,
                                    onValueChange = { branchUrl = it },
                                    label = { Text("Ссылка на ветку Gemini (опц.)") },
                                    placeholder = { Text("https://gemini.google.com/app/...") },
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth()
                                )
                                Text(
                                    text = exifSummary,
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        },
                        confirmButton = {
                            Button(onClick = {
                                KomandirPrefs.setGeminiBranchUrl(context, branchUrl)
                                val cm = context.getSystemService(ClipboardManager::class.java)
                                cm?.setPrimaryClip(ClipData.newPlainText("exif", exifSummary))
                                val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", viewerImageFile!!)
                                val sendIntent = Intent(Intent.ACTION_SEND).apply {
                                    type = "image/*"
                                    putExtra(Intent.EXTRA_STREAM, uri)
                                    putExtra(Intent.EXTRA_TEXT, exifSummary)
                                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                    setPackage("com.google.android.apps.bard")
                                }
                                runCatching { context.startActivity(sendIntent) }.onFailure {
                                    val fallback = Intent(sendIntent).apply { setPackage(null) }
                                    context.startActivity(Intent.createChooser(fallback, "Отправить фото с EXIF"))
                                }
                                showGeminiDialog = false
                            }) { Text("Отправить") }
                        },
                        dismissButton = {
                            Row {
                                if (branchUrl.isNotBlank()) {
                                    TextButton(onClick = {
                                        KomandirPrefs.setGeminiBranchUrl(context, branchUrl)
                                        val cm = context.getSystemService(ClipboardManager::class.java)
                                        cm?.setPrimaryClip(ClipData.newPlainText("exif", exifSummary))
                                        runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(branchUrl))) }
                                        Toast.makeText(context, "EXIF скопирован, открываю ветку", Toast.LENGTH_SHORT).show()
                                        showGeminiDialog = false
                                    }) { Text("Открыть ветку") }
                                }
                                TextButton(onClick = { showGeminiDialog = false }) { Text(t.cancelBtn) }
                            }
                        }
                    )
                }
                    if (viewerImageGallery.size > 1 && currentIdx >= 0) {
                        IconButton(
                            enabled = currentIdx > 0,
                            onClick = {
                                isSlideshow = false
                                if (currentIdx > 0) viewerImageFile = viewerImageGallery[currentIdx - 1]
                            },
                            modifier = Modifier
                                .align(Alignment.CenterStart)
                                .padding(start = 4.dp)
                                .background(Color.Black.copy(alpha = 0.4f), RoundedCornerShape(50))
                        ) {
                            Icon(
                                Icons.Default.ArrowBack,
                                contentDescription = "Prev",
                                tint = if (currentIdx > 0) Color.White else Color.Gray
                            )
                        }
                        IconButton(
                            enabled = currentIdx < viewerImageGallery.lastIndex,
                            onClick = {
                                isSlideshow = false
                                if (currentIdx < viewerImageGallery.lastIndex) viewerImageFile = viewerImageGallery[currentIdx + 1]
                            },
                            modifier = Modifier
                                .align(Alignment.CenterEnd)
                                .padding(end = 4.dp)
                                .background(Color.Black.copy(alpha = 0.4f), RoundedCornerShape(50))
                        ) {
                            Icon(
                                Icons.Default.ArrowForward,
                                contentDescription = "Next",
                                tint = if (currentIdx < viewerImageGallery.lastIndex) Color.White else Color.Gray
                            )
                        }
                    }
                }

                // Нижняя лента мини-фоток с прокруткой
                if (viewerImageGallery.size > 1 && currentIdx >= 0) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color.Black.copy(alpha = 0.85f))
                            .padding(vertical = 6.dp)
                    ) {
                        LazyRow(
                            state = thumbListState,
                            contentPadding = PaddingValues(horizontal = 8.dp),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            itemsIndexed(viewerImageGallery, key = { _, f -> f.absolutePath }) { idx, imgFile ->
                                val isCurrent = idx == currentIdx
                                var thumb by remember(imgFile.absolutePath) { mutableStateOf<android.graphics.Bitmap?>(null) }
                                LaunchedEffect(imgFile.absolutePath) {
                                    thumb = withContext(Dispatchers.IO) {
                                        decodeSampledBitmap(imgFile, maxDim = 180)
                                    }
                                }
                                Box(
                                    modifier = Modifier
                                        .size(56.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                        .border(
                                            width = if (isCurrent) 2.dp else 1.dp,
                                            color = if (isCurrent) BrandYellow else Color.White.copy(alpha = 0.25f),
                                            shape = RoundedCornerShape(8.dp)
                                        )
                                        .clickable {
                                            isSlideshow = false
                                            viewerImageFile = imgFile
                                        }
                                ) {
                                    if (thumb != null) {
                                        Image(
                                            bitmap = thumb!!.asImageBitmap(),
                                            contentDescription = imgFile.name,
                                            contentScale = ContentScale.Crop,
                                            modifier = Modifier.fillMaxSize()
                                        )
                                    }
                                }
                            }
                        }
                        Text(
                            text = "${currentIdx + 1} / ${viewerImageGallery.size}",
                            color = Color.White.copy(alpha = 0.75f),
                            fontSize = 11.sp,
                            modifier = Modifier
                                .align(Alignment.CenterHorizontally)
                                .padding(top = 4.dp)
                        )
                    }
                }
            }
        }

        // Полноэкранный просмотрщик видео (встроенный, иммерсивный)
        if (viewerVideoFile != null || viewerExternalVideoUri != null) {
            var videoViewRef by remember { mutableStateOf<VideoView?>(null) }
            var isPlaying by remember { mutableStateOf(true) }
            var durationMs by remember { mutableIntStateOf(0) }
            var positionMs by remember { mutableIntStateOf(0) }
            var videoError by remember { mutableStateOf<String?>(null) }
            var loadedKey by remember { mutableStateOf<String?>(null) }
            var showControls by remember { mutableStateOf(true) }

            DisposableEffect(Unit) {
                val window = (context as? Activity)?.window
                val controller = window?.let { WindowCompat.getInsetsController(it, it.decorView) }
                controller?.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                controller?.hide(WindowInsetsCompat.Type.systemBars())
                onDispose {
                    controller?.show(WindowInsetsCompat.Type.systemBars())
                }
            }

            BackHandler(enabled = true) {
                runCatching { videoViewRef?.stopPlayback() }
                viewerVideoFile = null
                viewerExternalVideoUri = null
            }

            val currentVideoIdx = viewerVideoFile?.let { f ->
                viewerVideoGallery.indexOfFirst { it.absolutePath == f.absolutePath }
            } ?: -1

            LaunchedEffect(showControls, isPlaying) {
                if (showControls && isPlaying) {
                    kotlinx.coroutines.delay(3000L)
                    showControls = false
                }
            }

            LaunchedEffect(isPlaying, viewerVideoFile, viewerExternalVideoUri) {
                while (true) {
                    val vv = videoViewRef
                    if (vv != null) {
                        runCatching {
                            if (vv.duration > 0) durationMs = vv.duration
                            positionMs = vv.currentPosition
                            isPlaying = vv.isPlaying
                        }
                    }
                    kotlinx.coroutines.delay(300L)
                }
            }

            fun formatVideoTime(ms: Int): String {
                val totalSec = (ms / 1000).coerceAtLeast(0)
                val hrs = totalSec / 3600
                val min = (totalSec % 3600) / 60
                val sec = totalSec % 60
                return if (hrs > 0) String.format("%d:%02d:%02d", hrs, min, sec)
                else String.format("%02d:%02d", min, sec)
            }

            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black)
                    .clickable { showControls = !showControls }
            ) {
                val targetUri: Uri? = when {
                    viewerVideoFile != null -> Uri.fromFile(viewerVideoFile!!)
                    else -> viewerExternalVideoUri
                }
                val targetKey = targetUri?.toString() ?: ""

                AndroidView(
                    factory = { ctx ->
                        val container = FrameLayout(ctx).apply {
                            layoutParams = ViewGroup.LayoutParams(
                                ViewGroup.LayoutParams.MATCH_PARENT,
                                ViewGroup.LayoutParams.MATCH_PARENT
                            )
                        }
                        val vv = VideoView(ctx).apply {
                            layoutParams = FrameLayout.LayoutParams(
                                ViewGroup.LayoutParams.MATCH_PARENT,
                                ViewGroup.LayoutParams.MATCH_PARENT,
                                Gravity.CENTER
                            )
                            setOnPreparedListener { mp ->
                                mp.isLooping = false
                                durationMs = duration.coerceAtLeast(0)
                                videoError = null
                                start()
                                isPlaying = true
                            }
                            setOnCompletionListener {
                                isPlaying = false
                                showControls = true
                                positionMs = durationMs
                            }
                            setOnErrorListener { _, what, extra ->
                                videoError = "Ошибка воспроизведения ($what / $extra)"
                                isPlaying = false
                                showControls = true
                                true
                            }
                        }
                        container.addView(vv)
                        videoViewRef = vv
                        container
                    },
                    update = { container ->
                        val vv = container.getChildAt(0) as? VideoView ?: return@AndroidView
                        videoViewRef = vv
                        if (targetUri != null && loadedKey != targetKey) {
                            loadedKey = targetKey
                            durationMs = 0
                            positionMs = 0
                            videoError = null
                            vv.setVideoURI(targetUri)
                        }
                    },
                    modifier = Modifier.fillMaxSize()
                )

                if (videoError != null) {
                    Text(
                        text = videoError!!,
                        color = Color(0xFFFF6B6B),
                        fontSize = 14.sp,
                        modifier = Modifier
                            .align(Alignment.Center)
                            .background(Color.Black.copy(alpha = 0.7f), RoundedCornerShape(8.dp))
                            .padding(12.dp)
                    )
                }

                if (showControls) {
                    Row(
                        modifier = Modifier
                            .align(Alignment.TopCenter)
                            .fillMaxWidth()
                            .background(Color.Black.copy(alpha = 0.65f))
                            .padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = viewerVideoFile?.name ?: "Video",
                            color = Color.White,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f)
                        )
                        if (viewerVideoGallery.size > 1 && currentVideoIdx >= 0) {
                            Text(
                                text = "${currentVideoIdx + 1}/${viewerVideoGallery.size}",
                                color = Color.White.copy(alpha = 0.75f),
                                fontSize = 12.sp,
                                modifier = Modifier.padding(horizontal = 8.dp)
                            )
                        }
                        IconButton(
                            onClick = {
                                runCatching { videoViewRef?.stopPlayback() }
                                viewerVideoFile = null
                                viewerExternalVideoUri = null
                            },
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White)
                        }
                    }

                    Column(
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .fillMaxWidth()
                            .background(Color.Black.copy(alpha = 0.65f))
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = formatVideoTime(positionMs),
                                color = Color.White,
                                fontSize = 11.sp
                            )
                            Slider(
                                value = if (durationMs > 0) (positionMs.toFloat() / durationMs.toFloat()).coerceIn(0f, 1f) else 0f,
                                onValueChange = { frac ->
                                    if (durationMs > 0) {
                                        val target = (frac * durationMs).toInt()
                                        positionMs = target
                                        videoViewRef?.seekTo(target)
                                    }
                                },
                                colors = SliderDefaults.colors(
                                    thumbColor = BrandYellow,
                                    activeTrackColor = BrandYellow,
                                    inactiveTrackColor = Color.White.copy(alpha = 0.3f)
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .padding(horizontal = 8.dp)
                            )
                            Text(
                                text = formatVideoTime(durationMs),
                                color = Color.White,
                                fontSize = 11.sp
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            if (viewerVideoGallery.size > 1 && currentVideoIdx >= 0) {
                                IconButton(
                                    enabled = currentVideoIdx > 0,
                                    onClick = {
                                        if (currentVideoIdx > 0) {
                                            viewerVideoFile = viewerVideoGallery[currentVideoIdx - 1]
                                        }
                                    }
                                ) {
                                    Icon(
                                        Icons.Default.ArrowBack,
                                        contentDescription = "Prev Video",
                                        tint = if (currentVideoIdx > 0) Color.White else Color.Gray
                                    )
                                }
                            }
                            IconButton(
                                onClick = {
                                    val vv = videoViewRef ?: return@IconButton
                                    if (vv.isPlaying) {
                                        vv.pause()
                                        isPlaying = false
                                    } else {
                                        vv.start()
                                        isPlaying = true
                                    }
                                }
                            ) {
                                Icon(
                                    imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                    contentDescription = "Play/Pause",
                                    tint = BrandYellow,
                                    modifier = Modifier.size(32.dp)
                                )
                            }
                            if (viewerVideoGallery.size > 1 && currentVideoIdx >= 0) {
                                IconButton(
                                    enabled = currentVideoIdx < viewerVideoGallery.lastIndex,
                                    onClick = {
                                        if (currentVideoIdx < viewerVideoGallery.lastIndex) {
                                            viewerVideoFile = viewerVideoGallery[currentVideoIdx + 1]
                                        }
                                    }
                                ) {
                                    Icon(
                                        Icons.Default.ArrowForward,
                                        contentDescription = "Next Video",
                                        tint = if (currentVideoIdx < viewerVideoGallery.lastIndex) Color.White else Color.Gray
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Полноэкранный просмотрщик PDF (встроенный PdfRenderer)
        if (viewerPdfFile != null || viewerExternalPdfUri != null) {
            var pageIndex by remember(viewerPdfFile, viewerExternalPdfUri) { mutableIntStateOf(0) }
            var pageCount by remember(viewerPdfFile, viewerExternalPdfUri) { mutableIntStateOf(0) }
            var pdfBitmap by remember { mutableStateOf<Bitmap?>(null) }
            var pdfError by remember { mutableStateOf<String?>(null) }
            var pdfScale by remember { mutableStateOf(1f) }
            var pdfOffset by remember { mutableStateOf(Offset.Zero) }

            BackHandler(enabled = true) {
                viewerPdfFile = null
                viewerExternalPdfUri = null
            }

            DisposableEffect(viewerPdfFile, viewerExternalPdfUri, pageIndex) {
                var pfd: ParcelFileDescriptor? = null
                var renderer: PdfRenderer? = null
                runCatching {
                    pfd = when {
                        viewerPdfFile != null -> ParcelFileDescriptor.open(viewerPdfFile!!, ParcelFileDescriptor.MODE_READ_ONLY)
                        viewerExternalPdfUri != null -> context.contentResolver.openFileDescriptor(viewerExternalPdfUri!!, "r")
                        else -> null
                    }
                    if (pfd != null) {
                        renderer = PdfRenderer(pfd!!)
                        val count = renderer!!.pageCount
                        pageCount = count
                        if (count > 0) {
                            val safeIdx = pageIndex.coerceIn(0, count - 1)
                            if (safeIdx != pageIndex) pageIndex = safeIdx
                            renderer!!.openPage(safeIdx).use { page ->
                                val targetWidth = 1400
                                val targetHeight = (page.height.toFloat() / page.width.coerceAtLeast(1) * targetWidth).toInt().coerceAtLeast(1)
                                val bmp = Bitmap.createBitmap(targetWidth, targetHeight, Bitmap.Config.ARGB_8888)
                                val canvas = Canvas(bmp)
                                canvas.drawColor(android.graphics.Color.WHITE)
                                page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                                pdfBitmap = bmp
                            }
                        }
                        pdfError = null
                    }
                }.onFailure { err ->
                    pdfError = err.message ?: "Ошибка открытия PDF"
                }
                pdfScale = 1f
                pdfOffset = Offset.Zero
                onDispose {
                    runCatching { renderer?.close() }
                    runCatching { pfd?.close() }
                }
            }

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xFF141418))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color.Black.copy(alpha = 0.85f))
                        .padding(horizontal = 10.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = viewerPdfFile?.name ?: "PDF",
                        color = Color.White,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    if (pageCount > 0) {
                        Text(
                            text = "${pageIndex + 1} / $pageCount",
                            color = BrandYellow,
                            fontSize = 12.sp,
                            modifier = Modifier.padding(horizontal = 8.dp)
                        )
                    }
                    IconButton(
                        onClick = {
                            viewerPdfFile = null
                            viewerExternalPdfUri = null
                        },
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White)
                    }
                }

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .pointerInput(viewerPdfFile, viewerExternalPdfUri, pageIndex) {
                            detectTransformGestures { _, pan, zoom, _ ->
                                val newScale = (pdfScale * zoom).coerceIn(1f, 5f)
                                pdfScale = newScale
                                pdfOffset = if (newScale > 1.01f) pdfOffset + pan else Offset.Zero
                            }
                        }
                        .pointerInput(pageIndex, pageCount) {
                            var totalX = 0f
                            detectHorizontalDragGestures(
                                onDragStart = { totalX = 0f },
                                onHorizontalDrag = { _, dragAmount -> totalX += dragAmount },
                                onDragEnd = {
                                    if (pdfScale <= 1.05f && pageCount > 1) {
                                        if (totalX < -50f && pageIndex < pageCount - 1) pageIndex++
                                        else if (totalX > 50f && pageIndex > 0) pageIndex--
                                    }
                                }
                            )
                        },
                    contentAlignment = Alignment.Center
                ) {
                    if (pdfError != null) {
                        Text(text = pdfError!!, color = Color(0xFFFF6B6B), fontSize = 14.sp, modifier = Modifier.padding(16.dp))
                    } else if (pdfBitmap != null) {
                        Image(
                            bitmap = pdfBitmap!!.asImageBitmap(),
                            contentDescription = "PDF Page",
                            contentScale = ContentScale.Fit,
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(4.dp)
                                .graphicsLayer(
                                    scaleX = pdfScale,
                                    scaleY = pdfScale,
                                    translationX = pdfOffset.x,
                                    translationY = pdfOffset.y
                                )
                        )
                    }
                }

                if (pageCount > 1) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color.Black.copy(alpha = 0.85f))
                            .padding(horizontal = 12.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            enabled = pageIndex > 0,
                            onClick = { if (pageIndex > 0) pageIndex-- }
                        ) {
                            Icon(Icons.Default.ArrowBack, contentDescription = "Prev Page", tint = if (pageIndex > 0) Color.White else Color.Gray)
                        }
                        Text(
                            text = "${pageIndex + 1} / $pageCount",
                            color = Color.White,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium
                        )
                        IconButton(
                            enabled = pageIndex < pageCount - 1,
                            onClick = { if (pageIndex < pageCount - 1) pageIndex++ }
                        ) {
                            Icon(Icons.Default.ArrowForward, contentDescription = "Next Page", tint = if (pageIndex < pageCount - 1) Color.White else Color.Gray)
                        }
                    }
                }
            }
        }

        // Встроенный аудиоплеер (MediaPlayer)
        if (viewerAudioFile != null || viewerExternalAudioUri != null) {
            var mediaPlayerRef by remember { mutableStateOf<MediaPlayer?>(null) }
            var isAudioPlaying by remember { mutableStateOf(false) }
            var audioDurationMs by remember { mutableIntStateOf(0) }
            var audioPositionMs by remember { mutableIntStateOf(0) }
            var audioError by remember { mutableStateOf<String?>(null) }

            BackHandler(enabled = true) {
                runCatching {
                    mediaPlayerRef?.stop()
                    mediaPlayerRef?.release()
                }
                mediaPlayerRef = null
                viewerAudioFile = null
                viewerExternalAudioUri = null
            }

            val currentAudioIdx = viewerAudioFile?.let { f ->
                viewerAudioGallery.indexOfFirst { it.absolutePath == f.absolutePath }
            } ?: -1

            DisposableEffect(viewerAudioFile, viewerExternalAudioUri) {
                val mp = MediaPlayer()
                mediaPlayerRef = mp
                audioError = null
                audioDurationMs = 0
                audioPositionMs = 0
                runCatching {
                    when {
                        viewerAudioFile != null -> mp.setDataSource(viewerAudioFile!!.absolutePath)
                        viewerExternalAudioUri != null -> mp.setDataSource(context, viewerExternalAudioUri!!)
                    }
                    mp.setOnPreparedListener { player ->
                        audioDurationMs = player.duration.coerceAtLeast(0)
                        player.start()
                        isAudioPlaying = true
                    }
                    mp.setOnCompletionListener {
                        isAudioPlaying = false
                        if (viewerAudioGallery.size > 1 && currentAudioIdx in 0 until viewerAudioGallery.lastIndex) {
                            viewerAudioFile = viewerAudioGallery[currentAudioIdx + 1]
                        }
                    }
                    mp.setOnErrorListener { _, what, extra ->
                        audioError = "Ошибка аудио ($what / $extra)"
                        isAudioPlaying = false
                        true
                    }
                    mp.prepareAsync()
                }.onFailure { err ->
                    audioError = err.message ?: "Не удалось открыть аудио"
                }
                onDispose {
                    runCatching {
                        mp.stop()
                        mp.release()
                    }
                    if (mediaPlayerRef == mp) mediaPlayerRef = null
                }
            }

            LaunchedEffect(isAudioPlaying, mediaPlayerRef) {
                while (true) {
                    val mp = mediaPlayerRef
                    if (mp != null) {
                        runCatching {
                            if (mp.isPlaying) {
                                audioPositionMs = mp.currentPosition
                                if (mp.duration > 0) audioDurationMs = mp.duration
                            }
                            isAudioPlaying = mp.isPlaying
                        }
                    }
                    kotlinx.coroutines.delay(300L)
                }
            }

            fun formatAudioTime(ms: Int): String {
                val totalSec = (ms / 1000).coerceAtLeast(0)
                val min = totalSec / 60
                val sec = totalSec % 60
                return String.format("%02d:%02d", min, sec)
            }

            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.78f))
                    .clickable(enabled = false) {},
                contentAlignment = Alignment.Center
            ) {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = Color(0xFF1E1E24),
                    border = BorderStroke(1.dp, BrandBlue.copy(alpha = 0.6f)),
                    modifier = Modifier
                        .fillMaxWidth(0.92f)
                        .padding(16.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                Icon(Icons.Default.Audiotrack, contentDescription = null, tint = BrandYellow)
                                Spacer(Modifier.width(8.dp))
                                Text(
                                    text = viewerAudioFile?.name ?: "Audio",
                                    color = Color.White,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            IconButton(
                                onClick = {
                                    runCatching {
                                        mediaPlayerRef?.stop()
                                        mediaPlayerRef?.release()
                                    }
                                    mediaPlayerRef = null
                                    viewerAudioFile = null
                                    viewerExternalAudioUri = null
                                }
                            ) {
                                Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White)
                            }
                        }

                        if (viewerAudioGallery.size > 1 && currentAudioIdx >= 0) {
                            Text(
                                text = "${currentAudioIdx + 1} / ${viewerAudioGallery.size}",
                                color = Color.White.copy(alpha = 0.65f),
                                fontSize = 12.sp,
                                modifier = Modifier.padding(top = 2.dp)
                            )
                        }

                        if (audioError != null) {
                            Text(text = audioError!!, color = Color(0xFFFF6B6B), fontSize = 13.sp, modifier = Modifier.padding(vertical = 8.dp))
                        }

                        Spacer(Modifier.height(10.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(text = formatAudioTime(audioPositionMs), color = Color.White, fontSize = 11.sp)
                            Slider(
                                value = if (audioDurationMs > 0) (audioPositionMs.toFloat() / audioDurationMs.toFloat()).coerceIn(0f, 1f) else 0f,
                                onValueChange = { frac ->
                                    if (audioDurationMs > 0) {
                                        val target = (frac * audioDurationMs).toInt()
                                        audioPositionMs = target
                                        runCatching { mediaPlayerRef?.seekTo(target) }
                                    }
                                },
                                colors = SliderDefaults.colors(
                                    thumbColor = BrandYellow,
                                    activeTrackColor = BrandYellow,
                                    inactiveTrackColor = Color.White.copy(alpha = 0.25f)
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .padding(horizontal = 8.dp)
                            )
                            Text(text = formatAudioTime(audioDurationMs), color = Color.White, fontSize = 11.sp)
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            if (viewerAudioGallery.size > 1 && currentAudioIdx >= 0) {
                                IconButton(
                                    enabled = currentAudioIdx > 0,
                                    onClick = { if (currentAudioIdx > 0) viewerAudioFile = viewerAudioGallery[currentAudioIdx - 1] }
                                ) {
                                    Icon(Icons.Default.ArrowBack, contentDescription = "Prev", tint = if (currentAudioIdx > 0) Color.White else Color.Gray)
                                }
                            }
                            IconButton(
                                onClick = {
                                    val mp = mediaPlayerRef ?: return@IconButton
                                    runCatching {
                                        if (mp.isPlaying) {
                                            mp.pause()
                                            isAudioPlaying = false
                                        } else {
                                            mp.start()
                                            isAudioPlaying = true
                                        }
                                    }
                                }
                            ) {
                                Icon(
                                    imageVector = if (isAudioPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                    contentDescription = "Play/Pause",
                                    tint = BrandYellow,
                                    modifier = Modifier.size(36.dp)
                                )
                            }
                            if (viewerAudioGallery.size > 1 && currentAudioIdx >= 0) {
                                IconButton(
                                    enabled = currentAudioIdx < viewerAudioGallery.lastIndex,
                                    onClick = { if (currentAudioIdx < viewerAudioGallery.lastIndex) viewerAudioFile = viewerAudioGallery[currentAudioIdx + 1] }
                                ) {
                                    Icon(Icons.Default.ArrowForward, contentDescription = "Next", tint = if (currentAudioIdx < viewerAudioGallery.lastIndex) Color.White else Color.Gray)
                                }
                            }
                        }
                    }
                }
            }
        }

        // Встроенный просмотрщик и редактор текста / кода
        if (viewerTextFile != null || viewerExternalTextUri != null) {
            var isEditMode by remember(viewerTextFile, viewerExternalTextUri) { mutableStateOf(false) }
            var textContent by remember(viewerTextFile, viewerExternalTextUri) { mutableStateOf("") }
            var isTruncated by remember(viewerTextFile, viewerExternalTextUri) { mutableStateOf(false) }

            LaunchedEffect(viewerTextFile, viewerExternalTextUri) {
                runCatching {
                    val maxBytes = 512 * 1024
                    val rawBytes = when {
                        viewerTextFile != null -> {
                            val f = viewerTextFile!!
                            if (f.length() > maxBytes) {
                                isTruncated = true
                                f.inputStream().use { it.readNBytes(maxBytes) }
                            } else {
                                f.readBytes()
                            }
                        }
                        viewerExternalTextUri != null -> {
                            context.contentResolver.openInputStream(viewerExternalTextUri!!)?.use {
                                val buf = it.readNBytes(maxBytes + 1)
                                if (buf.size > maxBytes) {
                                    isTruncated = true
                                    buf.copyOf(maxBytes)
                                } else buf
                            } ?: ByteArray(0)
                        }
                        else -> ByteArray(0)
                    }
                    textContent = rawBytes.toString(Charsets.UTF_8)
                }.onFailure { err ->
                    textContent = "Ошибка чтения: ${err.message}"
                }
            }

            BackHandler(enabled = true) {
                viewerTextFile = null
                viewerExternalTextUri = null
            }

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xFF141418))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color.Black.copy(alpha = 0.85f))
                        .padding(horizontal = 10.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = viewerTextFile?.name ?: "Text",
                        color = Color.White,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    if (viewerTextFile != null) {
                        TextButton(
                            onClick = {
                                viewerHexFile = viewerTextFile
                                viewerTextFile = null
                            }
                        ) {
                            Text("HEX", color = BrandYellow, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    IconButton(
                        onClick = {
                            val cm = context.getSystemService(ClipboardManager::class.java)
                            cm?.setPrimaryClip(ClipData.newPlainText("komandir_text", textContent))
                            Toast.makeText(context, "Скопировано", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(Icons.Default.ContentCopy, contentDescription = "Copy", tint = Color.White)
                    }
                    if (viewerTextFile != null && !isTruncated) {
                        if (isEditMode) {
                            IconButton(
                                onClick = {
                                    runCatching {
                                        viewerTextFile!!.writeText(textContent, Charsets.UTF_8)
                                        isEditMode = false
                                        refreshTick++
                                        Toast.makeText(context, "Сохранено", Toast.LENGTH_SHORT).show()
                                    }.onFailure {
                                        Toast.makeText(context, "Ошибка сохранения: ${it.message}", Toast.LENGTH_SHORT).show()
                                    }
                                },
                                modifier = Modifier.size(36.dp)
                            ) {
                                Icon(Icons.Default.Save, contentDescription = "Save", tint = BrandYellow)
                            }
                        } else {
                            IconButton(
                                onClick = { isEditMode = true },
                                modifier = Modifier.size(36.dp)
                            ) {
                                Icon(Icons.Default.Edit, contentDescription = "Edit", tint = Color.White)
                            }
                        }
                    }
                    IconButton(
                        onClick = {
                            viewerTextFile = null
                            viewerExternalTextUri = null
                        },
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White)
                    }
                }

                if (isTruncated) {
                    Text(
                        text = "Показаны первые 512 КБ файла",
                        color = BrandYellow,
                        fontSize = 11.sp,
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color(0xFF23232B))
                            .padding(horizontal = 12.dp, vertical = 4.dp)
                    )
                }

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .padding(10.dp)
                        .verticalScroll(rememberScrollState())
                ) {
                    if (isEditMode) {
                        OutlinedTextField(
                            value = textContent,
                            onValueChange = { textContent = it },
                            textStyle = androidx.compose.ui.text.TextStyle(
                                color = Color(0xFFE8E8EE),
                                fontSize = 13.sp,
                                fontFamily = FontFamily.Monospace
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )
                    } else {
                        SelectionContainer {
                            Text(
                                text = textContent,
                                color = Color(0xFFE8E8EE),
                                fontSize = 13.sp,
                                fontFamily = FontFamily.Monospace,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                }
            }
        }

        // Встроенный просмотрщик HTML и SVG (WebView)
        if (viewerHtmlFile != null || viewerExternalHtmlUri != null) {
            BackHandler(enabled = true) {
                viewerHtmlFile = null
                viewerExternalHtmlUri = null
            }

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color.Black.copy(alpha = 0.85f))
                        .padding(horizontal = 10.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = viewerHtmlFile?.name ?: "Web / SVG",
                        color = Color.White,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(
                        onClick = {
                            viewerHtmlFile = null
                            viewerExternalHtmlUri = null
                        },
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White)
                    }
                }

                val targetUrl = when {
                    viewerHtmlFile != null -> Uri.fromFile(viewerHtmlFile!!).toString()
                    else -> viewerExternalHtmlUri?.toString()
                }
                AndroidView(
                    factory = { ctx ->
                        WebView(ctx).apply {
                            webViewClient = WebViewClient()
                            settings.allowFileAccess = true
                            settings.builtInZoomControls = true
                            settings.displayZoomControls = false
                            settings.useWideViewPort = true
                            settings.loadWithOverviewMode = true
                            if (targetUrl != null) loadUrl(targetUrl)
                        }
                    },
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                )
            }
        }

        // Приём файлов через системное меню «Поделиться» (ACTION_SEND / SEND_MULTIPLE)
        if (incomingShareUris.isNotEmpty()) {
            fun saveSharedTo(destDir: File) {
                val urisToSave = incomingShareUris.toList()
                scope.launch(Dispatchers.IO) {
                    if (!destDir.exists()) destDir.mkdirs()
                    var saved = 0
                    urisToSave.forEach { u ->
                        var resolved: String? = null
                        runCatching {
                            context.contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                                if (c.moveToFirst()) resolved = c.getString(0)
                            }
                        }
                        val fname = resolved ?: u.lastPathSegment ?: "shared_${System.currentTimeMillis()}"
                        val target = File(destDir, fname)
                        runCatching {
                            context.contentResolver.openInputStream(u)?.use { inp ->
                                target.outputStream().use { out -> inp.copyTo(out) }
                            }
                            saved++
                        }
                    }
                    withContext(Dispatchers.Main) {
                        refreshTick++
                        Toast.makeText(context, "Сохранено файлов: $saved", Toast.LENGTH_SHORT).show()
                    }
                }
                onShareHandled()
            }

            AlertDialog(
                onDismissRequest = onShareHandled,
                title = { Text("Сохранить в Komandir", fontWeight = FontWeight.Bold) },
                text = {
                    Text("Получено файлов: ${incomingShareUris.size}. Куда сохранить?")
                },
                confirmButton = {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = {
                            saveSharedTo(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS))
                        }) { Text("В Загрузки") }
                        Button(onClick = {
                            val activeDir = if (activePane == 0) leftPath else rightPath
                            val activeKind = if (activePane == 0) leftSource.kind else rightSource.kind
                            val dest = if (activeKind == StorageKind.LOCAL) File(activeDir)
                            else Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                            saveSharedTo(dest)
                        }) { Text("В папку") }
                    }
                },
                dismissButton = {
                    TextButton(onClick = onShareHandled) { Text(t.cancelBtn) }
                }
            )
        }

        // Встроенный HEX-просмотрщик файлов (постранично по 4 КБ)
        if (viewerHexFile != null) {
            val hexFile = viewerHexFile!!
            val pageSize = 4096
            var hexPage by remember(hexFile) { mutableIntStateOf(0) }
            val totalPages = ((hexFile.length() + pageSize - 1) / pageSize).toInt().coerceAtLeast(1)
            val hexDump = remember(hexFile, hexPage) {
                runCatching {
                    val raf = java.io.RandomAccessFile(hexFile, "r")
                    raf.use { r ->
                        val offset = hexPage.toLong() * pageSize
                        r.seek(offset)
                        val buf = ByteArray(pageSize)
                        val read = r.read(buf).coerceAtLeast(0)
                        val sb = StringBuilder()
                        var i = 0
                        while (i < read) {
                            sb.append(String.format("%06X: ", offset + i))
                            val ascii = StringBuilder()
                            for (j in 0 until 16) {
                                if (i + j < read) {
                                    val b = buf[i + j].toInt() and 0xFF
                                    sb.append(String.format("%02X ", b))
                                    ascii.append(if (b in 32..126) b.toChar() else .)
                                } else {
                                    sb.append("   ")
                                }
                            }
                            sb.append("| ").append(ascii).append("\n")
                            i += 16
                        }
                        sb.toString()
                    }
                }.getOrElse { "Ошибка чтения HEX: ${it.message}" }
            }

            BackHandler(enabled = true) { viewerHexFile = null }

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xFF101216))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color.Black.copy(alpha = 0.85f))
                        .padding(horizontal = 10.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "HEX: ${hexFile.name}",
                        color = BrandYellow,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(onClick = { viewerHexFile = null }, modifier = Modifier.size(36.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White)
                    }
                }
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .padding(8.dp)
                        .verticalScroll(rememberScrollState())
                ) {
                    SelectionContainer {
                        Text(
                            text = hexDump,
                            color = Color(0xFFD8E2EE),
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
                if (totalPages > 1) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color.Black.copy(alpha = 0.85f))
                            .padding(horizontal = 12.dp, vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(enabled = hexPage > 0, onClick = { if (hexPage > 0) hexPage-- }) {
                            Icon(Icons.Default.ArrowBack, contentDescription = "Prev", tint = if (hexPage > 0) Color.White else Color.Gray)
                        }
                        Text("${hexPage + 1} / $totalPages", color = Color.White, fontSize = 12.sp)
                        IconButton(enabled = hexPage < totalPages - 1, onClick = { if (hexPage < totalPages - 1) hexPage++ }) {
                            Icon(Icons.Default.ArrowForward, contentDescription = "Next", tint = if (hexPage < totalPages - 1) Color.White else Color.Gray)
                        }
                    }
                }
            }
        }

        if (draggingFromPane != null && draggingItems.isNotEmpty()) {
            val label = if (draggingItems.size == 1) draggingItems.first().name else "${draggingItems.size} items"
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = BrandBlue,
                shadowElevation = 8.dp,
                modifier = Modifier.offset {
                    IntOffset(
                        (dragPointerRoot.x - 80f).roundToInt(),
                        (dragPointerRoot.y - 60f).roundToInt()
                    )
                }
            ) {
                Text(
                    text = label,
                    color = Color.White,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                )
            }
        }
        }
    }
}

@Composable
private fun KomandirHeader(
    versionCode: Int,
    dualPane: Boolean,
    onVersionClick: () -> Unit,
    onToggleDualPane: () -> Unit,
    onToggleSearch: () -> Unit,
    onOpenSettings: () -> Unit
) {
    // Сине-жёлтая переливающаяся заливка (как в MedAssist)
    val baseTextColor = MaterialTheme.colorScheme.onSurface
    val transition = rememberInfiniteTransition(label = "medAssistShimmer")
    val shift by transition.animateFloat(
        initialValue = -300f,
        targetValue = 900f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 12000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "shift"
    )
    val shimmerBrush = Brush.linearGradient(
        colors = listOf(baseTextColor, baseTextColor, BrandBlue, BrandYellow, BrandBlue, baseTextColor, baseTextColor),
        start = Offset(shift - 220f, 0f),
        end = Offset(shift + 120f, 80f)
    )
    val logoBrush = Brush.linearGradient(
        colors = listOf(BrandBlue, BrandBlue, BrandYellow, BrandBlue),
        start = Offset(shift - 220f, 0f),
        end = Offset(shift + 120f, 80f)
    )

    Surface(
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 2.dp
    ) {
        Column {
            HorizontalDivider(thickness = 0.5.dp)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(24.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(logoBrush),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.ViewColumn,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(15.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "Komandir",
                            style = TextStyle(
                                brush = shimmerBrush,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold
                            )
                        )
                        Spacer(modifier = Modifier.width(3.dp))
                        Text(
                            text = "v$versionCode by mizgiroff",
                            style = TextStyle(
                                brush = shimmerBrush,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Medium
                            ),
                            maxLines = 1,
                            modifier = Modifier
                                .offset(y = (-5).dp)
                                .clickable { onVersionClick() }
                        )
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onToggleDualPane, modifier = Modifier.size(34.dp)) {
                        Icon(
                            imageVector = Icons.Default.ViewColumn,
                            contentDescription = "Dual Pane",
                            modifier = Modifier.size(20.dp),
                            tint = if (dualPane) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                        )
                    }
                    IconButton(onClick = onToggleSearch, modifier = Modifier.size(34.dp)) {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = "Search",
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    IconButton(onClick = onOpenSettings, modifier = Modifier.size(34.dp)) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = "Settings",
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun FilePaneView(
    modifier: Modifier,
    source: StorageSource,
    currentPath: String,
    selectedIds: Set<String>,
    isActive: Boolean,
    isDropTarget: Boolean,
    dualPane: Boolean,
    searchQuery: String,
    hasPermission: Boolean,
    refreshTick: Int,
    strings: UiStrings,
    onActivate: () -> Unit,
    onEntriesLoaded: (List<FileEntry>) -> Unit = {},
    onRequestPermission: () -> Unit,
    onDragStart: (List<FileEntry>, Offset) -> Unit,
    onDragMove: (Offset) -> Unit,
    onDragEnd: () -> Unit,
    onNavigate: (String) -> Unit,
    onToggleSelect: (String) -> Unit,
    onOpenFile: (FileEntry) -> Unit
) {
    val context = LocalContext.current
    var entries by remember { mutableStateOf<List<FileEntry>>(emptyList()) }
    var loadError by remember { mutableStateOf<String?>(null) }
    var isLoading by remember { mutableStateOf(false) }
    var pathHistory by remember(source.id) { mutableStateOf<List<String>>(emptyList()) }
    val currentOnDragStart by rememberUpdatedState(onDragStart)
    val currentOnDragMove by rememberUpdatedState(onDragMove)
    val currentOnDragEnd by rememberUpdatedState(onDragEnd)
    val currentOnNavigate by rememberUpdatedState(onNavigate)

    val canNavigateBack = (source.kind == StorageKind.LOCAL && currentPath != source.rootPath && File(currentPath).parentFile != null) || pathHistory.isNotEmpty()
    if (isActive) {
        BackHandler(enabled = canNavigateBack) {
            if (pathHistory.isNotEmpty()) {
                val prev = pathHistory.last()
                pathHistory = pathHistory.dropLast(1)
                currentOnNavigate(prev)
            } else if (source.kind == StorageKind.LOCAL) {
                File(currentPath).parentFile?.absolutePath?.let(currentOnNavigate)
            }
        }
    }

    LaunchedEffect(source.id, currentPath, refreshTick, hasPermission) {
        isLoading = true
        loadError = null
        val res = withContext(Dispatchers.IO) {
            when (source.kind) {
                StorageKind.LOCAL -> {
                    if (!hasPermission) DirResult()
                    else DirResult(entries = listLocalDirectory(File(currentPath)))
                }
                StorageKind.GDRIVE_API -> listGoogleDriveDirectory(context, currentPath)
                StorageKind.SAF_CLOUD -> listSafDirectory(context, currentPath)
                StorageKind.WEBDAV -> listWebDavDirectory(source, currentPath)
                StorageKind.SMB -> listSmbDirectory(source, currentPath)
                StorageKind.FTP -> listFtpDirectory(source, currentPath)
            }
        }
        entries = res.entries
        onEntriesLoaded(res.entries)
        loadError = res.error
        isLoading = false
    }

    val filtered = remember(entries, searchQuery) {
        if (searchQuery.isBlank()) entries
        else entries.filter { it.name.contains(searchQuery, ignoreCase = true) }
    }

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .clickable { onActivate() },
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(
            width = if (isDropTarget) 2.5.dp else if (isActive) 1.5.dp else 1.dp,
            color = when {
                isDropTarget -> BrandYellow
                isActive -> MaterialTheme.colorScheme.primary
                else -> MaterialTheme.colorScheme.outlineVariant
            }
        )
    ) {
        val isPaperLight = MaterialTheme.colorScheme.background.luminance() > 0.5f
        Column(modifier = Modifier.fillMaxSize().paperTexture(isPaperLight)) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "${source.title}: $currentPath",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = source.kind.badge,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
            }

            if (source.kind == StorageKind.LOCAL && !hasPermission) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(strings.permissionTitle, fontSize = 13.sp)
                        Spacer(modifier = Modifier.height(10.dp))
                        Button(onClick = onRequestPermission) {
                            Text(strings.permissionBtn)
                        }
                    }
                }
            } else if (isLoading) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        CircularProgressIndicator(modifier = Modifier.size(28.dp))
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(strings.loadingMsg, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            } else if (loadError != null) {
                Box(modifier = Modifier.fillMaxSize().padding(16.dp), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(loadError ?: "Error", fontSize = 12.sp, color = MaterialTheme.colorScheme.error)
                        if (pathHistory.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(8.dp))
                            OutlinedButton(onClick = {
                                val prev = pathHistory.last()
                                pathHistory = pathHistory.dropLast(1)
                                onNavigate(prev)
                            }) { Text(strings.upDir) }
                        }
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .pointerInput(source.id, currentPath, pathHistory) {
                            var totalX = 0f
                            detectHorizontalDragGestures(
                                onDragStart = { totalX = 0f },
                                onHorizontalDrag = { _, dragAmount -> totalX += dragAmount },
                                onDragEnd = {
                                    if (totalX < -100f && canNavigateBack) {
                                        if (pathHistory.isNotEmpty()) {
                                            val prev = pathHistory.last()
                                            pathHistory = pathHistory.dropLast(1)
                                            currentOnNavigate(prev)
                                        } else if (source.kind == StorageKind.LOCAL) {
                                            File(currentPath).parentFile?.absolutePath?.let(currentOnNavigate)
                                        }
                                    }
                                }
                            )
                        }
                ) {
                    val canGoUp = (source.kind == StorageKind.LOCAL && currentPath != source.rootPath && File(currentPath).parentFile != null) || pathHistory.isNotEmpty()
                    if (canGoUp) {
                        item(key = "up_dir") {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        if (pathHistory.isNotEmpty()) {
                                            val prev = pathHistory.last()
                                            pathHistory = pathHistory.dropLast(1)
                                            onNavigate(prev)
                                        } else {
                                            File(currentPath).parentFile?.absolutePath?.let(onNavigate)
                                        }
                                    }
                                    .padding(horizontal = 10.dp, vertical = 5.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.Folder, contentDescription = null, tint = BrandYellow)
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(strings.upDir, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                            }
                            HorizontalDivider(thickness = 0.5.dp)
                        }
                    }

                    if (filtered.isEmpty()) {
                        item(key = "empty") {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(24.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(strings.emptyDir, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    } else {
                        items(filtered, key = { it.id }) { item ->
                            val isSel = item.id in selectedIds
                            var rowBounds by remember(item.id) { mutableStateOf<Rect?>(null) }
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .onGloballyPositioned { rowBounds = it.boundsInRoot() }
                                    .pointerInput(dualPane, item.id, selectedIds, filtered) {
                                        if (!dualPane) return@pointerInput
                                        detectDragGesturesAfterLongPress(
                                            onDragStart = { localOffset ->
                                                val rootTopLeft = rowBounds?.topLeft ?: Offset.Zero
                                                val itemsToDrag = if (isSel) {
                                                    filtered.filter { it.id in selectedIds }
                                                } else {
                                                    listOf(item)
                                                }
                                                currentOnDragStart(itemsToDrag, rootTopLeft + localOffset)
                                            },
                                            onDrag = { change, dragAmount ->
                                                change.consume()
                                                currentOnDragMove(dragAmount)
                                            },
                                            onDragEnd = { currentOnDragEnd() },
                                            onDragCancel = { currentOnDragEnd() }
                                        )
                                    }
                                    .background(if (isSel) MaterialTheme.colorScheme.primary.copy(alpha = 0.12f) else Color.Transparent)
                                    .clickable {
                                        if (item.isDirectory) {
                                            pathHistory = pathHistory + currentPath
                                            onNavigate(item.path)
                                        } else {
                                            onOpenFile(item)
                                        }
                                    }
                                    .padding(horizontal = 8.dp, vertical = 3.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(18.dp)
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(if (isSel) MaterialTheme.colorScheme.primary else Color.Transparent)
                                        .clickable { onToggleSelect(item.id) },
                                    contentAlignment = Alignment.Center
                                ) {
                                    if (isSel) {
                                        Icon(
                                            imageVector = Icons.Default.Check,
                                            contentDescription = null,
                                            tint = Color.White,
                                            modifier = Modifier.size(13.dp)
                                        )
                                    } else {
                                        Surface(
                                            modifier = Modifier.fillMaxSize(),
                                            shape = RoundedCornerShape(4.dp),
                                            color = Color.Transparent,
                                            border = BorderStroke(1.2.dp, MaterialTheme.colorScheme.outline)
                                        ) {}
                                    }
                                }
                                Spacer(modifier = Modifier.width(7.dp))
                                Icon(
                                    imageVector = if (item.isDirectory) Icons.Default.Folder else Icons.Default.InsertDriveFile,
                                    contentDescription = null,
                                    tint = if (item.isDirectory) Color(0xFFEAB308) else MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(7.dp))
                                Row(
                                    modifier = Modifier.weight(1f),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = item.name,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Medium,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        modifier = Modifier.weight(1f)
                                    )
                                    if (item.subtitle.isNotBlank()) {
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = item.subtitle,
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            maxLines = 1
                                        )
                                    }
                                }
                            }
                            HorizontalDivider(thickness = 0.5.dp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun KomandirBottomBar(
    strings: UiStrings,
    selectedCount: Int,
    onCopy: () -> Unit,
    onMove: () -> Unit,
    onNewFolder: () -> Unit,
    onZip: () -> Unit,
    onRename: () -> Unit,
    onDelete: () -> Unit
) {
    Surface(
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 3.dp
    ) {
        Column(modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)) {
            Text(
                text = if (selectedCount > 0) strings.selectedCount(selectedCount) else strings.nothingSelected,
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                ActionChip(Modifier.weight(1f), Icons.Default.ContentCopy, strings.actCopy, onCopy)
                ActionChip(Modifier.weight(1f), Icons.Default.DriveFileMove, strings.actMove, onMove)
                ActionChip(Modifier.weight(1f), Icons.Default.CreateNewFolder, strings.actNewFolder, onNewFolder)
                ActionChip(Modifier.weight(1f), Icons.Default.Archive, strings.actZip, onZip)
                ActionChip(Modifier.weight(1f), Icons.Default.Edit, strings.actRename, onRename)
                ActionChip(Modifier.weight(1f), Icons.Default.Delete, strings.actDelete, onDelete, isDanger = true)
            }
        }
    }
}

@Composable
private fun ActionChip(
    modifier: Modifier,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    onClick: () -> Unit,
    isDanger: Boolean = false
) {
    Surface(
        modifier = modifier
            .heightIn(min = 44.dp)
            .clip(RoundedCornerShape(10.dp))
            .clickable { onClick() },
        shape = RoundedCornerShape(10.dp),
        color = MaterialTheme.colorScheme.surfaceVariant
    ) {
        Column(
            modifier = Modifier.padding(vertical = 6.dp, horizontal = 2.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = if (isDanger) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = label,
                fontSize = 10.sp,
                fontWeight = FontWeight.Medium,
                color = if (isDanger) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface,
                maxLines = 1
            )
        }
    }
}
