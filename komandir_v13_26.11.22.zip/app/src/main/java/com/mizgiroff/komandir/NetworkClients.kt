package com.mizgiroff.komandir

import android.content.Context
import android.net.Uri
import android.util.Xml
import androidx.documentfile.provider.DocumentFile
import com.hierynomus.smbj.SMBClient
import com.hierynomus.smbj.auth.AuthenticationContext
import com.hierynomus.smbj.share.DiskShare
import okhttp3.Credentials
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.apache.commons.net.ftp.FTP
import org.apache.commons.net.ftp.FTPClient
import org.xmlpull.v1.XmlPullParser
import java.io.StringReader
import java.util.concurrent.TimeUnit

data class DirResult(
    val entries: List<FileEntry> = emptyList(),
    val error: String? = null
)

fun listSafDirectory(context: Context, docUriStr: String): DirResult {
    return try {
        val uri = Uri.parse(docUriStr)
        val doc = DocumentFile.fromTreeUri(context, uri)
            ?: DocumentFile.fromSingleUri(context, uri)
            ?: return DirResult(error = "Cannot open folder")
        val list = doc.listFiles()
            .sortedWith(compareBy<DocumentFile> { !it.isDirectory }.thenBy { (it.name ?: "").lowercase() })
            .map { f ->
                FileEntry(
                    id = f.uri.toString(),
                    name = f.name ?: "Unnamed",
                    path = f.uri.toString(),
                    isDirectory = f.isDirectory,
                    sizeBytes = if (f.isDirectory) 0L else f.length(),
                    lastModified = f.lastModified(),
                    subtitle = if (f.isDirectory) "Folder" else formatFileSize(f.length())
                )
            }
        DirResult(entries = list)
    } catch (e: Exception) {
        DirResult(error = e.message ?: "SAF access error")
    }
}

private val webDavClient: OkHttpClient by lazy {
    OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()
}

fun listWebDavDirectory(source: StorageSource, currentUrl: String): DirResult {
    return try {
        val targetUrl = if (currentUrl.endsWith("/")) currentUrl else "$currentUrl/"
        val propBody = """<?xml version="1.0" encoding="utf-8" ?>
            <D:propfind xmlns:D="DAV:">
                <D:prop>
                    <D:displayname/>
                    <D:getcontentlength/>
                    <D:resourcetype/>
                </D:prop>
            </D:propfind>""".trimIndent().toRequestBody("application/xml".toMediaType())

        val reqBuilder = Request.Builder()
            .url(targetUrl)
            .method("PROPFIND", propBody)
            .header("Depth", "1")
        if (source.username.isNotBlank()) {
            reqBuilder.header("Authorization", Credentials.basic(source.username, source.password))
        }
        webDavClient.newCall(reqBuilder.build()).execute().use { resp ->
            if (!resp.isSuccessful && resp.code != 207) {
                return DirResult(error = "HTTP ${resp.code}: ${resp.message}")
            }
            val xml = resp.body?.string() ?: return DirResult(emptyList())
            val parsed = parseWebDavXml(xml, targetUrl)
            DirResult(entries = parsed)
        }
    } catch (e: Exception) {
        DirResult(error = e.message ?: "WebDAV error")
    }
}

private fun parseWebDavXml(xml: String, baseUrl: String): List<FileEntry> {
    val entries = mutableListOf<FileEntry>()
    val parser = Xml.newPullParser()
    parser.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, true)
    parser.setInput(StringReader(xml))

    var href = ""
    var displayName = ""
    var contentLength = 0L
    var isDir = false
    var inResponse = false
    var currentTag = ""

    val baseUri = Uri.parse(baseUrl)
    val basePath = (baseUri.path ?: "/").trimEnd('/')

    var event = parser.eventType
    while (event != XmlPullParser.END_DOCUMENT) {
        when (event) {
            XmlPullParser.START_TAG -> {
                currentTag = parser.name ?: ""
                if (currentTag == "response") {
                    inResponse = true
                    href = ""
                    displayName = ""
                    contentLength = 0L
                    isDir = false
                } else if (inResponse && currentTag == "collection") {
                    isDir = true
                }
            }
            XmlPullParser.TEXT -> {
                if (inResponse) {
                    val txt = parser.text?.trim() ?: ""
                    when (currentTag) {
                        "href" -> if (href.isEmpty()) href = txt
                        "displayname" -> if (displayName.isEmpty()) displayName = txt
                        "getcontentlength" -> contentLength = txt.toLongOrNull() ?: 0L
                    }
                }
            }
            XmlPullParser.END_TAG -> {
                if (parser.name == "response" && inResponse) {
                    inResponse = false
                    val decodedHref = Uri.decode(href).trimEnd('/')
                    val itemPath = if (decodedHref.startsWith("http")) Uri.parse(decodedHref).path?.trimEnd('/') ?: decodedHref else decodedHref
                    if (itemPath != basePath && itemPath.isNotEmpty()) {
                        val fullUrl = if (href.startsWith("http")) href else "${baseUri.scheme}://${baseUri.encodedAuthority}$href"
                        val name = displayName.ifBlank { itemPath.substringAfterLast('/') }
                        if (name.isNotBlank()) {
                            entries.add(
                                FileEntry(
                                    id = fullUrl,
                                    name = name,
                                    path = fullUrl,
                                    isDirectory = isDir,
                                    sizeBytes = contentLength,
                                    lastModified = 0L,
                                    subtitle = if (isDir) "WebDAV" else formatFileSize(contentLength)
                                )
                            )
                        }
                    }
                }
                currentTag = ""
            }
        }
        event = parser.next()
    }
    return entries.sortedWith(compareBy<FileEntry> { !it.isDirectory }.thenBy { it.name.lowercase() })
}

fun listFtpDirectory(source: StorageSource, path: String): DirResult {
    val client = FTPClient()
    return try {
        val cleanHost = source.host.removePrefix("ftp://").substringBefore("/")
        val hostPart = cleanHost.substringBefore(":")
        val port = cleanHost.substringAfter(":", "21").toIntOrNull() ?: 21
        client.connectTimeout = 10000
        client.connect(hostPart, port)
        val user = source.username.ifBlank { "anonymous" }
        val pass = source.password.ifBlank { "" }
        if (!client.login(user, pass)) {
            return DirResult(error = "FTP login failed (${client.replyCode})")
        }
        client.enterLocalPassiveMode()
        client.setFileType(FTP.BINARY_FILE_TYPE)
        val targetPath = path.ifBlank { "/" }
        val files = client.listFiles(targetPath)
        val entries = files
            .filter { it.name != "." && it.name != ".." }
            .sortedWith(compareBy<org.apache.commons.net.ftp.FTPFile> { !it.isDirectory }.thenBy { it.name.lowercase() })
            .map { f ->
                val childPath = if (targetPath.endsWith("/")) "$targetPath${f.name}" else "$targetPath/${f.name}"
                FileEntry(
                    id = childPath,
                    name = f.name,
                    path = childPath,
                    isDirectory = f.isDirectory,
                    sizeBytes = f.size,
                    lastModified = f.timestamp?.timeInMillis ?: 0L,
                    subtitle = if (f.isDirectory) "FTP" else formatFileSize(f.size)
                )
            }
        DirResult(entries = entries)
    } catch (e: Exception) {
        DirResult(error = e.message ?: "FTP connection error")
    } finally {
        runCatching {
            if (client.isConnected) {
                client.logout()
                client.disconnect()
            }
        }
    }
}

fun listSmbDirectory(source: StorageSource, path: String): DirResult {
    val client = SMBClient()
    return try {
        val raw = source.host.removePrefix("smb://").replace('\\', '/').trimStart('/')
        val cleanHost = raw.substringBefore("/")
        val share = source.shareName.ifBlank {
            raw.substringAfter("/", "").substringBefore("/")
        }
        if (cleanHost.isBlank() || share.isBlank()) {
            return DirResult(error = "Specify host and share name (e.g. 192.168.1.50 and Public)")
        }
        client.connect(cleanHost).use { conn ->
            val auth = if (source.username.isBlank()) {
                AuthenticationContext.guest()
            } else {
                AuthenticationContext(source.username, source.password.toCharArray(), "")
            }
            val session = conn.authenticate(auth)
            (session.connectShare(share) as DiskShare).use { diskShare ->
                val relPath = path.trim('/').replace('/', '\\')
                val dirAttr = 0x10L
                val items = diskShare.list(relPath)
                    .filter { it.fileName != "." && it.fileName != ".." }
                    .sortedWith(compareBy<com.hierynomus.msfscc.fileinformation.FileIdBothDirectoryInformation> {
                        (it.fileAttributes and dirAttr) == 0L
                    }.thenBy { it.fileName.lowercase() })
                    .map { info ->
                        val isDir = (info.fileAttributes and dirAttr) != 0L
                        val nextPath = if (path.isBlank() || path == "/") info.fileName else "${path.trimEnd('/')}/${info.fileName}"
                        FileEntry(
                            id = nextPath,
                            name = info.fileName,
                            path = nextPath,
                            isDirectory = isDir,
                            sizeBytes = info.endOfFile,
                            lastModified = 0L,
                            subtitle = if (isDir) "SMB" else formatFileSize(info.endOfFile)
                        )
                    }
                DirResult(entries = items)
            }
        }
    } catch (e: Exception) {
        DirResult(error = e.message ?: "SMB connection error")
    } finally {
        runCatching { client.close() }
    }
}


fun generatePkcePair(): Pair<String, String> {
    val bytes = ByteArray(32)
    java.security.SecureRandom().nextBytes(bytes)
    val flags = android.util.Base64.URL_SAFE or android.util.Base64.NO_WRAP or android.util.Base64.NO_PADDING
    val verifier = android.util.Base64.encodeToString(bytes, flags)
    val digest = java.security.MessageDigest.getInstance("SHA-256").digest(verifier.toByteArray(Charsets.US_ASCII))
    val challenge = android.util.Base64.encodeToString(digest, flags)
    return verifier to challenge
}

fun exchangeGoogleAuthCode(
    clientId: String,
    clientSecret: String,
    code: String,
    verifier: String,
    redirectUri: String
): Pair<String, String>? {
    return try {
        val fb = okhttp3.FormBody.Builder()
            .add("client_id", clientId)
            .add("code", code)
            .add("code_verifier", verifier)
            .add("redirect_uri", redirectUri)
            .add("grant_type", "authorization_code")
        if (clientSecret.isNotBlank()) fb.add("client_secret", clientSecret)
        val body = fb.build()
        val req = Request.Builder()
            .url("https://oauth2.googleapis.com/token")
            .post(body)
            .build()
        webDavClient.newCall(req).execute().use { resp ->
            val txt = resp.body?.string() ?: return null
            if (!resp.isSuccessful) return null
            val json = org.json.JSONObject(txt)
            val access = json.optString("access_token", "")
            val refresh = json.optString("refresh_token", "")
            if (access.isBlank()) null else access to refresh
        }
    } catch (_: Exception) {
        null
    }
}

private fun refreshGoogleToken(clientId: String, clientSecret: String, refreshToken: String): String? {
    if (clientId.isBlank() || refreshToken.isBlank()) return null
    return try {
        val fb = okhttp3.FormBody.Builder()
            .add("client_id", clientId)
            .add("refresh_token", refreshToken)
            .add("grant_type", "refresh_token")
        if (clientSecret.isNotBlank()) fb.add("client_secret", clientSecret)
        val body = fb.build()
        val req = Request.Builder()
            .url("https://oauth2.googleapis.com/token")
            .post(body)
            .build()
        webDavClient.newCall(req).execute().use { resp ->
            val txt = resp.body?.string() ?: return null
            if (!resp.isSuccessful) return null
            org.json.JSONObject(txt).optString("access_token", "").takeIf { it.isNotBlank() }
        }
    } catch (_: Exception) {
        null
    }
}

fun listGoogleDriveDirectory(context: Context, folderId: String): DirResult {
    var token = KomandirPrefs.getGdAccessToken(context)
    val clientId = KomandirPrefs.getGdClientId(context)
    val refresh = KomandirPrefs.getGdRefreshToken(context)
    if (token.isBlank()) {
        return DirResult(error = "Sign in to Google Drive first")
    }
    val targetFolder = folderId.ifBlank { "root" }
    val query = Uri.encode("'$targetFolder' in parents and trashed = false")
    val url = "https://www.googleapis.com/drive/v3/files?q=$query&pageSize=100&fields=files(id,name,mimeType,size)&orderBy=folder,name"

    fun callDrive(bearer: String): okhttp3.Response {
        val req = Request.Builder()
            .url(url)
            .header("Authorization", "Bearer $bearer")
            .build()
        return webDavClient.newCall(req).execute()
    }

    return try {
        var resp = callDrive(token)
        if (resp.code == 401 && refresh.isNotBlank()) {
            resp.close()
            val newToken = refreshGoogleToken(clientId, if (clientId == KomandirPrefs.DEFAULT_GD_CLIENT_ID) KomandirPrefs.DEFAULT_GD_CLIENT_SECRET else "", refresh)
            if (newToken != null) {
                KomandirPrefs.saveGdTokens(context, newToken, "")
                token = newToken
                resp = callDrive(token)
            }
        }
        resp.use { r ->
            if (!r.isSuccessful) {
                return DirResult(error = "Drive API ${r.code}: ${r.message}")
            }
            val bodyStr = r.body?.string() ?: return DirResult(emptyList())
            val arr = org.json.JSONObject(bodyStr).optJSONArray("files") ?: return DirResult(emptyList())
            val list = mutableListOf<FileEntry>()
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                val id = obj.getString("id")
                val name = obj.getString("name")
                val mime = obj.optString("mimeType", "")
                val isDir = mime == "application/vnd.google-apps.folder"
                val size = obj.optString("size", "0").toLongOrNull() ?: 0L
                list.add(
                    FileEntry(
                        id = id,
                        name = name,
                        path = id,
                        isDirectory = isDir,
                        sizeBytes = size,
                        lastModified = 0L,
                        subtitle = if (isDir) "Google Drive" else if (size > 0L) formatFileSize(size) else "Google Doc"
                    )
                )
            }
            DirResult(entries = list)
        }
    } catch (e: Exception) {
        DirResult(error = e.message ?: "Google Drive error")
    }
}


fun runGoogleOAuthLoopback(
    clientId: String,
    clientSecret: String,
    onOpenUrl: (String) -> Unit
): Pair<String, String>? {
    val server = java.net.ServerSocket(0, 1, java.net.InetAddress.getByName("127.0.0.1"))
    return try {
        server.soTimeout = 180_000
        val port = server.localPort
        val redirectUri = "http://127.0.0.1:$port"
        val (verifier, challenge) = generatePkcePair()
        val authUrl = "https://accounts.google.com/o/oauth2/v2/auth" +
            "?client_id=${Uri.encode(clientId)}" +
            "&redirect_uri=${Uri.encode(redirectUri)}" +
            "&response_type=code" +
            "&scope=${Uri.encode("https://www.googleapis.com/auth/drive")}" +
            "&access_type=offline&prompt=consent" +
            "&code_challenge=$challenge&code_challenge_method=S256"

        onOpenUrl(authUrl)

        val socket = server.accept()
        socket.use { s ->
            val reader = java.io.BufferedReader(java.io.InputStreamReader(s.getInputStream()))
            val requestLine = reader.readLine() ?: ""
            val queryPart = requestLine.substringAfter("GET ", "").substringBefore(" HTTP")
            val parsedUri = Uri.parse("http://127.0.0.1$queryPart")
            val code = parsedUri.getQueryParameter("code") ?: ""

            val html = "<html><body style='font-family:sans-serif;text-align:center;padding:40px;'><h2>Komandir</h2><p>Authorization complete. Return to the Komandir app.</p></body></html>"
            val httpResp = "HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=UTF-8\r\nContent-Length: ${html.toByteArray().size}\r\nConnection: close\r\n\r\n$html"
            s.getOutputStream().write(httpResp.toByteArray(Charsets.UTF_8))
            s.getOutputStream().flush()

            if (code.isBlank()) null
            else exchangeGoogleAuthCode(clientId, clientSecret, code, verifier, redirectUri)
        }
    } catch (_: Exception) {
        null
    } finally {
        runCatching { server.close() }
    }
}
