package com.mizgiroff.komandir

import android.content.Context
import android.net.Uri
import android.util.Xml
import androidx.documentfile.provider.DocumentFile
import com.hierynomus.msfscc.fileattrs.FileAttributes
import com.hierynomus.smbj.SMBClient
import com.hierynomus.smbj.auth.AuthenticationContext
import com.hierynomus.smbj.share.DiskShare
import okhttp3.Credentials
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.apache.commons.net.ftp.FTP
import org.apache.commons.net.ftp.FTPClient
import org.xmlpull.v1.XmlPullParser
import java.io.StringReader
import java.util.concurrent.TimeUnit

data class DirResult(
    val entries: List<FileEntry> = emptyList(),
    val error: String? = null
)

fun listSafDirectory(context: Context, docUriStr: String): DirResult {
    return try {
        val uri = Uri.parse(docUriStr)
        val doc = DocumentFile.fromTreeUri(context, uri)
            ?: DocumentFile.fromSingleUri(context, uri)
            ?: return DirResult(error = "Cannot open folder")
        val list = doc.listFiles()
            .sortedWith(compareBy<DocumentFile> { !it.isDirectory }.thenBy { (it.name ?: "").lowercase() })
            .map { f ->
                FileEntry(
                    id = f.uri.toString(),
                    name = f.name ?: "Unnamed",
                    path = f.uri.toString(),
                    isDirectory = f.isDirectory,
                    sizeBytes = if (f.isDirectory) 0L else f.length(),
                    lastModified = f.lastModified(),
                    subtitle = if (f.isDirectory) "Folder" else formatFileSize(f.length())
                )
            }
        DirResult(entries = list)
    } catch (e: Exception) {
        DirResult(error = e.message ?: "SAF access error")
    }
}

private val webDavClient: OkHttpClient by lazy {
    OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()
}

fun listWebDavDirectory(source: StorageSource, currentUrl: String): DirResult {
    return try {
        val targetUrl = if (currentUrl.endsWith("/")) currentUrl else "$currentUrl/"
        val propBody = """<?xml version="1.0" encoding="utf-8" ?>
            <D:propfind xmlns:D="DAV:">
                <D:prop>
                    <D:displayname/>
                    <D:getcontentlength/>
                    <D:resourcetype/>
                </D:prop>
            </D:propfind>""".trimIndent().toRequestBody("application/xml".toMediaType())

        val reqBuilder = Request.Builder()
            .url(targetUrl)
            .method("PROPFIND", propBody)
            .header("Depth", "1")
        if (source.username.isNotBlank()) {
            reqBuilder.header("Authorization", Credentials.basic(source.username, source.password))
        }
        webDavClient.newCall(reqBuilder.build()).execute().use { resp ->
            if (!resp.isSuccessful && resp.code != 207) {
                return DirResult(error = "HTTP ${resp.code}: ${resp.message}")
            }
            val xml = resp.body?.string() ?: return DirResult(emptyList())
            val parsed = parseWebDavXml(xml, targetUrl)
            DirResult(entries = parsed)
        }
    } catch (e: Exception) {
        DirResult(error = e.message ?: "WebDAV error")
    }
}

private fun parseWebDavXml(xml: String, baseUrl: String): List<FileEntry> {
    val entries = mutableListOf<FileEntry>()
    val parser = Xml.newPullParser()
    parser.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, true)
    parser.setInput(StringReader(xml))

    var href = ""
    var displayName = ""
    var contentLength = 0L
    var isDir = false
    var inResponse = false
    var currentTag = ""

    val baseUri = Uri.parse(baseUrl)
    val basePath = (baseUri.path ?: "/").trimEnd('/')

    var event = parser.eventType
    while (event != XmlPullParser.END_DOCUMENT) {
        when (event) {
            XmlPullParser.START_TAG -> {
                currentTag = parser.name ?: ""
                if (currentTag == "response") {
                    inResponse = true
                    href = ""
                    displayName = ""
                    contentLength = 0L
                    isDir = false
                } else if (inResponse && currentTag == "collection") {
                    isDir = true
                }
            }
            XmlPullParser.TEXT -> {
                if (inResponse) {
                    val txt = parser.text?.trim() ?: ""
                    when (currentTag) {
                        "href" -> if (href.isEmpty()) href = txt
                        "displayname" -> if (displayName.isEmpty()) displayName = txt
                        "getcontentlength" -> contentLength = txt.toLongOrNull() ?: 0L
                    }
                }
            }
            XmlPullParser.END_TAG -> {
                if (parser.name == "response" && inResponse) {
                    inResponse = false
                    val decodedHref = Uri.decode(href).trimEnd('/')
                    val itemPath = if (decodedHref.startsWith("http")) Uri.parse(decodedHref).path?.trimEnd('/') ?: decodedHref else decodedHref
                    if (itemPath != basePath && itemPath.isNotEmpty()) {
                        val fullUrl = if (href.startsWith("http")) href else "${baseUri.scheme}://${baseUri.encodedAuthority}$href"
                        val name = displayName.ifBlank { itemPath.substringAfterLast('/') }
                        if (name.isNotBlank()) {
                            entries.add(
                                FileEntry(
                                    id = fullUrl,
                                    name = name,
                                    path = fullUrl,
                                    isDirectory = isDir,
                                    sizeBytes = contentLength,
                                    lastModified = 0L,
                                    subtitle = if (isDir) "WebDAV" else formatFileSize(contentLength)
                                )
                            )
                        }
                    }
                }
                currentTag = ""
            }
        }
        event = parser.next()
    }
    return entries.sortedWith(compareBy<FileEntry> { !it.isDirectory }.thenBy { it.name.lowercase() })
}

fun listFtpDirectory(source: StorageSource, path: String): DirResult {
    val client = FTPClient()
    return try {
        val cleanHost = source.host.removePrefix("ftp://").substringBefore("/")
        val hostPart = cleanHost.substringBefore(":")
        val port = cleanHost.substringAfter(":", "21").toIntOrNull() ?: 21
        client.connectTimeout = 10000
        client.connect(hostPart, port)
        val user = source.username.ifBlank { "anonymous" }
        val pass = source.password.ifBlank { "" }
        if (!client.login(user, pass)) {
            return DirResult(error = "FTP login failed (${client.replyCode})")
        }
        client.enterLocalPassiveMode()
        client.setFileType(FTP.BINARY_FILE_TYPE)
        val targetPath = path.ifBlank { "/" }
        val files = client.listFiles(targetPath)
        val entries = files
            .filter { it.name != "." && it.name != ".." }
            .sortedWith(compareBy<org.apache.commons.net.ftp.FTPFile> { !it.isDirectory }.thenBy { it.name.lowercase() })
            .map { f ->
                val childPath = if (targetPath.endsWith("/")) "$targetPath${f.name}" else "$targetPath/${f.name}"
                FileEntry(
                    id = childPath,
                    name = f.name,
                    path = childPath,
                    isDirectory = f.isDirectory,
                    sizeBytes = f.size,
                    lastModified = f.timestamp?.timeInMillis ?: 0L,
                    subtitle = if (f.isDirectory) "FTP" else formatFileSize(f.size)
                )
            }
        DirResult(entries = entries)
    } catch (e: Exception) {
        DirResult(error = e.message ?: "FTP connection error")
    } finally {
        runCatching {
            if (client.isConnected) {
                client.logout()
                client.disconnect()
            }
        }
    }
}

fun listSmbDirectory(source: StorageSource, path: String): DirResult {
    val client = SMBClient()
    return try {
        val cleanHost = source.host.removePrefix("smb://").removePrefix("\\").substringBefore("/").substringBefore("\")
        val share = source.shareName.ifBlank {
            source.host.removePrefix("smb://").removePrefix("\\").substringAfter("/", "").substringBefore("/")
        }
        if (cleanHost.isBlank() || share.isBlank()) {
            return DirResult(error = "Specify host and share name (e.g. 192.168.1.50 and Public)")
        }
        client.connect(cleanHost).use { conn ->
            val auth = if (source.username.isBlank()) {
                AuthenticationContext.guest()
            } else {
                AuthenticationContext(source.username, source.password.toCharArray(), "")
            }
            val session = conn.authenticate(auth)
            (session.connectShare(share) as DiskShare).use { diskShare ->
                val relPath = path.trim('/').replace('/', '\')
                val items = diskShare.list(relPath)
                    .filter { it.fileName != "." && it.fileName != ".." }
                    .sortedWith(compareBy<com.hierynomus.msfscc.fileinformation.FileIdBothDirectoryInformation> {
                        (it.fileAttributes and FileAttributes.FILE_ATTRIBUTE_DIRECTORY.value) == 0L
                    }.thenBy { it.fileName.lowercase() })
                    .map { info ->
                        val isDir = (info.fileAttributes and FileAttributes.FILE_ATTRIBUTE_DIRECTORY.value) != 0L
                        val nextPath = if (path.isBlank() || path == "/") info.fileName else "${path.trimEnd('/')}/${info.fileName}"
                        FileEntry(
                            id = nextPath,
                            name = info.fileName,
                            path = nextPath,
                            isDirectory = isDir,
                            sizeBytes = info.endOfFile,
                            lastModified = 0L,
                            subtitle = if (isDir) "SMB" else formatFileSize(info.endOfFile)
                        )
                    }
                DirResult(entries = items)
            }
        }
    } catch (e: Exception) {
        DirResult(error = e.message ?: "SMB connection error")
    } finally {
        runCatching { client.close() }
    }
}
