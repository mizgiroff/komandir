package main

import (
	"bufio"
	"bytes"
	"crypto/rand"
	"crypto/sha256"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"encoding/xml"
	"fmt"
	"html"
	"io"
	"log"
	"net"
	"net/http"
	"net/url"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"runtime"
	"strconv"
	"strings"
	"sync"
	"time"

	"github.com/skip2/go-qrcode"
	"golang.org/x/net/webdav"
)

type PeerSyncConfig struct {
	ID          string `json:"id"`
	Name        string `json:"name"`
	PeerURL     string `json:"peerUrl"`
	PeerUser    string `json:"peerUser"`
	PeerPass    string `json:"peerPass"`
	Mode        string `json:"mode"` // "two_way", "push", "pull"
	IntervalMin int    `json:"intervalMin"`
	Enabled     bool   `json:"enabled"`
	LastRun     string `json:"lastRun"`
	LastStatus  string `json:"lastStatus"`
}

type BridgeConfig struct {
	DeviceID   string           `json:"deviceId"`
	Name       string           `json:"name"`
	Folder     string           `json:"folder"`
	User       string           `json:"user"`
	Pass       string           `json:"pass"`
	Port       int              `json:"port"`
	TunnelMode string           `json:"tunnelMode"` // "localhost.run", "pinggy", "cloudflare"
	BeaconURL      string           `json:"beaconUrl"`
	GdRefreshToken string           `json:"gdRefreshToken,omitempty"`
	Peers      []PeerSyncConfig `json:"peers"`
}

type QrPayload struct {
	Type      string `json:"type"`
	DeviceID  string `json:"deviceId"`
	Name      string `json:"name"`
	LanURL    string `json:"lanUrl"`
	DirectURL string `json:"directUrl,omitempty"`
	TunnelURL string `json:"tunnelUrl"`
	BeaconURL string `json:"beaconUrl,omitempty"`
	User      string `json:"user"`
	Pass      string `json:"pass"`
}

var (
	mu         sync.RWMutex
	cfg        BridgeConfig
	directURL  string
	tunnelURL  string
	tunnelErr  string
	tunnelProc *exec.Cmd
	tunnelGen  int
	paused     bool
	bridgeVersion = "dev"
	tunnelLogs []string
	ansiRe     = regexp.MustCompile(`\x1b\[[0-9;]*[a-zA-Z]`)
	gdVerifier string
	gdClientID = "864168741040-7r9g0vd266q4nse01qfvaudqi2ldos3k.apps.googleusercontent.com"
	gdSecret   = "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"
)

func randHex(n int) string {
	b := make([]byte, n)
	_, _ = rand.Read(b)
	return hex.EncodeToString(b)
}

func configPath() string {
	dir, err := os.UserConfigDir()
	if err != nil {
		dir = "."
	}
	appDir := filepath.Join(dir, "KomandirBridge")
	_ = os.MkdirAll(appDir, 0755)
	return filepath.Join(appDir, "config.json")
}

func loadOrCreateConfig() BridgeConfig {
	p := configPath()
	if data, err := os.ReadFile(p); err == nil {
		var c BridgeConfig
		if json.Unmarshal(data, &c) == nil && c.DeviceID != "" {
			if c.Port == 0 {
				c.Port = 8765
			}
			if c.TunnelMode == "" {
				c.TunnelMode = "localhost.run"
			}
			return c
		}
	}
	host, _ := os.Hostname()
	if host == "" {
		host = "Windows-PC"
	}
	home, _ := os.UserHomeDir()
	c := BridgeConfig{
		DeviceID:   "pc_" + randHex(6),
		Name:       host,
		Folder:     home,
		User:       "komandir",
		Pass:       randHex(8),
		Port:       8765,
		TunnelMode: "localhost.run",
	}
	saveConfig(c)
	return c
}

func saveConfig(c BridgeConfig) {
	data, _ := json.MarshalIndent(c, "", "  ")
	_ = os.WriteFile(configPath(), data, 0600)
}

func getLocalIP() string {
	conn, err := net.Dial("udp", "8.8.8.8:80")
	if err == nil {
		defer conn.Close()
		if addr, ok := conn.LocalAddr().(*net.UDPAddr); ok {
			return addr.IP.String()
		}
	}
	return "127.0.0.1"
}


func getGdAccessToken(refreshToken string) string {
	if refreshToken == "" {
		return ""
	}
	form := url.Values{}
	form.Set("client_id", gdClientID)
	form.Set("client_secret", gdSecret)
	form.Set("refresh_token", refreshToken)
	form.Set("grant_type", "refresh_token")
	resp, err := http.PostForm("https://oauth2.googleapis.com/token", form)
	if err != nil {
		return ""
	}
	defer resp.Body.Close()
	var res map[string]any
	if json.NewDecoder(resp.Body).Decode(&res) == nil {
		if tok, ok := res["access_token"].(string); ok {
			return tok
		}
	}
	return ""
}

func publishDriveBeacon(c BridgeConfig, lan, dURL, tURL string) {
	if c.GdRefreshToken == "" || tURL == "" {
		return
	}
	tok := getGdAccessToken(c.GdRefreshToken)
	if tok == "" {
		return
	}
	fname := fmt.Sprintf("komandir_bridge_%s.json", c.DeviceID)
	payload, _ := json.Marshal(map[string]any{
		"type":      "komandir_beacon",
		"deviceId":  c.DeviceID,
		"name":      c.Name,
		"lanUrl":    lan,
		"directUrl": dURL,
		"tunnelUrl": tURL,
		"beaconUrl": c.BeaconURL,
		"updatedAt": time.Now().UnixMilli(),
	})
	client := &http.Client{Timeout: 15 * time.Second}
	q := url.QueryEscape(fmt.Sprintf("name='%s' and trashed=false", fname))
	req, _ := http.NewRequest("GET", "https://www.googleapis.com/drive/v3/files?q="+q+"&fields=files(id)&pageSize=1", nil)
	req.Header.Set("Authorization", "Bearer "+tok)
	var existingID string
	if resp, err := client.Do(req); err == nil {
		var listRes struct {
			Files []struct{ ID string `json:"id"` } `json:"files"`
		}
		if json.NewDecoder(resp.Body).Decode(&listRes) == nil && len(listRes.Files) > 0 {
			existingID = listRes.Files[0].ID
		}
		_ = resp.Body.Close()
	}
	if existingID != "" {
		upReq, _ := http.NewRequest("PATCH", "https://www.googleapis.com/upload/drive/v3/files/"+existingID+"?uploadType=media", bytes.NewReader(payload))
		upReq.Header.Set("Authorization", "Bearer "+tok)
		upReq.Header.Set("Content-Type", "application/json")
		if resp, err := client.Do(upReq); err == nil {
			_ = resp.Body.Close()
			log.Println("Google Drive beacon updated:", resp.Status)
		}
	} else {
		boundary := fmt.Sprintf("kb_%d", time.Now().UnixNano())
		meta, _ := json.Marshal(map[string]any{"name": fname, "mimeType": "application/json"})
		body := fmt.Sprintf("--%s\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n%s\r\n--%s\r\nContent-Type: application/json\r\n\r\n%s\r\n--%s--",
			boundary, string(meta), boundary, string(payload), boundary)
		upReq, _ := http.NewRequest("POST", "https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart", strings.NewReader(body))
		upReq.Header.Set("Authorization", "Bearer "+tok)
		upReq.Header.Set("Content-Type", "multipart/related; boundary="+boundary)
		if resp, err := client.Do(upReq); err == nil {
			_ = resp.Body.Close()
			log.Println("Google Drive beacon created:", resp.Status)
		}
	}
}

func notifyBeacon(tURL string) {
	mu.RLock()
	c := cfg
	dURL := directURL
	if tURL == "" {
		tURL = tunnelURL
	}
	mu.RUnlock()
	if tURL == "" && dURL == "" {
		return
	}
	lan := fmt.Sprintf("http://%s:%d/", getLocalIP(), c.Port)
	if c.GdRefreshToken != "" {
		go publishDriveBeacon(c, lan, dURL, tURL)
	}
	if strings.TrimSpace(c.BeaconURL) == "" {
		return
	}
	body, _ := json.Marshal(map[string]any{
		"type":      "komandir_beacon",
		"deviceId":  c.DeviceID,
		"name":      c.Name,
		"lanUrl":    lan,
		"directUrl": dURL,
		"tunnelUrl": tURL,
		"updatedAt": time.Now().UTC().Format(time.RFC3339),
	})
	client := &http.Client{Timeout: 10 * time.Second}
	resp, err := client.Post(c.BeaconURL, "application/json", bytes.NewReader(body))
	if err != nil {
		log.Println("Beacon POST error:", err)
		return
	}
	_ = resp.Body.Close()
	log.Println("Beacon updated:", resp.Status)
}



func ensureSSHKey() string {
	dir, err := os.UserConfigDir()
	if err != nil {
		dir = "."
	}
	appDir := filepath.Join(dir, "KomandirBridge")
	_ = os.MkdirAll(appDir, 0755)
	keyPath := filepath.Join(appDir, "id_ed25519")
	if _, err := os.Stat(keyPath); err == nil {
		return keyPath
	}
	cmd := exec.Command("ssh-keygen", "-t", "ed25519", "-N", "", "-f", keyPath)
	hideCmdWindow(cmd)
	if out, err := cmd.CombinedOutput(); err != nil {
		log.Println("ssh-keygen error:", err, string(out))
		return ""
	}
	return keyPath
}

func ensureCloudflared() (string, error) {
	exeName := "cloudflared"
	if runtime.GOOS == "windows" {
		exeName = "cloudflared.exe"
	}
	if p, err := exec.LookPath(exeName); err == nil {
		return p, nil
	}
	dir, _ := os.UserConfigDir()
	localBin := filepath.Join(dir, "KomandirBridge", exeName)
	if _, err := os.Stat(localBin); err == nil {
		return localBin, nil
	}
	if runtime.GOOS != "windows" {
		return "", fmt.Errorf("cloudflared not found in PATH")
	}
	log.Println("Downloading cloudflared.exe for free HTTPS tunnel...")
	resp, err := http.Get("https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-windows-amd64.exe")
	if err != nil {
		return "", err
	}
	defer resp.Body.Close()
	out, err := os.Create(localBin)
	if err != nil {
		return "", err
	}
	defer out.Close()
	if _, err := io.Copy(out, resp.Body); err != nil {
		return "", err
	}
	return localBin, nil
}

func appendTunnelLog(line string) {
	clean := strings.TrimSpace(ansiRe.ReplaceAllString(line, ""))
	if clean == "" {
		return
	}
	mu.Lock()
	tunnelLogs = append(tunnelLogs, clean)
	if len(tunnelLogs) > 12 {
		tunnelLogs = tunnelLogs[len(tunnelLogs)-12:]
	}
	mu.Unlock()
}

func stopTunnel() {
	mu.Lock()
	tunnelGen++
	if tunnelProc != nil && tunnelProc.Process != nil {
		_ = tunnelProc.Process.Kill()
		tunnelProc = nil
	}
	mu.Unlock()
}

func cleanupOrphanTunnels() {
	if runtime.GOOS != "windows" {
		return
	}
	cmd := exec.Command("powershell", "-NoProfile", "-WindowStyle", "Hidden", "-Command",
		"Get-CimInstance Win32_Process -Filter \"Name='ssh.exe'\" | Where-Object { $_.CommandLine -like '*localhost.run*' } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }")
	hideCmdWindow(cmd)
	_ = cmd.Run()
}

func togglePause() {
	mu.Lock()
	paused = !paused
	p := paused
	if p {
		tunnelGen++
		tunnelURL = ""
		tunnelErr = "Paused"
		if tunnelProc != nil && tunnelProc.Process != nil {
			_ = tunnelProc.Process.Kill()
			tunnelProc = nil
		}
		mu.Unlock()
		return
	}
	mu.Unlock()
	restartTunnel()
}

func restartTunnel() {
	mu.Lock()
	tunnelGen++
	gen := tunnelGen
	tunnelURL = ""
	tunnelErr = ""
	tunnelLogs = nil
	if tunnelProc != nil && tunnelProc.Process != nil {
		_ = tunnelProc.Process.Kill()
		tunnelProc = nil
	}
	mode := cfg.TunnelMode
	port := cfg.Port
	mu.Unlock()
	go runTunnelLoop(gen, mode, port)
}

func runTunnelLoop(gen int, mode string, port int) {
	nullFile := "/dev/null"
	if runtime.GOOS == "windows" {
		nullFile = "NUL"
	}
	for {
		mu.RLock()
		activeGen := tunnelGen
		mu.RUnlock()
		if activeGen != gen {
			return
		}

		var cmd *exec.Cmd
		var re *regexp.Regexp
		switch mode {
		case "cloudflare":
			bin, err := ensureCloudflared()
			if err != nil {
				mu.Lock()
				tunnelErr = err.Error()
				mu.Unlock()
				return
			}
			cmd = exec.Command(bin, "tunnel", "--url", fmt.Sprintf("http://127.0.0.1:%d", port))
			re = regexp.MustCompile(`https://[a-zA-Z0-9-]+\.trycloudflare\.com`)
		default: // "localhost.run"
			key := ensureSSHKey()
			args := []string{"-T", "-o", "StrictHostKeyChecking=no", "-o", "UserKnownHostsFile=" + nullFile, "-o", "ServerAliveInterval=30", "-o", "ExitOnForwardFailure=yes"}
			if key != "" { args = append(args, "-i", key) }
			args = append(args, "-R", fmt.Sprintf("80:127.0.0.1:%d", port), "localhost.run", "--", "--output", "json")
			cmd = exec.Command("ssh", args...)
			re = regexp.MustCompile(`(?:https://)?[a-zA-Z0-9.-]+\.lhr\.life`)
		}

		hideCmdWindow(cmd)
		stdout, _ := cmd.StdoutPipe()
		stderr, _ := cmd.StderrPipe()
		if err := cmd.Start(); err != nil {
			mu.Lock()
			tunnelErr = fmt.Sprintf("%s start error: %v", mode, err)
			mu.Unlock()
			time.Sleep(5 * time.Second)
			continue
		}
		mu.Lock()
		tunnelProc = cmd
		mu.Unlock()

				scanWithNotify := func(r io.Reader) {
			if r == nil { return }
			sc := bufio.NewScanner(r)
			for sc.Scan() {
				line := ansiRe.ReplaceAllString(sc.Text(), "")
				appendTunnelLog(line)
				m := ""
				if mode == "localhost.run" {
					var obj map[string]any
					if json.Unmarshal([]byte(strings.TrimSpace(line)), &obj) == nil {
						if addr, ok := obj["address"].(string); ok && addr != "" && addr != "app.lhr.life" {
							m = addr
						}
					}
				}
				if m == "" {
					m = re.FindString(line)
				}
				if m != "" {
					low := strings.ToLower(m)
					if low == "app.lhr.life" || low == "https://app.lhr.life" || strings.Contains(low, "admin.localhost.run") || strings.Contains(low, "console.serveo.net") {
						continue
					}
					if !strings.HasPrefix(m, "http") { m = "https://" + m }
					u := m + "/"
					mu.Lock()
					changed := tunnelURL != u
					tunnelURL = u
					tunnelErr = ""
					mu.Unlock()
					if changed {
						log.Printf("Tunnel (%s) ready: %s\n", mode, u)
						go notifyBeacon(u)
					}
				}
			}
		}
		go scanWithNotify(stdout)
		go scanWithNotify(stderr)
		_ = cmd.Wait()

		mu.RLock()
		stillSame := tunnelGen == gen
		mu.RUnlock()
		if !stillSame {
			return
		}
		time.Sleep(4 * time.Second)
	}
}

// --- Autonomous PC <-> PC WebDAV Sync ---

type davMultistatus struct {
	Responses []struct {
		Href     string `xml:"href"`
		Propstat []struct {
			Prop struct {
				DisplayName  string `xml:"displayname"`
				ContentLen   int64  `xml:"getcontentlength"`
				LastModified string `xml:"getlastmodified"`
				ResourceType struct {
					Collection *struct{} `xml:"collection"`
				} `xml:"resourcetype"`
			} `xml:"prop"`
		} `xml:"propstat"`
	} `xml:"response"`
}

type davItem struct {
	RelPath string
	IsDir   bool
	Size    int64
	ModTime time.Time
}

func davListRecursive(client *http.Client, baseURL, user, pass, relPrefix string, out map[string]davItem) error {
	targetURL := strings.TrimRight(baseURL, "/") + "/"
	if relPrefix != "" {
		segs := strings.Split(strings.Trim(relPrefix, "/"), "/")
		for i, s := range segs {
			segs[i] = url.PathEscape(s)
		}
		targetURL += strings.Join(segs, "/") + "/"
	}
	req, err := http.NewRequest("PROPFIND", targetURL, strings.NewReader(`<?xml version="1.0" encoding="utf-8"?><d:propfind xmlns:d="DAV:"><d:prop><d:displayname/><d:getcontentlength/><d:getlastmodified/><d:resourcetype/></d:prop></d:propfind>`))
	if err != nil {
		return err
	}
	req.SetBasicAuth(user, pass)
	req.Header.Set("Depth", "1")
	req.Header.Set("Content-Type", "application/xml")
	resp, err := client.Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	if resp.StatusCode >= 300 {
		return fmt.Errorf("PROPFIND %s -> %d", targetURL, resp.StatusCode)
	}
	raw, _ := io.ReadAll(resp.Body)
	var ms davMultistatus
	if err := xml.Unmarshal(raw, &ms); err != nil {
		return err
	}
	baseParsed, _ := url.Parse(strings.TrimRight(baseURL, "/") + "/")
	basePath := "/"
	if baseParsed != nil && baseParsed.Path != "" {
		basePath = baseParsed.Path
	}
	for _, r := range ms.Responses {
		u, err := url.Parse(r.Href)
		if err != nil {
			continue
		}
		decodedPath, _ := url.PathUnescape(u.Path)
		rel := strings.TrimPrefix(decodedPath, basePath)
		rel = strings.Trim(rel, "/")
		if rel == "" || rel == strings.Trim(relPrefix, "/") {
			continue
		}
		var isDir bool
		var sz int64
		var mod time.Time
		for _, ps := range r.Propstat {
			if ps.Prop.ResourceType.Collection != nil {
				isDir = true
			}
			if ps.Prop.ContentLen > 0 {
				sz = ps.Prop.ContentLen
			}
			if ps.Prop.LastModified != "" {
				if t, e := http.ParseTime(ps.Prop.LastModified); e == nil {
					mod = t
				}
			}
		}
		out[rel] = davItem{RelPath: rel, IsDir: isDir, Size: sz, ModTime: mod}
		if isDir {
			if err := davListRecursive(client, baseURL, user, pass, rel, out); err != nil {
				return err
			}
		}
	}
	return nil
}

func davURL(baseURL, rel string) string {
	segs := strings.Split(strings.Trim(rel, "/"), "/")
	for i, s := range segs {
		segs[i] = url.PathEscape(s)
	}
	return strings.TrimRight(baseURL, "/") + "/" + strings.Join(segs, "/")
}

func syncWithPeer(peerID string) {
	mu.RLock()
	var p PeerSyncConfig
	found := false
	for _, item := range cfg.Peers {
		if item.ID == peerID {
			p = item
			found = true
			break
		}
	}
	localRoot := cfg.Folder
	mu.RUnlock()
	if !found {
		return
	}

	client := &http.Client{Timeout: 60 * time.Second}
	remoteMap := make(map[string]davItem)
	err := davListRecursive(client, p.PeerURL, p.PeerUser, p.PeerPass, "", remoteMap)
	statusMsg := ""
	if err != nil {
		statusMsg = "Error: " + err.Error()
	} else {
		localMap := make(map[string]davItem)
		_ = filepath.Walk(localRoot, func(full string, info os.FileInfo, werr error) error {
			if werr != nil || full == localRoot {
				return nil
			}
			rel, _ := filepath.Rel(localRoot, full)
			rel = filepath.ToSlash(rel)
			localMap[rel] = davItem{RelPath: rel, IsDir: info.IsDir(), Size: info.Size(), ModTime: info.ModTime()}
			return nil
		})

		uploaded, downloaded := 0, 0
		if p.Mode == "push" || p.Mode == "two_way" {
			for rel, l := range localMap {
				r, exists := remoteMap[rel]
				if l.IsDir {
					if !exists {
						req, _ := http.NewRequest("MKCOL", davURL(p.PeerURL, rel)+"/", nil)
						req.SetBasicAuth(p.PeerUser, p.PeerPass)
						if resp, e := client.Do(req); e == nil {
							_ = resp.Body.Close()
						}
					}
					continue
				}
				if !exists || (l.Size != r.Size && l.ModTime.After(r.ModTime.Add(2*time.Second))) {
					f, e := os.Open(filepath.Join(localRoot, filepath.FromSlash(rel)))
					if e == nil {
						req, _ := http.NewRequest("PUT", davURL(p.PeerURL, rel), f)
						req.SetBasicAuth(p.PeerUser, p.PeerPass)
						req.ContentLength = l.Size
						if resp, re := client.Do(req); re == nil {
							if resp.StatusCode < 300 {
								uploaded++
							}
							_ = resp.Body.Close()
						}
						_ = f.Close()
					}
				}
			}
		}
		if p.Mode == "pull" || p.Mode == "two_way" {
			for rel, r := range remoteMap {
				l, exists := localMap[rel]
				destPath := filepath.Join(localRoot, filepath.FromSlash(rel))
				if r.IsDir {
					_ = os.MkdirAll(destPath, 0755)
					continue
				}
				if !exists || (r.Size != l.Size && r.ModTime.After(l.ModTime.Add(2*time.Second))) {
					_ = os.MkdirAll(filepath.Dir(destPath), 0755)
					req, _ := http.NewRequest("GET", davURL(p.PeerURL, rel), nil)
					req.SetBasicAuth(p.PeerUser, p.PeerPass)
					if resp, re := client.Do(req); re == nil {
						if resp.StatusCode < 300 {
							if out, oe := os.Create(destPath); oe == nil {
								_, _ = io.Copy(out, resp.Body)
								_ = out.Close()
								if !r.ModTime.IsZero() {
									_ = os.Chtimes(destPath, r.ModTime, r.ModTime)
								}
								downloaded++
							}
						}
						_ = resp.Body.Close()
					}
				}
			}
		}
		statusMsg = fmt.Sprintf("OK: ↑%d ↓%d", uploaded, downloaded)
	}

	mu.Lock()
	for i := range cfg.Peers {
		if cfg.Peers[i].ID == peerID {
			cfg.Peers[i].LastRun = time.Now().Format("15:04:05")
			cfg.Peers[i].LastStatus = statusMsg
		}
	}
	saveConfig(cfg)
	mu.Unlock()
}

func startPeerScheduler() {
	lastTick := make(map[string]time.Time)
	for {
		time.Sleep(30 * time.Second)
		mu.RLock()
		peers := append([]PeerSyncConfig(nil), cfg.Peers...)
		mu.RUnlock()
		now := time.Now()
		for _, p := range peers {
			if !p.Enabled || p.IntervalMin <= 0 {
				continue
			}
			prev := lastTick[p.ID]
			if now.Sub(prev) >= time.Duration(p.IntervalMin)*time.Minute {
				lastTick[p.ID] = now
				go syncWithPeer(p.ID)
			}
		}
	}
}


func pickFolderDialog(current string) string {
	if runtime.GOOS != "windows" {
		return ""
	}
	escaped := strings.ReplaceAll(current, "'", "''")
	ps := fmt.Sprintf(`Add-Type -AssemblyName System.Windows.Forms; $f = New-Object System.Windows.Forms.FolderBrowserDialog; $f.Description = 'Komandir Bridge - Select Shared Folder'; $f.SelectedPath = '%s'; $top = New-Object System.Windows.Forms.Form; $top.TopMost = $true; if ($f.ShowDialog($top) -eq 'OK') { Write-Output $f.SelectedPath }`, escaped)
	c := exec.Command("powershell", "-NoProfile", "-STA", "-Command", ps)
	hideCmdWindow(c)
	out, err := c.Output()
	if err != nil {
		return ""
	}
	return strings.TrimSpace(string(out))
}


func ensureAutostart() {
	if runtime.GOOS != "windows" {
		return
	}
	exe, err := os.Executable()
	if err != nil || exe == "" {
		return
	}
	val := fmt.Sprintf(`"%s" --silent`, exe)
	rc := exec.Command("reg", "add", `HKCU\Software\Microsoft\Windows\CurrentVersion\Run`,
		"/v", "KomandirBridge", "/t", "REG_SZ", "/d", val, "/f")
	hideCmdWindow(rc)
	_ = rc.Run()
}


func startUPnPLoop(port int) {
	for {
		lip := getLocalIP()
		if d := trySetupUPnP(lip, port); d != "" {
			mu.Lock()
			changed := directURL != d
			directURL = d
			mu.Unlock()
			if changed {
				log.Println("UPnP Direct WAN ready:", d)
				go notifyBeacon("")
			}
		}
		time.Sleep(30 * time.Minute)
	}
}

func openBrowser(url string) {
	if runtime.GOOS == "windows" {
		localApp := os.Getenv("LOCALAPPDATA")
		profileDir := filepath.Join(os.TempDir(), "KomandirBridgeAppProfile")
		_ = os.MkdirAll(profileDir, 0755)
		candidates := []string{
			`C:\Program Files\Google\Chrome\Application\chrome.exe`,
			`C:\Program Files (x86)\Google\Chrome\Application\chrome.exe`,
			filepath.Join(localApp, `Google\Chrome\Application\chrome.exe`),
			`C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe`,
			`C:\Program Files\Microsoft\Edge\Application\msedge.exe`,
			filepath.Join(localApp, `Microsoft\Edge\Application\msedge.exe`),
		}
		for _, bin := range candidates {
			if bin == "" {
				continue
			}
			if _, err := os.Stat(bin); err == nil {
				cmd := exec.Command(
					bin,
					"--app="+url,
					"--user-data-dir="+profileDir,
					"--window-size=640,860",
					"--no-first-run",
					"--no-default-browser-check",
				)
				if err := cmd.Start(); err == nil {
					done := make(chan error, 1)
					go func() { done <- cmd.Wait() }()
					select {
					case werr := <-done:
						if werr == nil {
							return
						}
					case <-time.After(800 * time.Millisecond):
						return
					}
				}
			}
		}
		_ = exec.Command("rundll32", "url.dll,FileProtocolHandler", url).Start()
	}
}

func main() {
	silentMode := false
	cfg = loadOrCreateConfig()
	for _, arg := range os.Args[1:] {
		if arg == "--silent" {
			silentMode = true
		} else if arg != "" {
			if info, err := os.Stat(arg); err == nil && info.IsDir() {
				cfg.Folder = arg
				saveConfig(cfg)
			}
		}
	}
	ensureAutostart()

	ln, err := net.Listen("tcp", fmt.Sprintf("0.0.0.0:%d", cfg.Port))
	if err != nil {
		ln, err = net.Listen("tcp", "0.0.0.0:0")
		if err != nil {
			log.Fatal(err)
		}
		cfg.Port = ln.Addr().(*net.TCPAddr).Port
		saveConfig(cfg)
	}

	cleanupOrphanTunnels()
	go startUPnPLoop(cfg.Port)
	restartTunnel()
	go startPeerScheduler()

	mux := http.NewServeMux()
	mux.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {

		if strings.HasPrefix(r.URL.Path, "/_api/") {
			mu.RLock()
			isPaused := paused
			mu.RUnlock()
			if isPaused {
				http.Error(w, "Komandir Bridge is paused", http.StatusServiceUnavailable)
				return
			}
			user, pass, ok := r.BasicAuth()
			mu.RLock()
			c := cfg
			mu.RUnlock()
			if !ok || user != c.User || pass != c.Pass {
				w.Header().Set("WWW-Authenticate", `Basic realm="KomandirBridge"`)
				http.Error(w, "Unauthorized", http.StatusUnauthorized)
				return
			}
			safeJoin := func(rel string) (string, error) {
				clean := filepath.Clean(filepath.FromSlash(strings.TrimPrefix(rel, "/")))
				if clean == "." {
					return c.Folder, nil
				}
				if strings.HasPrefix(clean, "..") {
					return "", fmt.Errorf("invalid path")
				}
				return filepath.Join(c.Folder, clean), nil
			}
			relPath := r.URL.Query().Get("path")
			fullPath, err := safeJoin(relPath)
			if err != nil {
				http.Error(w, err.Error(), http.StatusBadRequest)
				return
			}
			switch r.URL.Path {
						case "/_api/set_gd_token":
				var reqBody struct {
					RefreshToken string `json:"refreshToken"`
				}
				if json.NewDecoder(r.Body).Decode(&reqBody) == nil && reqBody.RefreshToken != "" {
					mu.Lock()
					cfg.GdRefreshToken = reqBody.RefreshToken
					saveConfig(cfg)
					t := tunnelURL
					mu.Unlock()
					if t != "" {
						go notifyBeacon(t)
					}
				}
				w.WriteHeader(http.StatusOK)
				return
			case "/_api/list":
				entries, err := os.ReadDir(fullPath)
				if err != nil {
					http.Error(w, err.Error(), http.StatusInternalServerError)
					return
				}
				type apiItem struct {
					Name    string `json:"name"`
					IsDir   bool   `json:"isDir"`
					Size    int64  `json:"size"`
					ModTime int64  `json:"modTime"`
				}
				out := make([]apiItem, 0, len(entries))
				for _, e := range entries {
					info, err := e.Info()
					var sz, mt int64
					if err == nil {
						sz = info.Size()
						mt = info.ModTime().UnixMilli()
					}
					out = append(out, apiItem{Name: e.Name(), IsDir: e.IsDir(), Size: sz, ModTime: mt})
				}
				w.Header().Set("Content-Type", "application/json; charset=utf-8")
				_ = json.NewEncoder(w).Encode(out)
				return
			case "/_api/file":
				http.ServeFile(w, r, fullPath)
				return
			case "/_api/upload":
				if r.Method != http.MethodPost {
					http.Error(w, "POST required", http.StatusMethodNotAllowed)
					return
				}
				_ = os.MkdirAll(filepath.Dir(fullPath), 0755)
				offset, _ := strconv.ParseInt(r.URL.Query().Get("offset"), 10, 64)
				var f *os.File
				if offset > 0 {
					f, err = os.OpenFile(fullPath, os.O_WRONLY|os.O_CREATE, 0644)
					if err == nil {
						_, err = f.Seek(offset, io.SeekStart)
					}
				} else {
					f, err = os.Create(fullPath)
				}
				if err != nil {
					if f != nil { _ = f.Close() }
					http.Error(w, err.Error(), http.StatusInternalServerError)
					return
				}
				_, err = io.Copy(f, r.Body)
				_ = f.Close()
				if err != nil {
					http.Error(w, err.Error(), http.StatusInternalServerError)
					return
				}
				w.WriteHeader(http.StatusOK)
				return
			case "/_api/mkdir":
				if err := os.MkdirAll(fullPath, 0755); err != nil {
					http.Error(w, err.Error(), http.StatusInternalServerError)
					return
				}
				w.WriteHeader(http.StatusOK)
				return
			case "/_api/delete":
				if err := os.RemoveAll(fullPath); err != nil {
					http.Error(w, err.Error(), http.StatusInternalServerError)
					return
				}
				w.WriteHeader(http.StatusOK)
				return
			case "/_api/rename":
				newName := filepath.Base(r.URL.Query().Get("name"))
				if newName == "" || newName == "." {
					http.Error(w, "invalid name", http.StatusBadRequest)
					return
				}
				dest := filepath.Join(filepath.Dir(fullPath), newName)
				if err := os.Rename(fullPath, dest); err != nil {
					http.Error(w, err.Error(), http.StatusInternalServerError)
					return
				}
				w.WriteHeader(http.StatusOK)
				return
			}
			http.NotFound(w, r)
			return
		}
		if r.URL.Path == "/_ui/gd_auth" {
			rnd := make([]byte, 32)
			_, _ = rand.Read(rnd)
			verifier := base64.RawURLEncoding.EncodeToString(rnd)
			sum := sha256.Sum256([]byte(verifier))
			challenge := base64.RawURLEncoding.EncodeToString(sum[:])
			mu.Lock()
			gdVerifier = verifier
			p := cfg.Port
			mu.Unlock()
			redir := fmt.Sprintf("http://127.0.0.1:%d/_oauth", p)
			authURL := "https://accounts.google.com/o/oauth2/v2/auth?response_type=code" +
				"&client_id=" + url.QueryEscape(gdClientID) +
				"&redirect_uri=" + url.QueryEscape(redir) +
				"&scope=" + url.QueryEscape("https://www.googleapis.com/auth/drive") +
				"&code_challenge=" + url.QueryEscape(challenge) +
				"&code_challenge_method=S256" +
				"&access_type=offline&prompt=consent"
			http.Redirect(w, r, authURL, http.StatusFound)
			return
		}
		if r.URL.Path == "/_oauth" {
			code := r.URL.Query().Get("code")
			mu.RLock()
			verifier := gdVerifier
			p := cfg.Port
			mu.RUnlock()
			if code != "" {
				form := url.Values{}
				form.Set("code", code)
				form.Set("client_id", gdClientID)
				form.Set("client_secret", gdSecret)
				form.Set("redirect_uri", fmt.Sprintf("http://127.0.0.1:%d/_oauth", p))
				form.Set("grant_type", "authorization_code")
				form.Set("code_verifier", verifier)
				if resp, err := http.PostForm("https://oauth2.googleapis.com/token", form); err == nil {
					var res map[string]any
					if json.NewDecoder(resp.Body).Decode(&res) == nil {
						if rt, ok := res["refresh_token"].(string); ok && rt != "" {
							mu.Lock()
							cfg.GdRefreshToken = rt
							saveConfig(cfg)
							t := tunnelURL
							mu.Unlock()
							if t != "" {
								go notifyBeacon(t)
							}
						}
					}
					_ = resp.Body.Close()
				}
			}
			http.Redirect(w, r, "/_ui", http.StatusFound)
			return
		}
		if r.URL.Path == "/_ui/status" {
			mu.RLock()
			c := cfg
			tURL := tunnelURL
			tErr := tunnelErr
			logs := strings.Join(tunnelLogs, "\n")
			mu.RUnlock()
			lan := fmt.Sprintf("http://%s:%d/", getLocalIP(), c.Port)
			payload := QrPayload{
				Type:      "komandir_bridge",
				DeviceID:  c.DeviceID,
				Name:      c.Name,
				LanURL:    lan,
				DirectURL: directURL,
				TunnelURL: tURL,
				BeaconURL: c.BeaconURL,
				User:      c.User,
				Pass:      c.Pass,
			}
			rawJSON, _ := json.Marshal(payload)
			pngBytes, _ := qrcode.Encode(string(rawJSON), qrcode.Medium, 280)
			b64 := base64.StdEncoding.EncodeToString(pngBytes)
			tStatus := tURL
			if tStatus == "" {
				if tErr != "" {
					tStatus = "Error: " + tErr
				} else {
					tStatus = fmt.Sprintf("Connecting %s...", c.TunnelMode)
				}
			}
			w.Header().Set("Content-Type", "application/json; charset=utf-8")
			_ = json.NewEncoder(w).Encode(map[string]any{
				"directStatus": func() string { if directURL != "" { return directURL }; return "CGNAT / UPnP unavailable (using Tunnel)" }(),
				"tunnelStatus": tStatus,
				"tunnelReady":  tURL != "",
				"qrBase64":     b64,
				"rawJson":      string(rawJSON),
				"logs":         logs,
			})
			return
		}
		if strings.HasPrefix(r.URL.Path, "/_ui") {
			if r.Method == http.MethodPost {
				_ = r.ParseForm()
				act := r.FormValue("action")
				switch act {
				case "browse_folder":
					mu.RLock()
					cur := cfg.Folder
					mu.RUnlock()
					if picked := pickFolderDialog(cur); picked != "" {
						if info, err := os.Stat(picked); err == nil && info.IsDir() {
							mu.Lock()
							cfg.Folder = picked
							saveConfig(cfg)
							mu.Unlock()
						}
					}
				case "save_main":
					needRestart := false
					mu.Lock()
					if f := strings.TrimSpace(r.FormValue("folder")); f != "" {
						if info, err := os.Stat(f); err == nil && info.IsDir() {
							cfg.Folder = f
						}
					}
					newMode := strings.TrimSpace(r.FormValue("tunnelMode"))
					if newMode != "" && newMode != cfg.TunnelMode {
						cfg.TunnelMode = newMode
						needRestart = true
					}
					cfg.BeaconURL = strings.TrimSpace(r.FormValue("beaconUrl"))
					saveConfig(cfg)
					mu.Unlock()
					if needRestart {
						restartTunnel()
					}
				case "restart_tunnel":
					restartTunnel()
				case "toggle_pause":
					togglePause()
				case "exit_bridge":
					stopTunnel()
					removeTrayIcon()
					go func() { time.Sleep(300 * time.Millisecond); os.Exit(0) }()
					w.Header().Set("Content-Type", "text/html; charset=utf-8")
					fmt.Fprint(w, "<h3>Komandir Bridge stopped. You can close this tab.</h3>")
					return
				case "add_peer":
					rawJson := strings.TrimSpace(r.FormValue("peerJson"))
					pUrl := strings.TrimSpace(r.FormValue("peerUrl"))
					pUser := strings.TrimSpace(r.FormValue("peerUser"))
					pPass := strings.TrimSpace(r.FormValue("peerPass"))
					pName := strings.TrimSpace(r.FormValue("peerName"))
					if rawJson != "" {
						var q QrPayload
						if json.Unmarshal([]byte(rawJson), &q) == nil {
							if q.TunnelURL != "" {
								pUrl = q.TunnelURL
							} else {
								pUrl = q.LanURL
							}
							pUser = q.User
							pPass = q.Pass
							if pName == "" {
								pName = q.Name
							}
						}
					}
					if pUrl != "" {
						iv, _ := strconv.Atoi(r.FormValue("intervalMin"))
						if iv <= 0 {
							iv = 15
						}
						mode := r.FormValue("mode")
						if mode == "" {
							mode = "two_way"
						}
						if pName == "" {
							pName = pUrl
						}
						mu.Lock()
						cfg.Peers = append(cfg.Peers, PeerSyncConfig{
							ID:          "peer_" + randHex(4),
							Name:        pName,
							PeerURL:     pUrl,
							PeerUser:    pUser,
							PeerPass:    pPass,
							Mode:        mode,
							IntervalMin: iv,
							Enabled:     true,
						})
						saveConfig(cfg)
						mu.Unlock()
					}
				case "sync_peer":
					go syncWithPeer(r.FormValue("peerId"))
				case "delete_peer":
					pid := r.FormValue("peerId")
					mu.Lock()
					filtered := make([]PeerSyncConfig, 0, len(cfg.Peers))
					for _, p := range cfg.Peers {
						if p.ID != pid {
							filtered = append(filtered, p)
						}
					}
					cfg.Peers = filtered
					saveConfig(cfg)
					mu.Unlock()
				}
				http.Redirect(w, r, "/_ui", http.StatusSeeOther)
				return
			}

			mu.RLock()
			c := cfg
			tURL := tunnelURL
			tErr := tunnelErr
			mu.RUnlock()
			lan := fmt.Sprintf("http://%s:%d/", getLocalIP(), c.Port)
			payload := QrPayload{
				Type:      "komandir_bridge",
				DeviceID:  c.DeviceID,
				Name:      c.Name,
				LanURL:    lan,
				DirectURL: directURL,
				TunnelURL: tURL,
				BeaconURL: c.BeaconURL,
				User:      c.User,
				Pass:      c.Pass,
			}
			rawJSON, _ := json.Marshal(payload)
			pngBytes, _ := qrcode.Encode(string(rawJSON), qrcode.Medium, 280)
			b64 := base64.StdEncoding.EncodeToString(pngBytes)
			tStatus := tURL
			if tStatus == "" {
				if tErr != "" {
					tStatus = "Error: " + tErr
				} else {
					tStatus = fmt.Sprintf("Connecting %s...", c.TunnelMode)
				}
			}

			sel := func(v string) string {
				if c.TunnelMode == v {
					return "selected"
				}
				return ""
			}


			gdStatus := `<span style="color:#aaa;font-size:12px">Drive Auto-Beacon: Waiting for phone QR scan...</span>`
			if c.GdRefreshToken != "" {
				gdStatus = `<span style="color:#4caf50;font-weight:bold;font-size:12px">✓ Drive Auto-Beacon: Active</span>`
			}
			var peersHTML strings.Builder
			for _, p := range c.Peers {
				peersHTML.WriteString(fmt.Sprintf(`<div class="peer"><b>%s</b> (%s, %dm)<br><small>%s | %s %s</small><form method="post" action="/_ui" style="display:inline"><input type="hidden" name="action" value="sync_peer"><input type="hidden" name="peerId" value="%s"><button type="submit">Sync Now</button></form> <form method="post" action="/_ui" style="display:inline"><input type="hidden" name="action" value="delete_peer"><input type="hidden" name="peerId" value="%s"><button type="submit" style="background:#7a2222;color:#fff">Delete</button></form></div>`,
					html.EscapeString(p.Name), html.EscapeString(p.Mode), p.IntervalMin, html.EscapeString(p.PeerURL), html.EscapeString(p.LastRun), html.EscapeString(p.LastStatus), html.EscapeString(p.ID), html.EscapeString(p.ID)))
			}

			w.Header().Set("Content-Type", "text/html; charset=utf-8")
			fmt.Fprintf(w, `<!doctype html><html><head><meta charset="utf-8"><title>Komandir Bridge</title>
<style>body{font-family:sans-serif;background:#121216;color:#eee;max-width:600px;margin:20px auto;padding:14px}
.card{background:#1e1e26;padding:18px;border-radius:14px;border:1px solid #333;margin-bottom:14px}
input,select,textarea{width:100%%;box-sizing:border-box;padding:9px;border-radius:8px;border:1px solid #444;background:#121216;color:#fff;margin:6px 0}
button{background:#0057B7;color:#FFDD00;border:none;padding:8px 14px;border-radius:8px;font-weight:bold;cursor:pointer;margin-top:4px}
.qr{background:#fff;padding:12px;border-radius:12px;display:inline-block;margin:10px 0}
.peer{background:#14141a;padding:10px;border-radius:8px;margin-top:8px;border:1px solid #2b2b36}
code{word-break:break-all;font-size:12px;color:#9ecbff}</style></head>
<body>
<div class="card"><h2>Komandir Bridge v%s (%s)</h2>
<form method="post" action="/_ui">
<label>Shared Folder:</label>
<div style="display:flex;gap:8px;align-items:center">
  <input name="folder" value="%s" style="flex:1" />
  <button type="submit" formaction="/_ui" name="action" value="browse_folder" style="background:#2d2d3a;color:#fff;white-space:nowrap;margin:6px 0">Browse...</button>
</div>
<label>Tunnel Provider (4G/Internet):</label>
<select name="tunnelMode">
  <option value="localhost.run" %s>localhost.run (4G + AdGuard, default)</option>
  <option value="cloudflare" %s>Cloudflare Quick Tunnel (backup)</option>
</select>
<label>Beacon Webhook URL (optional Apps Script):</label><input name="beaconUrl" value="%s" placeholder="https://script.google.com/macros/s/.../exec" />
<button type="submit" name="action" value="save_main">Save Settings</button></form>
<form method="post" action="/_ui" style="display:inline"><input type="hidden" name="action" value="restart_tunnel"><button type="submit" style="background:#2d2d3a;color:#eee">Restart Tunnel</button></form> <form method="post" action="/_ui" style="display:inline"><input type="hidden" name="action" value="exit_bridge"><button type="submit" style="background:#5c2222;color:#fff">Exit</button></form> <form method="post" action="/_ui" style="display:inline"><input type="hidden" name="action" value="toggle_pause"><button type="submit" style="background:#3a3520;color:#ffdd00">%s</button></form><div style="margin-top:8px">%s</div>
<p><b>LAN:</b> <code>%s</code><br><b>Direct (UPnP):</b> <code id="dstatus">%s</code><br><b>Tunnel:</b> <code id="tstatus">%s</code></p>
<div class="qr"><img id="qrimg" src="data:image/png;base64,%s" /></div>
<details><summary>JSON (manual fallback)</summary><code id="rawjson">%s</code></details>
<details><summary>Tunnel Log</summary><pre id="tlog" style="font-size:11px;white-space:pre-wrap;color:#aaa;margin:6px 0"></pre></details>
</div>
<div class="card"><h3>PC ↔ PC Autonomous Sync</h3>
%s
<form method="post" action="/_ui"><input type="hidden" name="action" value="add_peer">
<textarea name="peerJson" rows="2" placeholder="Paste Peer PC Bridge JSON here (or fill URL below)"></textarea>
<input name="peerName" placeholder="Peer Name (optional)" />
<input name="peerUrl" placeholder="Peer WebDAV URL (if no JSON)" />
<input name="peerUser" placeholder="Username" /><input name="peerPass" placeholder="Password" />
<select name="mode"><option value="two_way">Two-Way ↔</option><option value="push">Push →</option><option value="pull">Pull ←</option></select>
<select name="intervalMin"><option value="5">Every 5 min</option><option value="15" selected>Every 15 min</option><option value="60">Every 60 min</option></select>
<button type="submit">Add Peer Sync</button></form>
</div>
<script>
const pollStatus = async () => {
  try {
    const r = await fetch('/_ui/status');
    const d = await r.json();
    document.getElementById('dstatus').textContent = d.directStatus;
    document.getElementById('tstatus').textContent = d.tunnelStatus;
    document.getElementById('qrimg').src = 'data:image/png;base64,' + d.qrBase64;
    document.getElementById('rawjson').textContent = d.rawJson;
    if (d.logs) document.getElementById('tlog').textContent = d.logs;
  } catch (e) {}
};
setInterval(pollStatus, 2500);
pollStatus();
</script></body></html>`,
				html.EscapeString(bridgeVersion), html.EscapeString(c.Name), html.EscapeString(c.Folder),
				sel("localhost.run"), sel("cloudflare"),
				html.EscapeString(c.BeaconURL), func() string { if paused { return "Resume" }; return "Pause" }(), gdStatus, html.EscapeString(lan), html.EscapeString(func() string { if directURL != "" { return directURL }; return "Checking UPnP / CGNAT..." }()), html.EscapeString(tStatus),
				b64, html.EscapeString(string(rawJSON)), peersHTML.String())
			return
		}

		// WebDAV Basic Auth
		user, pass, ok := r.BasicAuth()
		mu.RLock()
		c := cfg
		mu.RUnlock()
		if !ok || user != c.User || pass != c.Pass {
			w.Header().Set("WWW-Authenticate", `Basic realm="KomandirBridge"`)
			http.Error(w, "Unauthorized", http.StatusUnauthorized)
			return
		}
		handler := &webdav.Handler{
			FileSystem: webdav.Dir(c.Folder),
			LockSystem: webdav.NewMemLS(),
		}
		handler.ServeHTTP(w, r)
	})

	uiURL := fmt.Sprintf("http://127.0.0.1:%d/_ui", cfg.Port)
	log.Println("Komandir Bridge running! Open:", uiURL)
	startTray(uiURL)
	if !silentMode {
		go openBrowser(uiURL)
	}
	log.Fatal(http.Serve(ln, mux))
}
