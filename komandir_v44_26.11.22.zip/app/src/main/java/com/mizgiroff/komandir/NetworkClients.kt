package com.mizgiroff.komandir

import android.content.Context
import android.net.Uri
import android.util.Xml
import androidx.documentfile.provider.DocumentFile
import com.hierynomus.smbj.SMBClient
import com.hierynomus.smbj.auth.AuthenticationContext
import com.hierynomus.smbj.share.DiskShare
import com.hierynomus.msdtyp.AccessMask
import com.hierynomus.mssmb2.SMB2CreateDisposition
import com.hierynomus.mssmb2.SMB2ShareAccess
import okhttp3.RequestBody.Companion.asRequestBody
import java.util.EnumSet
import okhttp3.Credentials
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.apache.commons.net.ftp.FTP
import org.apache.commons.net.ftp.FTPClient
import org.xmlpull.v1.XmlPullParser
import java.io.StringReader
import java.util.concurrent.TimeUnit

data class DirResult(
    val entries: List<FileEntry> = emptyList(),
    val error: String? = null
)

fun listSafDirectory(context: Context, docUriStr: String): DirResult {
    return try {
        val uri = Uri.parse(docUriStr)
        val doc = DocumentFile.fromTreeUri(context, uri)
            ?: DocumentFile.fromSingleUri(context, uri)
            ?: return DirResult(error = "Cannot open folder")
        val list = doc.listFiles()
            .sortedWith(compareBy<DocumentFile> { !it.isDirectory }.thenBy { (it.name ?: "").lowercase() })
            .map { f ->
                FileEntry(
                    id = f.uri.toString(),
                    name = f.name ?: "Unnamed",
                    path = f.uri.toString(),
                    isDirectory = f.isDirectory,
                    sizeBytes = if (f.isDirectory) 0L else f.length(),
                    lastModified = f.lastModified(),
                    subtitle = if (f.isDirectory) "Folder" else formatFileSize(f.length())
                )
            }
        DirResult(entries = list)
    } catch (e: Exception) {
        DirResult(error = e.message ?: "SAF access error")
    }
}

private val webDavClient: OkHttpClient by lazy {
    OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()
}

fun listWebDavDirectory(source: StorageSource, currentUrl: String): DirResult {
    return try {
        val targetUrl = if (currentUrl.endsWith("/")) currentUrl else "$currentUrl/"
        val propBody = """<?xml version="1.0" encoding="utf-8" ?>
            <D:propfind xmlns:D="DAV:">
                <D:prop>
                    <D:displayname/>
                    <D:getcontentlength/>
                    <D:resourcetype/>
                </D:prop>
            </D:propfind>""".trimIndent().toRequestBody("application/xml".toMediaType())

        val reqBuilder = Request.Builder()
            .url(targetUrl)
            .method("PROPFIND", propBody)
            .header("Depth", "1")
        if (source.username.isNotBlank()) {
            reqBuilder.header("Authorization", Credentials.basic(source.username, source.password))
        }
        webDavClient.newCall(reqBuilder.build()).execute().use { resp ->
            if (!resp.isSuccessful && resp.code != 207) {
                return DirResult(error = "HTTP ${resp.code}: ${resp.message}")
            }
            val xml = resp.body?.string() ?: return DirResult(emptyList())
            val parsed = parseWebDavXml(xml, targetUrl)
            DirResult(entries = parsed)
        }
    } catch (e: Exception) {
        DirResult(error = e.message ?: "WebDAV error")
    }
}

private fun parseWebDavXml(xml: String, baseUrl: String): List<FileEntry> {
    val entries = mutableListOf<FileEntry>()
    val parser = Xml.newPullParser()
    parser.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, true)
    parser.setInput(StringReader(xml))

    var href = ""
    var displayName = ""
    var contentLength = 0L
    var isDir = false
    var inResponse = false
    var currentTag = ""

    val baseUri = Uri.parse(baseUrl)
    val basePath = (baseUri.path ?: "/").trimEnd('/')

    var event = parser.eventType
    while (event != XmlPullParser.END_DOCUMENT) {
        when (event) {
            XmlPullParser.START_TAG -> {
                currentTag = parser.name ?: ""
                if (currentTag == "response") {
                    inResponse = true
                    href = ""
                    displayName = ""
                    contentLength = 0L
                    isDir = false
                } else if (inResponse && currentTag == "collection") {
                    isDir = true
                }
            }
            XmlPullParser.TEXT -> {
                if (inResponse) {
                    val txt = parser.text?.trim() ?: ""
                    when (currentTag) {
                        "href" -> if (href.isEmpty()) href = txt
                        "displayname" -> if (displayName.isEmpty()) displayName = txt
                        "getcontentlength" -> contentLength = txt.toLongOrNull() ?: 0L
                    }
                }
            }
            XmlPullParser.END_TAG -> {
                if (parser.name == "response" && inResponse) {
                    inResponse = false
                    val decodedHref = Uri.decode(href).trimEnd('/')
                    val itemPath = if (decodedHref.startsWith("http")) Uri.parse(decodedHref).path?.trimEnd('/') ?: decodedHref else decodedHref
                    if (itemPath != basePath && itemPath.isNotEmpty()) {
                        val fullUrl = if (href.startsWith("http")) href else "${baseUri.scheme}://${baseUri.encodedAuthority}$href"
                        val name = displayName.ifBlank { itemPath.substringAfterLast('/') }
                        if (name.isNotBlank()) {
                            entries.add(
                                FileEntry(
                                    id = fullUrl,
                                    name = name,
                                    path = fullUrl,
                                    isDirectory = isDir,
                                    sizeBytes = contentLength,
                                    lastModified = 0L,
                                    subtitle = if (isDir) "WebDAV" else formatFileSize(contentLength)
                                )
                            )
                        }
                    }
                }
                currentTag = ""
            }
        }
        event = parser.next()
    }
    return entries.sortedWith(compareBy<FileEntry> { !it.isDirectory }.thenBy { it.name.lowercase() })
}

fun listFtpDirectory(source: StorageSource, path: String): DirResult {
    val client = FTPClient()
    return try {
        val cleanHost = source.host.removePrefix("ftp://").substringBefore("/")
        val hostPart = cleanHost.substringBefore(":")
        val port = cleanHost.substringAfter(":", "21").toIntOrNull() ?: 21
        client.connectTimeout = 10000
        client.connect(hostPart, port)
        val user = source.username.ifBlank { "anonymous" }
        val pass = source.password.ifBlank { "" }
        if (!client.login(user, pass)) {
            return DirResult(error = "FTP login failed (${client.replyCode})")
        }
        client.enterLocalPassiveMode()
        client.setFileType(FTP.BINARY_FILE_TYPE)
        val targetPath = path.ifBlank { "/" }
        val files = client.listFiles(targetPath)
        val entries = files
            .filter { it.name != "." && it.name != ".." }
            .sortedWith(compareBy<org.apache.commons.net.ftp.FTPFile> { !it.isDirectory }.thenBy { it.name.lowercase() })
            .map { f ->
                val childPath = if (targetPath.endsWith("/")) "$targetPath${f.name}" else "$targetPath/${f.name}"
                FileEntry(
                    id = childPath,
                    name = f.name,
                    path = childPath,
                    isDirectory = f.isDirectory,
                    sizeBytes = f.size,
                    lastModified = f.timestamp?.timeInMillis ?: 0L,
                    subtitle = if (f.isDirectory) "FTP" else formatFileSize(f.size)
                )
            }
        DirResult(entries = entries)
    } catch (e: Exception) {
        DirResult(error = e.message ?: "FTP connection error")
    } finally {
        runCatching {
            if (client.isConnected) {
                client.logout()
                client.disconnect()
            }
        }
    }
}

fun listSmbDirectory(source: StorageSource, path: String): DirResult {
    val client = SMBClient()
    return try {
        val raw = source.host.removePrefix("smb://").replace('\\', '/').trimStart('/')
        val cleanHost = raw.substringBefore("/")
        val share = source.shareName.ifBlank {
            raw.substringAfter("/", "").substringBefore("/")
        }
        if (cleanHost.isBlank() || share.isBlank()) {
            return DirResult(error = "Specify host and share name (e.g. 192.168.1.50 and Public)")
        }
        client.connect(cleanHost).use { conn ->
            val auth = if (source.username.isBlank()) {
                AuthenticationContext.guest()
            } else {
                AuthenticationContext(source.username, source.password.toCharArray(), "")
            }
            val session = conn.authenticate(auth)
            (session.connectShare(share) as DiskShare).use { diskShare ->
                val relPath = path.trim('/').replace('/', '\\')
                val dirAttr = 0x10L
                val items = diskShare.list(relPath)
                    .filter { it.fileName != "." && it.fileName != ".." }
                    .sortedWith(compareBy<com.hierynomus.msfscc.fileinformation.FileIdBothDirectoryInformation> {
                        (it.fileAttributes and dirAttr) == 0L
                    }.thenBy { it.fileName.lowercase() })
                    .map { info ->
                        val isDir = (info.fileAttributes and dirAttr) != 0L
                        val nextPath = if (path.isBlank() || path == "/") info.fileName else "${path.trimEnd('/')}/${info.fileName}"
                        FileEntry(
                            id = nextPath,
                            name = info.fileName,
                            path = nextPath,
                            isDirectory = isDir,
                            sizeBytes = info.endOfFile,
                            lastModified = 0L,
                            subtitle = if (isDir) "SMB" else formatFileSize(info.endOfFile)
                        )
                    }
                DirResult(entries = items)
            }
        }
    } catch (e: Exception) {
        DirResult(error = e.message ?: "SMB connection error")
    } finally {
        runCatching { client.close() }
    }
}


fun generatePkcePair(): Pair<String, String> {
    val bytes = ByteArray(32)
    java.security.SecureRandom().nextBytes(bytes)
    val flags = android.util.Base64.URL_SAFE or android.util.Base64.NO_WRAP or android.util.Base64.NO_PADDING
    val verifier = android.util.Base64.encodeToString(bytes, flags)
    val digest = java.security.MessageDigest.getInstance("SHA-256").digest(verifier.toByteArray(Charsets.US_ASCII))
    val challenge = android.util.Base64.encodeToString(digest, flags)
    return verifier to challenge
}

fun exchangeGoogleAuthCode(
    clientId: String,
    clientSecret: String,
    code: String,
    verifier: String,
    redirectUri: String
): Pair<String, String>? {
    return try {
        val fb = okhttp3.FormBody.Builder()
            .add("client_id", clientId)
            .add("code", code)
            .add("code_verifier", verifier)
            .add("redirect_uri", redirectUri)
            .add("grant_type", "authorization_code")
        if (clientSecret.isNotBlank()) fb.add("client_secret", clientSecret)
        val body = fb.build()
        val req = Request.Builder()
            .url("https://oauth2.googleapis.com/token")
            .post(body)
            .build()
        webDavClient.newCall(req).execute().use { resp ->
            val txt = resp.body?.string() ?: return null
            if (!resp.isSuccessful) return null
            val json = org.json.JSONObject(txt)
            val access = json.optString("access_token", "")
            val refresh = json.optString("refresh_token", "")
            if (access.isBlank()) null else access to refresh
        }
    } catch (_: Exception) {
        null
    }
}

private fun refreshGoogleToken(clientId: String, clientSecret: String, refreshToken: String): String? {
    if (clientId.isBlank() || refreshToken.isBlank()) return null
    return try {
        val fb = okhttp3.FormBody.Builder()
            .add("client_id", clientId)
            .add("refresh_token", refreshToken)
            .add("grant_type", "refresh_token")
        if (clientSecret.isNotBlank()) fb.add("client_secret", clientSecret)
        val body = fb.build()
        val req = Request.Builder()
            .url("https://oauth2.googleapis.com/token")
            .post(body)
            .build()
        webDavClient.newCall(req).execute().use { resp ->
            val txt = resp.body?.string() ?: return null
            if (!resp.isSuccessful) return null
            org.json.JSONObject(txt).optString("access_token", "").takeIf { it.isNotBlank() }
        }
    } catch (_: Exception) {
        null
    }
}

fun listGoogleDriveDirectory(context: Context, folderId: String): DirResult {
    var token = KomandirPrefs.getGdAccessToken(context)
    val clientId = KomandirPrefs.getGdClientId(context)
    val refresh = KomandirPrefs.getGdRefreshToken(context)
    if (token.isBlank()) {
        return DirResult(error = "Sign in to Google Drive first")
    }
    val targetFolder = folderId.ifBlank { "root" }
    val query = Uri.encode("'$targetFolder' in parents and trashed = false")
    val url = "https://www.googleapis.com/drive/v3/files?q=$query&pageSize=100&fields=files(id,name,mimeType,size)&orderBy=folder,name"

    fun callDrive(bearer: String): okhttp3.Response {
        val req = Request.Builder()
            .url(url)
            .header("Authorization", "Bearer $bearer")
            .build()
        return webDavClient.newCall(req).execute()
    }

    return try {
        var resp = callDrive(token)
        if (resp.code == 401 && refresh.isNotBlank()) {
            resp.close()
            val newToken = refreshGoogleToken(clientId, KomandirPrefs.getGdClientSecret(context).ifBlank { if (clientId == KomandirPrefs.DEFAULT_GD_CLIENT_ID) KomandirPrefs.DEFAULT_GD_CLIENT_SECRET else "" }, refresh)
            if (newToken != null) {
                KomandirPrefs.saveGdTokens(context, newToken, "")
                token = newToken
                resp = callDrive(token)
            }
        }
        resp.use { r ->
            if (!r.isSuccessful) {
                return DirResult(error = "Drive API ${r.code}: ${r.message}")
            }
            val bodyStr = r.body?.string() ?: return DirResult(emptyList())
            val arr = org.json.JSONObject(bodyStr).optJSONArray("files") ?: return DirResult(emptyList())
            val list = mutableListOf<FileEntry>()
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                val id = obj.getString("id")
                val name = obj.getString("name")
                val mime = obj.optString("mimeType", "")
                val isDir = mime == "application/vnd.google-apps.folder"
                val size = obj.optString("size", "0").toLongOrNull() ?: 0L
                list.add(
                    FileEntry(
                        id = id,
                        name = name,
                        path = id,
                        isDirectory = isDir,
                        sizeBytes = size,
                        lastModified = 0L,
                        subtitle = if (isDir) "Google Drive" else if (size > 0L) formatFileSize(size) else "Google Doc"
                    )
                )
            }
            DirResult(entries = list)
        }
    } catch (e: Exception) {
        DirResult(error = e.message ?: "Google Drive error")
    }
}


fun runGoogleOAuthLoopback(
    clientId: String,
    clientSecret: String,
    onOpenUrl: (String) -> Unit
): Pair<String, String>? {
    val server = java.net.ServerSocket(0, 1, java.net.InetAddress.getByName("127.0.0.1"))
    return try {
        server.soTimeout = 180_000
        val port = server.localPort
        val redirectUri = "http://127.0.0.1:$port"
        val (verifier, challenge) = generatePkcePair()
        val authUrl = "https://accounts.google.com/o/oauth2/v2/auth" +
            "?client_id=${Uri.encode(clientId)}" +
            "&redirect_uri=${Uri.encode(redirectUri)}" +
            "&response_type=code" +
            "&scope=${Uri.encode("https://www.googleapis.com/auth/drive")}" +
            "&access_type=offline&prompt=consent" +
            "&code_challenge=$challenge&code_challenge_method=S256"

        onOpenUrl(authUrl)

        var authCode = ""
        while (authCode.isBlank()) {
            val socket = server.accept()
            socket.use { s ->
                s.soTimeout = 5_000
                val reader = java.io.BufferedReader(java.io.InputStreamReader(s.getInputStream()))
                val requestLine = reader.readLine() ?: ""
                while (true) {
                    val hdr = reader.readLine()
                    if (hdr.isNullOrEmpty()) break
                }
                val queryPart = requestLine.substringAfter("GET ", "").substringBefore(" HTTP")
                val parsedUri = Uri.parse("http://127.0.0.1$queryPart")
                val candidate = parsedUri.getQueryParameter("code") ?: ""
                if (candidate.isNotBlank()) {
                    authCode = candidate
                    val html = "<html><head><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\"></head>" +
                        "<body style=\"font-family:sans-serif;text-align:center;padding:40px;background:#121216;color:#fff;\">" +
                        "<h2>Komandir</h2><p>Google Drive connected ✓</p>" +
                        "<p style=\"margin-top:24px;\"><a href=\"com.mizgiroff.komandir://oauth2done\" style=\"display:inline-block;padding:14px 28px;background:#0057B7;color:#FFDD00;text-decoration:none;border-radius:10px;font-weight:bold;\">Open Komandir</a></p>" +
                        "<script>setTimeout(function(){ window.location.replace(\"intent://oauth2done#Intent;scheme=com.mizgiroff.komandir;package=com.mizgiroff.komandir;end\"); }, 80); setTimeout(function(){ window.location.href = \"com.mizgiroff.komandir://oauth2done\"; }, 350); setTimeout(function(){ window.close(); }, 900);</script>" +
                        "</body></html>"
                    val htmlBytes = html.toByteArray(Charsets.UTF_8)
                    val httpResp = "HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=UTF-8\r\nContent-Length: ${htmlBytes.size}\r\nConnection: close\r\n\r\n"
                    val out = s.getOutputStream()
                    out.write(httpResp.toByteArray(Charsets.UTF_8))
                    out.write(htmlBytes)
                    out.flush()
                    runCatching { s.shutdownOutput() }
                } else {
                    val emptyResp = "HTTP/1.1 204 No Content\r\nConnection: close\r\n\r\n"
                    val out = s.getOutputStream()
                    out.write(emptyResp.toByteArray(Charsets.UTF_8))
                    out.flush()
                    runCatching { s.shutdownOutput() }
                }
            }
        }

        // Briefly drain any trailing browser requests (e.g. favicon.ico) so Chrome never sees ERR_CONNECTION_REFUSED
        Thread {
            runCatching {
                server.soTimeout = 1500
                val deadline = System.currentTimeMillis() + 2000
                while (System.currentTimeMillis() < deadline) {
                    val extra = runCatching { server.accept() }.getOrNull() ?: break
                    extra.use { es ->
                        es.soTimeout = 500
                        val er = java.io.BufferedReader(java.io.InputStreamReader(es.getInputStream()))
                        while (true) {
                            val l = er.readLine()
                            if (l.isNullOrEmpty()) break
                        }
                        val eo = es.getOutputStream()
                        eo.write("HTTP/1.1 204 No Content\r\nConnection: close\r\n\r\n".toByteArray(Charsets.UTF_8))
                        eo.flush()
                        runCatching { es.shutdownOutput() }
                    }
                }
            }
            runCatching { server.close() }
        }.start()

        exchangeGoogleAuthCode(clientId, clientSecret, authCode, verifier, redirectUri)
    } catch (_: Exception) {
        runCatching { server.close() }
        null
    }
}


private fun getValidGdToken(context: Context): String? {
    var token = KomandirPrefs.getGdAccessToken(context)
    if (token.isNotBlank()) return token
    val clientId = KomandirPrefs.getGdClientId(context)
    val refresh = KomandirPrefs.getGdRefreshToken(context)
    val secret = KomandirPrefs.getGdClientSecret(context).ifBlank { if (clientId == KomandirPrefs.DEFAULT_GD_CLIENT_ID) KomandirPrefs.DEFAULT_GD_CLIENT_SECRET else "" }
    val newToken = refreshGoogleToken(clientId, secret, refresh)
    if (newToken != null) {
        KomandirPrefs.saveGdTokens(context, newToken, "")
        token = newToken
    }
    return token.ifBlank { null }
}

private fun executeGdWithRefresh(context: Context, buildReq: (String) -> Request): okhttp3.Response? {
    var token = getValidGdToken(context) ?: return null
    var resp = webDavClient.newCall(buildReq(token)).execute()
    if (resp.code == 401) {
        resp.close()
        val clientId = KomandirPrefs.getGdClientId(context)
        val refresh = KomandirPrefs.getGdRefreshToken(context)
        val secret = KomandirPrefs.getGdClientSecret(context).ifBlank { if (clientId == KomandirPrefs.DEFAULT_GD_CLIENT_ID) KomandirPrefs.DEFAULT_GD_CLIENT_SECRET else "" }
        val newToken = refreshGoogleToken(clientId, secret, refresh) ?: return null
        KomandirPrefs.saveGdTokens(context, newToken, "")
        resp = webDavClient.newCall(buildReq(newToken)).execute()
    }
    return resp
}

fun downloadGoogleDriveEntry(context: Context, entry: FileEntry, destDir: java.io.File): Int {
    if (!destDir.exists()) destDir.mkdirs()
    if (entry.isDirectory) {
        val subDir = java.io.File(destDir, entry.name)
        if (!subDir.exists()) subDir.mkdirs()
        val children = listGoogleDriveDirectory(context, entry.id).entries
        var total = 0
        children.forEach { child ->
            total += downloadGoogleDriveEntry(context, child, subDir)
        }
        return total
    } else {
        val isGDoc = entry.subtitle == "Google Doc"
        val url = if (isGDoc) {
            "https://www.googleapis.com/drive/v3/files/${entry.id}/export?mimeType=application/pdf"
        } else {
            "https://www.googleapis.com/drive/v3/files/${entry.id}?alt=media"
        }
        val outName = if (isGDoc && !entry.name.lowercase().endsWith(".pdf")) "${entry.name}.pdf" else entry.name
        val outFile = java.io.File(destDir, outName)
        val resp = executeGdWithRefresh(context) { bearer ->
            Request.Builder().url(url).header("Authorization", "Bearer $bearer").build()
        } ?: return 0
        resp.use { r ->
            if (!r.isSuccessful) return 0
            r.body?.byteStream()?.use { input ->
                java.io.FileOutputStream(outFile).use { output ->
                    input.copyTo(output)
                }
            }
        }
        return 1
    }
}

fun createGoogleDriveFolder(context: Context, name: String, parentId: String): String? {
    val metaJson = org.json.JSONObject().apply {
        put("name", name)
        put("mimeType", "application/vnd.google-apps.folder")
        put("parents", org.json.JSONArray().put(parentId.ifBlank { "root" }))
    }.toString()
    val body = metaJson.toRequestBody("application/json; charset=utf-8".toMediaType())
    val resp = executeGdWithRefresh(context) { bearer ->
        Request.Builder()
            .url("https://www.googleapis.com/drive/v3/files")
            .header("Authorization", "Bearer $bearer")
            .post(body)
            .build()
    } ?: return null
    return resp.use { r ->
        if (!r.isSuccessful) null
        else org.json.JSONObject(r.body?.string() ?: "{}").optString("id", "").takeIf { it.isNotBlank() }
    }
}

fun uploadFileToGoogleDrive(context: Context, localFile: java.io.File, parentFolderId: String): Int {
    val targetParent = parentFolderId.ifBlank { "root" }
    if (localFile.isDirectory) {
        val newFolderId = createGoogleDriveFolder(context, localFile.name, targetParent) ?: return 0
        var count = 0
        localFile.listFiles()?.forEach { child ->
            count += uploadFileToGoogleDrive(context, child, newFolderId)
        }
        return count
    } else {
        val metaJson = org.json.JSONObject().apply {
            put("name", localFile.name)
            put("parents", org.json.JSONArray().put(targetParent))
        }.toString()
        val multipart = okhttp3.MultipartBody.Builder()
            .setType("multipart/related".toMediaType())
            .addPart(metaJson.toRequestBody("application/json; charset=utf-8".toMediaType()))
            .addPart(okhttp3.RequestBody.create("application/octet-stream".toMediaType(), localFile))
            .build()
        val resp = executeGdWithRefresh(context) { bearer ->
            Request.Builder()
                .url("https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart")
                .header("Authorization", "Bearer $bearer")
                .post(multipart)
                .build()
        } ?: return 0
        return resp.use { if (it.isSuccessful) 1 else 0 }
    }
}

// --- Google Drive: копирование, перемещение, удаление, переименование ---
fun copyGoogleDriveEntry(context: Context, entry: FileEntry, destParentId: String): Int {
    val targetParent = destParentId.ifBlank { "root" }
    if (entry.isDirectory) {
        val newFolderId = createGoogleDriveFolder(context, entry.name, targetParent) ?: return 0
        val children = listGoogleDriveDirectory(context, entry.id).entries
        var total = 0
        children.forEach { child ->
            total += copyGoogleDriveEntry(context, child, newFolderId)
        }
        return total.coerceAtLeast(1)
    } else {
        val metaJson = org.json.JSONObject().apply {
            put("name", entry.name)
            put("parents", org.json.JSONArray().put(targetParent))
        }.toString()
        val body = metaJson.toRequestBody("application/json; charset=utf-8".toMediaType())
        val resp = executeGdWithRefresh(context) { bearer ->
            Request.Builder()
                .url("https://www.googleapis.com/drive/v3/files/${entry.id}/copy")
                .header("Authorization", "Bearer $bearer")
                .post(body)
                .build()
        } ?: return 0
        return resp.use { if (it.isSuccessful) 1 else 0 }
    }
}

fun moveGoogleDriveEntry(context: Context, entry: FileEntry, srcParentId: String, destParentId: String): Int {
    val addParent = Uri.encode(destParentId.ifBlank { "root" })
    val removeParent = Uri.encode(srcParentId.ifBlank { "root" })
    val url = "https://www.googleapis.com/drive/v3/files/${entry.id}?addParents=$addParent&removeParents=$removeParent"
    val body = "{}".toRequestBody("application/json; charset=utf-8".toMediaType())
    val resp = executeGdWithRefresh(context) { bearer ->
        Request.Builder()
            .url(url)
            .header("Authorization", "Bearer $bearer")
            .patch(body)
            .build()
    } ?: return 0
    return resp.use { if (it.isSuccessful) 1 else 0 }
}

fun deleteGoogleDriveEntry(context: Context, fileId: String): Boolean {
    val resp = executeGdWithRefresh(context) { bearer ->
        Request.Builder()
            .url("https://www.googleapis.com/drive/v3/files/$fileId")
            .header("Authorization", "Bearer $bearer")
            .delete()
            .build()
    } ?: return false
    return resp.use { it.isSuccessful }
}

fun renameGoogleDriveEntry(context: Context, fileId: String, newName: String): Boolean {
    val metaJson = org.json.JSONObject().apply { put("name", newName) }.toString()
    val body = metaJson.toRequestBody("application/json; charset=utf-8".toMediaType())
    val resp = executeGdWithRefresh(context) { bearer ->
        Request.Builder()
            .url("https://www.googleapis.com/drive/v3/files/$fileId")
            .header("Authorization", "Bearer $bearer")
            .patch(body)
            .build()
    } ?: return false
    return resp.use { it.isSuccessful }
}

// --- WebDAV: полный цикл операций ---
private fun webDavReqBuilder(source: StorageSource, url: String): Request.Builder {
    val b = Request.Builder().url(url)
    if (source.username.isNotBlank()) {
        b.header("Authorization", Credentials.basic(source.username, source.password))
    }
    return b
}

fun createWebDavFolder(source: StorageSource, parentUrl: String, folderName: String): Boolean {
    val cleanBase = parentUrl.trimEnd('/')
    val url = "$cleanBase/${Uri.encode(folderName)}/"
    return runCatching {
        val req = webDavReqBuilder(source, url).method("MKCOL", null).build()
        webDavClient.newCall(req).execute().use { it.isSuccessful }
    }.getOrDefault(false)
}

fun downloadWebDavEntry(source: StorageSource, entry: FileEntry, destDir: java.io.File): Int {
    if (!destDir.exists()) destDir.mkdirs()
    if (entry.isDirectory) {
        val sub = java.io.File(destDir, entry.name).apply { mkdirs() }
        val children = listWebDavDirectory(source, entry.path).entries
        return children.sumOf { downloadWebDavEntry(source, it, sub) }
    } else {
        return runCatching {
            val req = webDavReqBuilder(source, entry.path).get().build()
            webDavClient.newCall(req).execute().use { r ->
                if (!r.isSuccessful) return 0
                val outFile = java.io.File(destDir, entry.name)
                r.body?.byteStream()?.use { inp ->
                    outFile.outputStream().use { out -> inp.copyTo(out) }
                }
                1
            }
        }.getOrDefault(0)
    }
}

fun uploadFileToWebDav(source: StorageSource, localFile: java.io.File, destDirUrl: String): Int {
    val cleanBase = destDirUrl.trimEnd('/')
    val targetUrl = "$cleanBase/${Uri.encode(localFile.name)}"
    if (localFile.isDirectory) {
        createWebDavFolder(source, cleanBase, localFile.name)
        return localFile.listFiles()?.sumOf { uploadFileToWebDav(source, it, "$targetUrl/") } ?: 0
    } else {
        return runCatching {
            val body = localFile.asRequestBody("application/octet-stream".toMediaType())
            val req = webDavReqBuilder(source, targetUrl).put(body).build()
            webDavClient.newCall(req).execute().use { if (it.isSuccessful) 1 else 0 }
        }.getOrDefault(0)
    }
}

fun deleteWebDavEntry(source: StorageSource, entryUrl: String): Boolean {
    return runCatching {
        val req = webDavReqBuilder(source, entryUrl).delete().build()
        webDavClient.newCall(req).execute().use { it.isSuccessful }
    }.getOrDefault(false)
}

fun renameWebDavEntry(source: StorageSource, entryUrl: String, newName: String): Boolean {
    return runCatching {
        val trimmed = entryUrl.trimEnd('/')
        val parent = trimmed.substringBeforeLast("/", "")
        val dest = "$parent/${Uri.encode(newName)}" + if (entryUrl.endsWith("/")) "/" else ""
        val req = webDavReqBuilder(source, entryUrl)
            .method("MOVE", null)
            .header("Destination", dest)
            .header("Overwrite", "T")
            .build()
        webDavClient.newCall(req).execute().use { it.isSuccessful }
    }.getOrDefault(false)
}

// --- FTP: полный цикл операций ---
private fun connectFtp(source: StorageSource): FTPClient {
    val ftp = FTPClient()
    ftp.connectTimeout = 10000
    ftp.connect(source.host, 21)
    ftp.login(source.username.ifBlank { "anonymous" }, source.password)
    ftp.enterLocalPassiveMode()
    ftp.setFileType(FTP.BINARY_FILE_TYPE)
    return ftp
}

fun createFtpFolder(source: StorageSource, parentPath: String, folderName: String): Boolean {
    val ftp = connectFtp(source)
    return runCatching {
        val target = if (parentPath == "/") "/$folderName" else "${parentPath.trimEnd('/')}/$folderName"
        ftp.makeDirectory(target)
    }.getOrDefault(false).also { runCatching { ftp.logout(); ftp.disconnect() } }
}

fun downloadFtpEntry(source: StorageSource, entry: FileEntry, destDir: java.io.File): Int {
    if (!destDir.exists()) destDir.mkdirs()
    if (entry.isDirectory) {
        val sub = java.io.File(destDir, entry.name).apply { mkdirs() }
        val children = listFtpDirectory(source, entry.path).entries
        return children.sumOf { downloadFtpEntry(source, it, sub) }
    } else {
        val ftp = connectFtp(source)
        return runCatching {
            val outFile = java.io.File(destDir, entry.name)
            outFile.outputStream().use { out ->
                if (ftp.retrieveFile(entry.path, out)) 1 else 0
            }
        }.getOrDefault(0).also { runCatching { ftp.logout(); ftp.disconnect() } }
    }
}

fun uploadFileToFtp(source: StorageSource, localFile: java.io.File, destDirPath: String): Int {
    val targetPath = if (destDirPath == "/") "/${localFile.name}" else "${destDirPath.trimEnd('/')}/${localFile.name}"
    if (localFile.isDirectory) {
        createFtpFolder(source, destDirPath, localFile.name)
        return localFile.listFiles()?.sumOf { uploadFileToFtp(source, it, targetPath) } ?: 0
    } else {
        val ftp = connectFtp(source)
        return runCatching {
            localFile.inputStream().use { inp ->
                if (ftp.storeFile(targetPath, inp)) 1 else 0
            }
        }.getOrDefault(0).also { runCatching { ftp.logout(); ftp.disconnect() } }
    }
}

fun deleteFtpEntry(source: StorageSource, entry: FileEntry): Boolean {
    val ftp = connectFtp(source)
    return runCatching {
        if (entry.isDirectory) {
            val children = listFtpDirectory(source, entry.path).entries
            children.forEach { deleteFtpEntry(source, it) }
            ftp.removeDirectory(entry.path)
        } else {
            ftp.deleteFile(entry.path)
        }
    }.getOrDefault(false).also { runCatching { ftp.logout(); ftp.disconnect() } }
}

fun renameFtpEntry(source: StorageSource, oldPath: String, newName: String): Boolean {
    val ftp = connectFtp(source)
    return runCatching {
        val parent = oldPath.substringBeforeLast("/", "")
        val newPath = if (parent.isEmpty()) "/$newName" else "$parent/$newName"
        ftp.rename(oldPath, newPath)
    }.getOrDefault(false).also { runCatching { ftp.logout(); ftp.disconnect() } }
}

// --- SMB 2/3: полный цикл операций ---
private fun <T> withSmbShare(source: StorageSource, block: (DiskShare) -> T): T {
    val client = SMBClient()
    return client.connect(source.host).use { conn ->
        val auth = if (source.username.isBlank()) AuthenticationContext.anonymous()
        else AuthenticationContext(source.username, source.password.toCharArray(), "")
        val session = conn.authenticate(auth)
        val shareName = source.shareName.ifBlank { "Shared" }
        (session.connectShare(shareName) as DiskShare).use(block)
    }
}

fun createSmbFolder(source: StorageSource, parentPath: String, folderName: String): Boolean {
    return runCatching {
        withSmbShare(source) { share ->
            val p = if (parentPath.isBlank()) folderName else "${parentPath.trimEnd('\\')}\\$folderName"
            share.mkdir(p)
            true
        }
    }.getOrDefault(false)
}

fun downloadSmbEntry(source: StorageSource, entry: FileEntry, destDir: java.io.File): Int {
    if (!destDir.exists()) destDir.mkdirs()
    if (entry.isDirectory) {
        val sub = java.io.File(destDir, entry.name).apply { mkdirs() }
        val children = listSmbDirectory(source, entry.path).entries
        return children.sumOf { downloadSmbEntry(source, it, sub) }
    } else {
        return runCatching {
            withSmbShare(source) { share ->
                val f = share.openFile(
                    entry.path,
                    EnumSet.of(AccessMask.GENERIC_READ),
                    null,
                    SMB2ShareAccess.ALL,
                    SMB2CreateDisposition.FILE_OPEN,
                    null
                )
                f.use { remote ->
                    val outFile = java.io.File(destDir, entry.name)
                    remote.inputStream.use { inp ->
                        outFile.outputStream().use { out -> inp.copyTo(out) }
                    }
                }
                1
            }
        }.getOrDefault(0)
    }
}

fun uploadFileToSmb(source: StorageSource, localFile: java.io.File, destDirPath: String): Int {
    val cleanParent = destDirPath.trimEnd('\\')
    val targetPath = if (cleanParent.isBlank()) localFile.name else "$cleanParent\\${localFile.name}"
    if (localFile.isDirectory) {
        createSmbFolder(source, cleanParent, localFile.name)
        return localFile.listFiles()?.sumOf { uploadFileToSmb(source, it, targetPath) } ?: 0
    } else {
        return runCatching {
            withSmbShare(source) { share ->
                val f = share.openFile(
                    targetPath,
                    EnumSet.of(AccessMask.GENERIC_WRITE),
                    null,
                    SMB2ShareAccess.ALL,
                    SMB2CreateDisposition.FILE_OVERWRITE_IF,
                    null
                )
                f.use { remote ->
                    localFile.inputStream().use { inp ->
                        remote.outputStream.use { out -> inp.copyTo(out) }
                    }
                }
                1
            }
        }.getOrDefault(0)
    }
}

fun deleteSmbEntry(source: StorageSource, entry: FileEntry): Boolean {
    return runCatching {
        withSmbShare(source) { share ->
            if (entry.isDirectory) share.rmdir(entry.path, true)
            else share.rm(entry.path)
            true
        }
    }.getOrDefault(false)
}

fun renameSmbEntry(source: StorageSource, entry: FileEntry, newName: String): Boolean {
    return runCatching {
        withSmbShare(source) { share ->
            val parent = entry.path.substringBeforeLast('\\', "")
            val newPath = if (parent.isEmpty()) newName else "$parent\\$newName"
            if (entry.isDirectory) {
                val d = share.openDirectory(
                    entry.path,
                    EnumSet.of(AccessMask.DELETE, AccessMask.GENERIC_READ),
                    null,
                    SMB2ShareAccess.ALL,
                    SMB2CreateDisposition.FILE_OPEN,
                    null
                )
                d.use { it.rename(newPath, true) }
            } else {
                val f = share.openFile(
                    entry.path,
                    EnumSet.of(AccessMask.DELETE, AccessMask.GENERIC_READ),
                    null,
                    SMB2ShareAccess.ALL,
                    SMB2CreateDisposition.FILE_OPEN,
                    null
                )
                f.use { it.rename(newPath, true) }
            }
            true
        }
    }.getOrDefault(false)
}
