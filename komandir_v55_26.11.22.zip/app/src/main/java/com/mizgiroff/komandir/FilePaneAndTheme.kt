package com.mizgiroff.komandir
import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.provider.OpenableColumns
import android.content.ClipData
import android.content.ClipboardManager
import android.widget.Toast
import android.widget.VideoView
import androidx.core.view.WindowInsetsControllerCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowCompat
import android.widget.FrameLayout
import android.view.ViewGroup
import android.view.Gravity
import android.app.Activity
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.pdf.PdfRenderer
import android.media.MediaPlayer
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Info
import android.media.ExifInterface
import android.os.ParcelFileDescriptor
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.filled.Audiotrack
import androidx.compose.material.icons.filled.Save
import androidx.compose.ui.text.font.FontFamily
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.Path
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.border
import androidx.compose.foundation.Image
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.Computer
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.CreateNewFolder
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DriveFileMove
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.InsertDriveFile
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ViewColumn
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material.icons.filled.Check
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.layout.offset
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.unit.IntOffset
import kotlin.math.roundToInt
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

internal val BrandBlue = Color(0xFF0057B7)
internal fun Modifier.paperTexture(enabled: Boolean): Modifier = if (!enabled) this else this.drawWithCache {
    val bgBrush = Brush.verticalGradient(
        colors = listOf(
            Color(0xFFF8EED1),
            Color(0xFFF3E7C4),
            Color(0xFFEDE0B8)
        )
    )
    onDrawBehind {
    drawRect(brush = bgBrush)
    val step = 28f
    var seed = 1337
    var y = 0f
    while (y < size.height) {
        var x = 0f
        while (x < size.width) {
            seed = (seed * 1103515245 + 12345) and 0x7fffffff
            val ox = (seed % 23).toFloat()
            seed = (seed * 1103515245 + 12345) and 0x7fffffff
            val oy = (seed % 23).toFloat()
            val dotColor = if ((seed and 1) == 0) Color(0x168A6E36) else Color(0x18FFFFFF)
            drawCircle(color = dotColor, radius = 1.2f, center = Offset(x + ox, y + oy))
            if ((seed % 5) == 0) {
                drawLine(
                    color = Color(0x118A6E36),
                    start = Offset(x + ox, y + oy),
                    end = Offset((x + ox + 14f).coerceAtMost(size.width), y + oy + 1.5f),
                    strokeWidth = 0.8f
                )
            }
            x += step
        }
        y += step
    }
    }
}

internal fun isWGesture(points: List<Offset>): Boolean {
    if (points.size < 8) return false
    val minX = points.minOf { it.x }
    val maxX = points.maxOf { it.x }
    val minY = points.minOf { it.y }
    val maxY = points.maxOf { it.y }
    if (maxX - minX < 70f || maxY - minY < 35f) return false
    if (points.last().x <= points.first().x + 30f) return false

    val dirs = mutableListOf<Int>()
    var anchorY = points.first().y
    val threshold = ((maxY - minY) * 0.22f).coerceAtLeast(12f)
    for (p in points) {
        val dy = p.y - anchorY
        if (dy > threshold) {
            if (dirs.lastOrNull() != 1) dirs.add(1)
            anchorY = p.y
        } else if (dy < -threshold) {
            if (dirs.lastOrNull() != -1) dirs.add(-1)
            anchorY = p.y
        }
    }
    return dirs == listOf(1, -1, 1, -1)
}

internal val BrandYellow = Color(0xFFFFDD00)

@Composable
internal fun KomandirHeader(
    versionCode: Int,
    dualPane: Boolean,
    compact: Boolean = false,
    onVersionClick: () -> Unit,
    onToggleDualPane: () -> Unit,
    onToggleSearch: () -> Unit,
    onOpenSettings: () -> Unit
) {
    // Сине-жёлтая переливающаяся заливка (как в MedAssist)
    val baseTextColor = MaterialTheme.colorScheme.onSurface
    val transition = rememberInfiniteTransition(label = "medAssistShimmer")
    val shift by transition.animateFloat(
        initialValue = -300f,
        targetValue = 900f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 12000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "shift"
    )
    val shimmerBrush = Brush.linearGradient(
        colors = listOf(baseTextColor, baseTextColor, BrandBlue, BrandYellow, BrandBlue, baseTextColor, baseTextColor),
        start = Offset(shift - 220f, 0f),
        end = Offset(shift + 120f, 80f)
    )
    val logoBrush = Brush.linearGradient(
        colors = listOf(BrandBlue, BrandBlue, BrandYellow, BrandBlue),
        start = Offset(shift - 220f, 0f),
        end = Offset(shift + 120f, 80f)
    )

    Surface(
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 2.dp
    ) {
        Column {
            HorizontalDivider(thickness = 0.5.dp)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = if (compact) 2.dp else 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(24.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(logoBrush),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.ViewColumn,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(15.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "Komandir",
                            style = TextStyle(
                                brush = shimmerBrush,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold
                            )
                        )
                        Spacer(modifier = Modifier.width(3.dp))
                        Text(
                            text = "v$versionCode by mizgiroff",
                            style = TextStyle(
                                brush = shimmerBrush,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Medium
                            ),
                            maxLines = 1,
                            modifier = Modifier
                                .offset(y = (-5).dp)
                                .clickable { onVersionClick() }
                        )
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onToggleDualPane, modifier = Modifier.size(if (compact) 28.dp else 34.dp)) {
                        Icon(
                            imageVector = Icons.Default.ViewColumn,
                            contentDescription = "Dual Pane",
                            modifier = Modifier.size(20.dp),
                            tint = if (dualPane) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                        )
                    }
                    IconButton(onClick = onToggleSearch, modifier = Modifier.size(if (compact) 28.dp else 34.dp)) {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = "Search",
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    IconButton(onClick = onOpenSettings, modifier = Modifier.size(if (compact) 28.dp else 34.dp)) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = "Settings",
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
internal fun FilePaneView(
    modifier: Modifier,
    source: StorageSource,
    currentPath: String,
    selectedIds: Set<String>,
    isActive: Boolean,
    isDropTarget: Boolean,
    dualPane: Boolean,
    searchQuery: String,
    hasPermission: Boolean,
    refreshTick: Int,
    strings: UiStrings,
    onActivate: () -> Unit,
    onEntriesLoaded: (List<FileEntry>) -> Unit = {},
    onRequestPermission: () -> Unit,
    onDragStart: (List<FileEntry>, Offset) -> Unit,
    onDragMove: (Offset) -> Unit,
    onDragEnd: () -> Unit,
    onNavigate: (String) -> Unit,
    onToggleSelect: (String) -> Unit,
    onOpenFile: (FileEntry) -> Unit,
    onLongPressFile: (FileEntry) -> Unit = {}
) {
    val context = LocalContext.current
    var entries by remember { mutableStateOf<List<FileEntry>>(emptyList()) }
    var loadError by remember { mutableStateOf<String?>(null) }
    var isLoading by remember { mutableStateOf(false) }
    var pathHistory by remember(source.id) { mutableStateOf<List<String>>(emptyList()) }
    val currentOnDragStart by rememberUpdatedState(onDragStart)
    val currentOnDragMove by rememberUpdatedState(onDragMove)
    val currentOnDragEnd by rememberUpdatedState(onDragEnd)
    val currentOnNavigate by rememberUpdatedState(onNavigate)
    val currentOnLongPressFile by rememberUpdatedState(onLongPressFile)
    val currentSelectedIds by rememberUpdatedState(selectedIds)

    val canNavigateBack = (source.kind == StorageKind.LOCAL && currentPath != source.rootPath && File(currentPath).parentFile != null) || pathHistory.isNotEmpty()
    if (isActive) {
        BackHandler(enabled = canNavigateBack) {
            if (pathHistory.isNotEmpty()) {
                val prev = pathHistory.last()
                pathHistory = pathHistory.dropLast(1)
                currentOnNavigate(prev)
            } else if (source.kind == StorageKind.LOCAL) {
                File(currentPath).parentFile?.absolutePath?.let(currentOnNavigate)
            }
        }
    }

    var fsTick by remember { mutableIntStateOf(0) }
    DisposableEffect(source.id, currentPath, hasPermission) {
        if (source.kind != StorageKind.LOCAL || !hasPermission || currentPath.isBlank()) {
            onDispose {}
        } else {
            val mainHandler = android.os.Handler(android.os.Looper.getMainLooper())
            var pendingPost = false
            val mask = android.os.FileObserver.CLOSE_WRITE or
                android.os.FileObserver.MOVED_TO or
                android.os.FileObserver.MOVED_FROM or
                android.os.FileObserver.CREATE or
                android.os.FileObserver.DELETE
            @Suppress("DEPRECATION")
            val observer = object : android.os.FileObserver(currentPath, mask) {
                override fun onEvent(event: Int, path: String?) {
                    if (!pendingPost) {
                        pendingPost = true
                        mainHandler.postDelayed({
                            pendingPost = false
                            fsTick++
                        }, 250L)
                    }
                }
            }
            runCatching { observer.startWatching() }
            onDispose {
                runCatching { observer.stopWatching() }
                mainHandler.removeCallbacksAndMessages(null)
            }
        }
    }

    LaunchedEffect(source.id, currentPath, refreshTick, fsTick, hasPermission) {
        isLoading = true
        loadError = null
        val res = withContext(Dispatchers.IO) {
            when (source.kind) {
                StorageKind.LOCAL -> {
                    if (!hasPermission) DirResult()
                    else DirResult(entries = listLocalDirectory(File(currentPath)))
                }
                StorageKind.GDRIVE_API -> listGoogleDriveDirectory(context, currentPath)
                StorageKind.SAF_CLOUD -> listSafDirectory(context, currentPath)
                StorageKind.WEBDAV -> listWebDavDirectory(source, currentPath)
                StorageKind.SMB -> listSmbDirectory(source, currentPath)
                StorageKind.FTP -> listFtpDirectory(source, currentPath)
                StorageKind.FAVORITES -> {
                    val favs = KomandirPrefs.getFavorites(context)
                    DirResult(
                        entries = favs.map { fav ->
                            val localF = if (fav.sourceKindName == StorageKind.LOCAL.name) File(fav.path) else null
                            FileEntry(
                                id = fav.id,
                                name = fav.name,
                                path = fav.path,
                                isDirectory = fav.isDirectory,
                                sizeBytes = if (localF != null && localF.exists() && !localF.isDirectory) localF.length() else 0L,
                                lastModified = if (localF != null && localF.exists()) localF.lastModified() else 0L,
                                subtitle = if (fav.isDirectory) (localF?.list()?.size?.toString() ?: "★") else (localF?.takeIf { it.exists() }?.let { formatFileSize(it.length()) } ?: "★")
                            )
                        }
                    )
                }
            }
        }
        entries = res.entries
        onEntriesLoaded(res.entries)
        loadError = res.error
        isLoading = false
    }

    val filtered = remember(entries, searchQuery) {
        if (searchQuery.isBlank()) entries
        else entries.filter { it.name.contains(searchQuery, ignoreCase = true) }
    }
    val currentFiltered by rememberUpdatedState(filtered)

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .clickable { onActivate() },
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(
            width = if (isDropTarget) 2.5.dp else if (isActive) 1.5.dp else 1.dp,
            color = when {
                isDropTarget -> BrandYellow
                isActive -> MaterialTheme.colorScheme.primary
                else -> MaterialTheme.colorScheme.outlineVariant
            }
        )
    ) {
        val isPaperLight = MaterialTheme.colorScheme.background.luminance() > 0.5f
        Column(modifier = Modifier.fillMaxSize().paperTexture(isPaperLight)) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "${source.title}: $currentPath",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = source.kind.badge,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
            }

            if (source.kind == StorageKind.LOCAL && !hasPermission) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(strings.permissionTitle, fontSize = 13.sp)
                        Spacer(modifier = Modifier.height(10.dp))
                        Button(onClick = onRequestPermission) {
                            Text(strings.permissionBtn)
                        }
                    }
                }
            } else if (isLoading) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        CircularProgressIndicator(modifier = Modifier.size(28.dp))
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(strings.loadingMsg, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            } else if (loadError != null) {
                Box(modifier = Modifier.fillMaxSize().padding(16.dp), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(loadError ?: "Error", fontSize = 12.sp, color = MaterialTheme.colorScheme.error)
                        if (pathHistory.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(8.dp))
                            OutlinedButton(onClick = {
                                val prev = pathHistory.last()
                                pathHistory = pathHistory.dropLast(1)
                                onNavigate(prev)
                            }) { Text(strings.upDir) }
                        }
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .pointerInput(dualPane, source.id, currentPath, pathHistory) {
                            if (dualPane) return@pointerInput
                            var totalX = 0f
                            detectHorizontalDragGestures(
                                onDragStart = { totalX = 0f },
                                onHorizontalDrag = { _, dragAmount -> totalX += dragAmount },
                                onDragEnd = {
                                    if (totalX < -100f && canNavigateBack) {
                                        if (pathHistory.isNotEmpty()) {
                                            val prev = pathHistory.last()
                                            pathHistory = pathHistory.dropLast(1)
                                            currentOnNavigate(prev)
                                        } else if (source.kind == StorageKind.LOCAL) {
                                            File(currentPath).parentFile?.absolutePath?.let(currentOnNavigate)
                                        }
                                    }
                                }
                            )
                        }
                ) {
                    val canGoUp = (source.kind == StorageKind.LOCAL && currentPath != source.rootPath && File(currentPath).parentFile != null) || pathHistory.isNotEmpty()
                    if (canGoUp) {
                        item(key = "up_dir") {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        if (pathHistory.isNotEmpty()) {
                                            val prev = pathHistory.last()
                                            pathHistory = pathHistory.dropLast(1)
                                            onNavigate(prev)
                                        } else {
                                            File(currentPath).parentFile?.absolutePath?.let(onNavigate)
                                        }
                                    }
                                    .padding(horizontal = 10.dp, vertical = 5.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.Folder, contentDescription = null, tint = BrandYellow)
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(strings.upDir, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                            }
                            HorizontalDivider(thickness = 0.5.dp)
                        }
                    }

                    if (filtered.isEmpty()) {
                        item(key = "empty") {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(24.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(strings.emptyDir, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    } else {
                        items(filtered, key = { it.id }) { item ->
                            val isSel = item.id in selectedIds
                            var rowBounds by remember(item.id) { mutableStateOf<Rect?>(null) }
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .onGloballyPositioned { rowBounds = it.boundsInRoot() }
                                    .pointerInput(dualPane, item.id) {
                                        if (!dualPane) return@pointerInput
                                        var dragDist = 0f
                                        detectDragGesturesAfterLongPress(
                                            onDragStart = { localOffset ->
                                                dragDist = 0f
                                                val rootTopLeft = rowBounds?.topLeft ?: Offset.Zero
                                                val selNow = currentSelectedIds
                                                val listNow = currentFiltered
                                                val itemsToDrag = if (item.id in selNow) {
                                                    listNow.filter { it.id in selNow }
                                                } else {
                                                    listOf(item)
                                                }
                                                currentOnDragStart(itemsToDrag, rootTopLeft + localOffset)
                                            },
                                            onDrag = { change, dragAmount ->
                                                change.consume()
                                                dragDist += kotlin.math.hypot(dragAmount.x, dragAmount.y)
                                                currentOnDragMove(dragAmount)
                                            },
                                            onDragEnd = {
                                                currentOnDragEnd()
                                                if (dragDist < 28f) currentOnLongPressFile(item)
                                            },
                                            onDragCancel = { currentOnDragEnd() }
                                        )
                                    }
                                    .background(if (isSel) MaterialTheme.colorScheme.primary.copy(alpha = 0.12f) else Color.Transparent)
                                    .combinedClickable(
                                        onClick = {
                                            if (item.isDirectory) {
                                                pathHistory = pathHistory + currentPath
                                                onNavigate(item.path)
                                            } else {
                                                onOpenFile(item)
                                            }
                                        },
                                        onLongClick = if (dualPane) null else ({ currentOnLongPressFile(item) })
                                    )
                                    .padding(horizontal = 8.dp, vertical = 3.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(18.dp)
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(if (isSel) MaterialTheme.colorScheme.primary else Color.Transparent)
                                        .clickable { onToggleSelect(item.id) },
                                    contentAlignment = Alignment.Center
                                ) {
                                    if (isSel) {
                                        Icon(
                                            imageVector = Icons.Default.Check,
                                            contentDescription = null,
                                            tint = Color.White,
                                            modifier = Modifier.size(13.dp)
                                        )
                                    } else {
                                        Surface(
                                            modifier = Modifier.fillMaxSize(),
                                            shape = RoundedCornerShape(4.dp),
                                            color = Color.Transparent,
                                            border = BorderStroke(1.2.dp, MaterialTheme.colorScheme.outline)
                                        ) {}
                                    }
                                }
                                Spacer(modifier = Modifier.width(7.dp))
                                Icon(
                                    imageVector = if (item.isDirectory) Icons.Default.Folder else Icons.Default.InsertDriveFile,
                                    contentDescription = null,
                                    tint = if (item.isDirectory) Color(0xFFEAB308) else MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(7.dp))
                                Row(
                                    modifier = Modifier.weight(1f),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = item.name,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Medium,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        modifier = Modifier.weight(1f)
                                    )
                                    if (item.subtitle.isNotBlank()) {
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = item.subtitle,
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            maxLines = 1
                                        )
                                    }
                                }
                            }
                            HorizontalDivider(thickness = 0.5.dp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
internal fun KomandirBottomBar(
    strings: UiStrings,
    lang: AppLang,
    selectedCount: Int,
    compact: Boolean = false,
    onSelectAll: () -> Unit,
    onClearSelection: () -> Unit,
    onShare: () -> Unit,
    onCopy: () -> Unit,
    onMove: () -> Unit,
    onNewFolder: () -> Unit,
    onZip: () -> Unit,
    onRename: () -> Unit,
    onDelete: () -> Unit
) {
    Surface(
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 3.dp
    ) {
        Column(modifier = Modifier.padding(horizontal = 8.dp, vertical = if (compact) 3.dp else 6.dp)) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 4.dp, vertical = 2.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = if (selectedCount > 0) strings.selectedCount(selectedCount) else strings.nothingSelected,
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                if (selectedCount > 0) {
                    val selectAllLabel = strings.selectAllActionLabel
                    val clearLabel = strings.clearActionLabel
                    val shareLabel = strings.shareActionLabel
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = shareLabel,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = BrandYellow,
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .clickable(onClick = onShare)
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                        Text(
                            text = selectAllLabel,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .clickable(onClick = onSelectAll)
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                        Text(
                            text = clearLabel,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .clickable(onClick = onClearSelection)
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
            }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                ActionChip(Modifier.weight(1f), Icons.Default.ContentCopy, strings.actCopy, onCopy, compact = compact)
                ActionChip(Modifier.weight(1f), Icons.Default.DriveFileMove, strings.actMove, onMove, compact = compact)
                ActionChip(Modifier.weight(1f), Icons.Default.CreateNewFolder, strings.actNewFolder, onNewFolder, compact = compact)
                ActionChip(Modifier.weight(1f), Icons.Default.Archive, strings.actZip, onZip, compact = compact)
                ActionChip(Modifier.weight(1f), Icons.Default.Edit, strings.actRename, onRename, compact = compact)
                ActionChip(Modifier.weight(1f), Icons.Default.Delete, strings.actDelete, onDelete, isDanger = true, compact = compact)
            }
        }
    }
}

@Composable
internal fun ActionChip(
    modifier: Modifier,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    onClick: () -> Unit,
    isDanger: Boolean = false,
    compact: Boolean = false
) {
    Surface(
        modifier = modifier
            .heightIn(min = if (compact) 30.dp else 44.dp)
            .clip(RoundedCornerShape(if (compact) 8.dp else 10.dp))
            .clickable { onClick() },
        shape = RoundedCornerShape(if (compact) 8.dp else 10.dp),
        color = MaterialTheme.colorScheme.surfaceVariant
    ) {
        if (compact) {
            Row(
                modifier = Modifier.padding(vertical = 4.dp, horizontal = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = label,
                    tint = if (isDanger) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(3.dp))
                Text(
                    text = label,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Medium,
                    color = if (isDanger) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface,
                    maxLines = 1
                )
            }
        } else {
            Column(
                modifier = Modifier.padding(vertical = 6.dp, horizontal = 2.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = label,
                    tint = if (isDanger) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = label,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Medium,
                    color = if (isDanger) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface,
                    maxLines = 1
                )
            }
        }
    }
}
