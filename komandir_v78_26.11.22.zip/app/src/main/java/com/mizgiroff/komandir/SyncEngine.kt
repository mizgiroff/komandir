package com.mizgiroff.komandir

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Environment
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

private const val SYNC_WORK_NAME = "komandir_auto_sync"

fun isWifiConnected(context: Context): Boolean {
    val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return false
    val net = cm.activeNetwork ?: return false
    val caps = cm.getNetworkCapabilities(net) ?: return false
    return caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) ||
        caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_METERED)
}

private fun resolveSourceById(context: Context, id: String): StorageSource? {
    if (id == "phone") {
        return StorageSource("phone", "Phone", StorageKind.LOCAL, Environment.getExternalStorageDirectory().absolutePath)
    }
    return KomandirPrefs.getCustomStorages(context).firstOrNull { it.id == id }
}

private fun listDirForSync(context: Context, src: StorageSource, path: String): DirResult {
    return when (src.kind) {
        StorageKind.LOCAL -> DirResult(entries = listLocalDirectory(File(path)))
        StorageKind.GDRIVE_API -> listGoogleDriveDirectory(context, path)
        StorageKind.SAF_CLOUD -> listSafDirectory(context, path)
        StorageKind.WEBDAV -> listWebDavDirectory(src, path)
        StorageKind.SMB -> listSmbDirectory(src, path)
        StorageKind.FTP -> listFtpDirectory(src, path)
        else -> DirResult(error = "Unsupported")
    }
}

private fun copyEntryForSync(context: Context, srcS: StorageSource, dstS: StorageSource, dstP: String, entry: FileEntry): Int {
    val sk = srcS.kind
    val dk = dstS.kind
    return when {
        sk == StorageKind.LOCAL && dk == StorageKind.LOCAL -> {
            val sf = File(entry.path)
            val df = File(dstP, entry.name)
            if (sf.absolutePath == df.absolutePath) 0
            else if (sf.isDirectory) { sf.copyRecursively(df, overwrite = true); 1 }
            else { sf.copyTo(df, overwrite = true); 1 }
        }
        sk == StorageKind.GDRIVE_API && dk == StorageKind.LOCAL -> downloadGoogleDriveEntry(context, entry, File(dstP))
        sk == StorageKind.LOCAL && dk == StorageKind.GDRIVE_API -> uploadFileToGoogleDrive(context, File(entry.path), dstP)
        sk == StorageKind.GDRIVE_API && dk == StorageKind.GDRIVE_API -> copyGoogleDriveEntry(context, entry, dstP)
        sk == StorageKind.WEBDAV && dk == StorageKind.LOCAL -> downloadWebDavEntry(srcS, entry, File(dstP))
        sk == StorageKind.LOCAL && dk == StorageKind.WEBDAV -> uploadFileToWebDav(dstS, File(entry.path), dstP)
        sk == StorageKind.FTP && dk == StorageKind.LOCAL -> downloadFtpEntry(srcS, entry, File(dstP))
        sk == StorageKind.LOCAL && dk == StorageKind.FTP -> uploadFileToFtp(dstS, File(entry.path), dstP)
        sk == StorageKind.SMB && dk == StorageKind.LOCAL -> downloadSmbEntry(srcS, entry, File(dstP))
        sk == StorageKind.LOCAL && dk == StorageKind.SMB -> uploadFileToSmb(dstS, File(entry.path), dstP)
        else -> 0
    }
}

private fun deleteEntryForSync(context: Context, src: StorageSource, entry: FileEntry): Boolean {
    return when (src.kind) {
        StorageKind.LOCAL -> File(entry.path).deleteRecursively()
        StorageKind.GDRIVE_API -> deleteGoogleDriveEntry(context, entry.id)
        StorageKind.WEBDAV -> deleteWebDavEntry(src, entry.path)
        StorageKind.FTP -> deleteFtpEntry(src, entry)
        StorageKind.SMB -> deleteSmbEntry(src, entry)
        else -> false
    }
}

fun runSyncProfile(context: Context, profile: SyncProfile, forceNow: Boolean = false): Int {
    if (!profile.enabled && !forceNow) return 0
    if (profile.wifiOnly && !isWifiConnected(context)) return 0
    if (!forceNow && profile.intervalMinutes > 0) {
        val elapsedMs = System.currentTimeMillis() - profile.lastRunAt
        if (elapsedMs < profile.intervalMinutes * 60_000L - 30_000L) return 0
    }

    val lSrc = resolveSourceById(context, profile.leftSourceId) ?: return 0
    val rSrc = resolveSourceById(context, profile.rightSourceId) ?: return 0
    val lRes = listDirForSync(context, lSrc, profile.leftPath)
    val rRes = listDirForSync(context, rSrc, profile.rightPath)
    if (lRes.error != null || rRes.error != null) return 0

    val mode = runCatching { SyncMode.valueOf(profile.modeName) }.getOrDefault(SyncMode.ONE_WAY_LR)
    val diff = computeSyncDiff(lRes.entries, rRes.entries)
    val snapshot = if (mode == SyncMode.TWO_WAY) KomandirPrefs.getSyncSnapshot(context, profile.id) else emptyMap()

    var count = 0
    val deletedNames = mutableSetOf<String>()
    for (d in diff) {
        when (mode) {
            SyncMode.ONE_WAY_LR -> {
                if (d.status == SyncItemStatus.ONLY_LEFT || d.status == SyncItemStatus.LEFT_NEWER || d.status == SyncItemStatus.DIFF_SIZE) {
                    d.left?.let { count += copyEntryForSync(context, lSrc, rSrc, profile.rightPath, it) }
                }
            }
            SyncMode.ONE_WAY_RL -> {
                if (d.status == SyncItemStatus.ONLY_RIGHT || d.status == SyncItemStatus.RIGHT_NEWER || d.status == SyncItemStatus.DIFF_SIZE) {
                    d.right?.let { count += copyEntryForSync(context, rSrc, lSrc, profile.leftPath, it) }
                }
            }
            SyncMode.MIRROR_LR -> {
                when (d.status) {
                    SyncItemStatus.ONLY_LEFT, SyncItemStatus.LEFT_NEWER, SyncItemStatus.DIFF_SIZE ->
                        d.left?.let { count += copyEntryForSync(context, lSrc, rSrc, profile.rightPath, it) }
                    SyncItemStatus.ONLY_RIGHT ->
                        d.right?.let { if (deleteEntryForSync(context, rSrc, it)) count++ }
                    else -> {}
                }
            }
            SyncMode.TWO_WAY -> {
                when (d.status) {
                    SyncItemStatus.ONLY_LEFT -> {
                        if (d.name in snapshot) {
                            // Existed before and was deleted on right -> delete on left
                            d.left?.let { if (deleteEntryForSync(context, lSrc, it)) { count++; deletedNames.add(d.name) } }
                        } else {
                            d.left?.let { count += copyEntryForSync(context, lSrc, rSrc, profile.rightPath, it) }
                        }
                    }
                    SyncItemStatus.ONLY_RIGHT -> {
                        if (d.name in snapshot) {
                            // Existed before and was deleted on left -> delete on right
                            d.right?.let { if (deleteEntryForSync(context, rSrc, it)) { count++; deletedNames.add(d.name) } }
                        } else {
                            d.right?.let { count += copyEntryForSync(context, rSrc, lSrc, profile.leftPath, it) }
                        }
                    }
                    SyncItemStatus.LEFT_NEWER, SyncItemStatus.DIFF_SIZE ->
                        d.left?.let { count += copyEntryForSync(context, lSrc, rSrc, profile.rightPath, it) }
                    SyncItemStatus.RIGHT_NEWER ->
                        d.right?.let { count += copyEntryForSync(context, rSrc, lSrc, profile.leftPath, it) }
                    SyncItemStatus.SAME -> {}
                }
            }
        }
    }

    if (mode == SyncMode.TWO_WAY) {
        val afterL = listDirForSync(context, lSrc, profile.leftPath).entries
        val newSnap = mutableMapOf<String, Pair<Long, Long>>()
        afterL.forEach { e ->
            if (e.name !in deletedNames) newSnap[e.name] = e.sizeBytes to e.lastModified
        }
        KomandirPrefs.saveSyncSnapshot(context, profile.id, newSnap)
    }

    val timeStr = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
    val updatedList = KomandirPrefs.getSyncProfiles(context).map { p ->
        if (p.id == profile.id) p.copy(lastRunAt = System.currentTimeMillis(), lastResult = "$timeStr · $count")
        else p
    }
    KomandirPrefs.saveSyncProfiles(context, updatedList)
    return count
}

class SyncWorker(appContext: Context, params: WorkerParameters) : CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result {
        BridgeEndpointResolver.init(applicationContext)
        val profiles = KomandirPrefs.getSyncProfiles(applicationContext)
        profiles.filter { it.enabled && it.intervalMinutes > 0 }.forEach { p ->
            runCatching { runSyncProfile(applicationContext, p, forceNow = false) }
        }
        return Result.success()
    }
}

fun scheduleSyncWork(context: Context) {
    val profiles = KomandirPrefs.getSyncProfiles(context)
    val hasPeriodic = profiles.any { it.enabled && it.intervalMinutes > 0 }
    val wm = WorkManager.getInstance(context)
    if (!hasPeriodic) {
        wm.cancelUniqueWork(SYNC_WORK_NAME)
        return
    }
    val req = PeriodicWorkRequestBuilder<SyncWorker>(15, TimeUnit.MINUTES).build()
    wm.enqueueUniquePeriodicWork(SYNC_WORK_NAME, ExistingPeriodicWorkPolicy.UPDATE, req)
}
