package main

import (
	"bytes"
	"encoding/xml"
	"fmt"
	"io"
	"net"
	"net/http"
	"net/url"
	"regexp"
	"strings"
	"time"
)

func getPublicIP() string {
	client := &http.Client{Timeout: 4 * time.Second}
	resp, err := client.Get("https://api.ipify.org")
	if err != nil {
		return ""
	}
	defer resp.Body.Close()
	b, _ := io.ReadAll(io.LimitReader(resp.Body, 64))
	return strings.TrimSpace(string(b))
}

func discoverUPnPLocation() string {
	conn, err := net.ListenUDP("udp4", &net.UDPAddr{IP: net.IPv4zero, Port: 0})
	if err != nil {
		return ""
	}
	defer conn.Close()
	_ = conn.SetDeadline(time.Now().Add(2500 * time.Millisecond))

	msg := "M-SEARCH * HTTP/1.1\r\n" +
		"HOST: 239.255.255.250:1900\r\n" +
		"MAN: \"ssdp:discover\"\r\n" +
		"MX: 2\r\n" +
		"ST: urn:schemas-upnp-org:device:InternetGatewayDevice:1\r\n\r\n"
	dst, _ := net.ResolveUDPAddr("udp4", "239.255.255.250:1900")
	_, _ = conn.WriteToUDP([]byte(msg), dst)

	buf := make([]byte, 2048)
	locRe := regexp.MustCompile(`(?im)^LOCATION:\s*(\S+)`)
	for i := 0; i < 4; i++ {
		n, _, err := conn.ReadFromUDP(buf)
		if err != nil {
			break
		}
		if m := locRe.FindStringSubmatch(string(buf[:n])); len(m) > 1 {
			return strings.TrimSpace(m[1])
		}
	}
	return ""
}

func findWANControlURL(descURL string) (string, string) {
	client := &http.Client{Timeout: 4 * time.Second}
	resp, err := client.Get(descURL)
	if err != nil {
		return "", ""
	}
	defer resp.Body.Close()
	raw, _ := io.ReadAll(io.LimitReader(resp.Body, 256*1024))
	type svc struct {
		ServiceType string `xml:"serviceType"`
		ControlURL  string `xml:"controlURL"`
	}
	var all []svc
	dec := xml.NewDecoder(bytes.NewReader(raw))
	for {
		tok, err := dec.Token()
		if err != nil {
			break
		}
		if se, ok := tok.(xml.StartElement); ok && se.Name.Local == "service" {
			var s svc
			if dec.DecodeElement(&s, &se) == nil {
				all = append(all, s)
			}
		}
	}
	base, _ := url.Parse(descURL)
	for _, s := range all {
		if strings.Contains(s.ServiceType, "WANIPConnection") || strings.Contains(s.ServiceType, "WANPPPConnection") {
			u, err := url.Parse(s.ControlURL)
			if err == nil && base != nil {
				return base.ResolveReference(u).String(), s.ServiceType
			}
		}
	}
	return "", ""
}

func upnpSoapCall(controlURL, serviceType, action, bodyXML string) (string, error) {
	envelope := fmt.Sprintf(`<?xml version="1.0"?>
<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/" s:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/">
  <s:Body>%s</s:Body>
</s:Envelope>`, bodyXML)
	req, err := http.NewRequest("POST", controlURL, strings.NewReader(envelope))
	if err != nil {
		return "", err
	}
	req.Header.Set("Content-Type", `text/xml; charset="utf-8"`)
	req.Header.Set("SOAPAction", fmt.Sprintf(`"%s#%s"`, serviceType, action))
	client := &http.Client{Timeout: 5 * time.Second}
	resp, err := client.Do(req)
	if err != nil {
		return "", err
	}
	defer resp.Body.Close()
	raw, _ := io.ReadAll(io.LimitReader(resp.Body, 32*1024))
	if resp.StatusCode >= 300 {
		return "", fmt.Errorf("UPnP HTTP %d", resp.StatusCode)
	}
	return string(raw), nil
}

// trySetupUPnP opens TCP port on home router via UPnP and verifies public IP (non-CGNAT).
func trySetupUPnP(localIP string, port int) string {
	loc := discoverUPnPLocation()
	if loc == "" {
		return ""
	}
	ctrlURL, svcType := findWANControlURL(loc)
	if ctrlURL == "" {
		return ""
	}
	extBody := fmt.Sprintf(`<u:GetExternalIPAddress xmlns:u="%s"/>`, svcType)
	extResp, err := upnpSoapCall(ctrlURL, svcType, "GetExternalIPAddress", extBody)
	if err != nil {
		return ""
	}
	ipRe := regexp.MustCompile(`<NewExternalIPAddress>([^<]+)</NewExternalIPAddress>`)
	m := ipRe.FindStringSubmatch(extResp)
	if len(m) < 2 {
		return ""
	}
	routerIP := strings.TrimSpace(m[1])
	publicIP := getPublicIP()
	if routerIP == "" || publicIP == "" || routerIP != publicIP {
		// Home ISP is behind CGNAT -> UPnP cannot be reached from 4G
		return ""
	}
	mapBody := fmt.Sprintf(`<u:AddPortMapping xmlns:u="%s">
  <NewRemoteHost></NewRemoteHost>
  <NewExternalPort>%d</NewExternalPort>
  <NewProtocol>TCP</NewProtocol>
  <NewInternalPort>%d</NewInternalPort>
  <NewInternalClient>%s</NewInternalClient>
  <NewEnabled>1</NewEnabled>
  <NewPortMappingDescription>KomandirBridge</NewPortMappingDescription>
  <NewLeaseDuration>3600</NewLeaseDuration>
</u:AddPortMapping>`, svcType, port, port, localIP)
	if _, err := upnpSoapCall(ctrlURL, svcType, "AddPortMapping", mapBody); err != nil {
		return ""
	}
	return fmt.Sprintf("http://%s:%d/", routerIP, port)
}
