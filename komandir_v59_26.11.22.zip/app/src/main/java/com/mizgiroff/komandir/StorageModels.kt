package com.mizgiroff.komandir

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

enum class AppThemeMode(val key: String) {
    LIGHT("light"),
    DARK("dark"),
    SYSTEM("system");

    companion object {
        fun fromKey(key: String?): AppThemeMode =
            entries.firstOrNull { it.key == key } ?: SYSTEM
    }
}

enum class AppLang(val key: String, val label: String) {
    UK("uk", "Українська"),
    EN("en", "English"),
    DE("de", "Deutsch"),
    FR("fr", "Français"),
    IT("it", "Italiano"),
    RU("ru", "Русский");

    companion object {
        fun fromKey(key: String?): AppLang =
            entries.firstOrNull { it.key == key } ?: UK
    }
}

enum class StorageKind(val badge: String) {
    LOCAL("Local"),
    GDRIVE_API("Drive API"),
    SAF_CLOUD("Cloud / SAF"),
    WEBDAV("WebDAV"),
    SMB("SMB"),
    FTP("FTP"),
    FAVORITES("★")
}

data class StorageSource(
    val id: String,
    val title: String,
    val kind: StorageKind,
    val rootPath: String,
    val host: String = "",
    val shareName: String = "",
    val username: String = "",
    val password: String = "",
    val isCustom: Boolean = false
)



data class SyncProfile(
    val id: String,
    val name: String,
    val leftSourceId: String,
    val leftPath: String,
    val rightSourceId: String,
    val rightPath: String,
    val modeName: String = "ONE_WAY_LR",
    val intervalMinutes: Int = 60,
    val wifiOnly: Boolean = true,
    val onChange: Boolean = false,
    val enabled: Boolean = true,
    val lastRunAt: Long = 0L,
    val lastResult: String = ""
)

data class FavoriteItem(
    val id: String,
    val name: String,
    val path: String,
    val isDirectory: Boolean,
    val sourceId: String,
    val sourceKindName: String
)

data class FileEntry(
    val id: String,
    val name: String,
    val path: String,
    val isDirectory: Boolean,
    val sizeBytes: Long,
    val lastModified: Long,
    val subtitle: String = ""
)

object KomandirPrefs {
    private const val PREFS_NAME = "komandir_prefs"
    private const val KEY_THEME = "theme_mode"
    private const val KEY_LANG = "app_lang"
    private const val KEY_LANG_SET = "app_lang_chosen"
    private const val KEY_DEFAULT_PROMPT_SHOWN = "default_prompt_shown"
    private const val KEY_CUSTOM_STORAGES = "custom_storages"
    private const val KEY_GD_CLIENT_ID = "gd_client_id"
    private const val KEY_GD_CLIENT_SECRET = "gd_client_secret"
    private const val KEY_GD_ACCESS = "gd_access_token"
    private const val KEY_GD_REFRESH = "gd_refresh_token"
    private const val KEY_GD_VERIFIER = "gd_pkce_verifier"
    private const val KEY_GEMINI_BRANCH = "gemini_branch_url"
    private const val KEY_FAVORITES = "favorites_json"

    fun getTheme(context: Context): AppThemeMode {
        val sp = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return AppThemeMode.fromKey(sp.getString(KEY_THEME, AppThemeMode.SYSTEM.key))
    }

    fun setTheme(context: Context, mode: AppThemeMode) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit().putString(KEY_THEME, mode.key).apply()
    }

    fun isDefaultPromptShown(context: Context): Boolean =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getBoolean(KEY_DEFAULT_PROMPT_SHOWN, false)

    fun setDefaultPromptShown(context: Context) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit().putBoolean(KEY_DEFAULT_PROMPT_SHOWN, true).apply()
    }

    fun isLangChosen(context: Context): Boolean =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getBoolean(KEY_LANG_SET, false)

    fun getLang(context: Context): AppLang {
        val sp = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return AppLang.fromKey(sp.getString(KEY_LANG, AppLang.UK.key))
    }

    fun setLang(context: Context, lang: AppLang) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_LANG, lang.key)
            .putBoolean(KEY_LANG_SET, true)
            .apply()
    }

    fun getCustomStorages(context: Context): List<StorageSource> {
        val raw = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getString(KEY_CUSTOM_STORAGES, "[]") ?: "[]"
        val list = mutableListOf<StorageSource>()
        return try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                val kind = runCatching { StorageKind.valueOf(obj.getString("kind")) }
                    .getOrDefault(StorageKind.SMB)
                list.add(
                    StorageSource(
                        id = obj.getString("id"),
                        title = obj.getString("title").let { if (kind == StorageKind.GDRIVE_API && it == "Google Диск") "Google Drive" else it },
                        kind = kind,
                        rootPath = obj.optString("rootPath", "/"),
                        host = obj.optString("host", ""),
                        shareName = obj.optString("shareName", ""),
                        username = obj.optString("username", ""),
                        password = obj.optString("password", ""),
                        isCustom = true
                    )
                )
            }
            list
        } catch (_: Exception) {
            emptyList()
        }
    }

    const val DEFAULT_GD_CLIENT_ID = "864168741040-7r9g0vd266q4nse01qfvaudqi2ldos3k.apps.googleusercontent.com"
    const val DEFAULT_GD_CLIENT_SECRET = "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"


    fun getFavorites(context: Context): List<FavoriteItem> {
        val raw = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).getString(KEY_FAVORITES, "[]") ?: "[]"
        val list = mutableListOf<FavoriteItem>()
        runCatching {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                list.add(
                    FavoriteItem(
                        id = o.getString("id"),
                        name = o.getString("name"),
                        path = o.getString("path"),
                        isDirectory = o.optBoolean("isDirectory", false),
                        sourceId = o.optString("sourceId", "phone"),
                        sourceKindName = o.optString("sourceKindName", StorageKind.LOCAL.name)
                    )
                )
            }
        }
        return list
    }

    fun saveFavorites(context: Context, list: List<FavoriteItem>) {
        val arr = JSONArray()
        list.forEach { f ->
            arr.put(JSONObject().apply {
                put("id", f.id)
                put("name", f.name)
                put("path", f.path)
                put("isDirectory", f.isDirectory)
                put("sourceId", f.sourceId)
                put("sourceKindName", f.sourceKindName)
            })
        }
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit().putString(KEY_FAVORITES, arr.toString()).apply()
    }

    fun toggleFavorite(context: Context, item: FavoriteItem): List<FavoriteItem> {
        val current = getFavorites(context).toMutableList()
        val existingIdx = current.indexOfFirst { it.id == item.id && it.sourceId == item.sourceId }
        if (existingIdx >= 0) current.removeAt(existingIdx) else current.add(item)
        saveFavorites(context, current)
        return current
    }

    fun getGeminiBranchUrl(context: Context): String {
        val sp = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return sp.getString(KEY_GEMINI_BRANCH, "") ?: ""
    }

    fun setGeminiBranchUrl(context: Context, url: String) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit().putString(KEY_GEMINI_BRANCH, url.trim()).apply()
    }

    fun getGdClientId(context: Context): String =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).getString(KEY_GD_CLIENT_ID, "") ?: ""

    fun getGdClientSecret(context: Context): String =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).getString(KEY_GD_CLIENT_SECRET, "") ?: ""

    fun setGdClientSecret(context: Context, secret: String) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit().putString(KEY_GD_CLIENT_SECRET, secret).apply()
    }

    fun setGdClientId(context: Context, id: String) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit().putString(KEY_GD_CLIENT_ID, id).apply()
    }

    fun getGdAccessToken(context: Context): String =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).getString(KEY_GD_ACCESS, "") ?: ""

    fun getGdRefreshToken(context: Context): String =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).getString(KEY_GD_REFRESH, "") ?: ""

    fun saveGdTokens(context: Context, access: String, refresh: String) {
        val ed = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit().putString(KEY_GD_ACCESS, access)
        if (refresh.isNotBlank()) ed.putString(KEY_GD_REFRESH, refresh)
        ed.apply()
    }

    fun getGdVerifier(context: Context): String =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).getString(KEY_GD_VERIFIER, "") ?: ""

    fun setGdVerifier(context: Context, v: String) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit().putString(KEY_GD_VERIFIER, v).apply()
    }

    fun removeCustomStorage(context: Context, id: String) {
        val updated = getCustomStorages(context).filterNot { it.id == id }
        val arr = JSONArray()
        updated.forEach { s ->
            arr.put(JSONObject().apply {
                put("id", s.id)
                put("title", s.title)
                put("kind", s.kind.name)
                put("rootPath", s.rootPath)
                put("host", s.host)
                put("shareName", s.shareName)
                put("username", s.username)
                put("password", s.password)
            })
        }
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit().putString(KEY_CUSTOM_STORAGES, arr.toString()).apply()
    }

    fun addCustomStorage(context: Context, source: StorageSource) {
        val current = getCustomStorages(context) + source
        val arr = JSONArray()
        current.forEach { s ->
            arr.put(JSONObject().apply {
                put("id", s.id)
                put("title", s.title)
                put("kind", s.kind.name)
                put("rootPath", s.rootPath)
                put("host", s.host)
                put("shareName", s.shareName)
                put("username", s.username)
                put("password", s.password)
            })
        }
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit().putString(KEY_CUSTOM_STORAGES, arr.toString()).apply()
    }

    private const val KEY_SYNC_PROFILES = "sync_profiles_json"
    private const val KEY_SYNC_SNAPSHOT_PREFIX = "sync_snap_"

    fun getSyncProfiles(context: Context): List<SyncProfile> {
        val raw = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getString(KEY_SYNC_PROFILES, null) ?: return emptyList()
        return runCatching {
            val arr = JSONArray(raw)
            buildList {
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    add(
                        SyncProfile(
                            id = o.getString("id"),
                            name = o.getString("name"),
                            leftSourceId = o.getString("leftSourceId"),
                            leftPath = o.getString("leftPath"),
                            rightSourceId = o.getString("rightSourceId"),
                            rightPath = o.getString("rightPath"),
                            modeName = o.optString("modeName", "ONE_WAY_LR"),
                            intervalMinutes = o.optInt("intervalMinutes", 60),
                            wifiOnly = o.optBoolean("wifiOnly", true),
                            onChange = o.optBoolean("onChange", false),
                            enabled = o.optBoolean("enabled", true),
                            lastRunAt = o.optLong("lastRunAt", 0L),
                            lastResult = o.optString("lastResult", "")
                        )
                    )
                }
            }
        }.getOrDefault(emptyList())
    }

    fun saveSyncProfiles(context: Context, list: List<SyncProfile>) {
        val arr = JSONArray()
        list.forEach { p ->
            arr.put(JSONObject().apply {
                put("id", p.id)
                put("name", p.name)
                put("leftSourceId", p.leftSourceId)
                put("leftPath", p.leftPath)
                put("rightSourceId", p.rightSourceId)
                put("rightPath", p.rightPath)
                put("modeName", p.modeName)
                put("intervalMinutes", p.intervalMinutes)
                put("wifiOnly", p.wifiOnly)
                put("onChange", p.onChange)
                put("enabled", p.enabled)
                put("lastRunAt", p.lastRunAt)
                put("lastResult", p.lastResult)
            })
        }
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit().putString(KEY_SYNC_PROFILES, arr.toString()).apply()
    }

    fun getSyncSnapshot(context: Context, profileId: String): Map<String, Pair<Long, Long>> {
        val raw = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getString(KEY_SYNC_SNAPSHOT_PREFIX + profileId, null) ?: return emptyMap()
        return runCatching {
            val obj = JSONObject(raw)
            val map = mutableMapOf<String, Pair<Long, Long>>()
            val keys = obj.keys()
            while (keys.hasNext()) {
                val k = keys.next()
                val arr = obj.getJSONArray(k)
                map[k] = arr.getLong(0) to arr.getLong(1)
            }
            map
        }.getOrDefault(emptyMap())
    }

    fun saveSyncSnapshot(context: Context, profileId: String, entries: Map<String, Pair<Long, Long>>) {
        val obj = JSONObject()
        entries.forEach { (name, pair) ->
            obj.put(name, JSONArray().apply { put(pair.first); put(pair.second) })
        }
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit().putString(KEY_SYNC_SNAPSHOT_PREFIX + profileId, obj.toString()).apply()
    }
}

fun formatFileSize(bytes: Long): String {
    if (bytes < 1024) return "$bytes B"
    val kb = bytes / 1024.0
    if (kb < 1024) return String.format("%.1f KB", kb)
    val mb = kb / 1024.0
    if (mb < 1024) return String.format("%.1f MB", mb)
    return String.format("%.2f GB", mb / 1024.0)
}

fun listLocalDirectory(dir: File): List<FileEntry> {
    val files = dir.listFiles() ?: return emptyList()
    return files
        .map { f -> Triple(f, f.isDirectory, f.name) }
        .sortedWith(compareBy<Triple<File, Boolean, String>> { !it.second }.thenBy { it.third.lowercase() })
        .map { (f, isDir, name) ->
            val len = if (isDir) 0L else f.length()
            FileEntry(
                id = f.absolutePath,
                name = name,
                path = f.absolutePath,
                isDirectory = isDir,
                sizeBytes = len,
                lastModified = f.lastModified(),
                subtitle = if (isDir) "${f.list()?.size ?: 0}" else formatFileSize(len)
            )
        }
}
