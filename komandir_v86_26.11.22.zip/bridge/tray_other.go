//go:build !windows

package main

func startTray(uiURL string) {}
func removeTrayIcon()         {}
