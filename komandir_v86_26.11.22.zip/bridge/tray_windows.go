//go:build windows

package main

import (
	"runtime"
	"syscall"
	"unsafe"
)

var (
	user32   = syscall.NewLazyDLL("user32.dll")
	kernel32 = syscall.NewLazyDLL("kernel32.dll")
	shell32  = syscall.NewLazyDLL("shell32.dll")
	gdi32    = syscall.NewLazyDLL("gdi32.dll")

	pGetModuleHandleW   = kernel32.NewProc("GetModuleHandleW")
	pRegisterClassExW   = user32.NewProc("RegisterClassExW")
	pCreateWindowExW    = user32.NewProc("CreateWindowExW")
	pDefWindowProcW     = user32.NewProc("DefWindowProcW")
	pGetMessageW        = user32.NewProc("GetMessageW")
	pTranslateMessage   = user32.NewProc("TranslateMessage")
	pDispatchMessageW   = user32.NewProc("DispatchMessageW")
	pLoadIconW          = user32.NewProc("LoadIconW")
	pCreatePopupMenu    = user32.NewProc("CreatePopupMenu")
	pAppendMenuW        = user32.NewProc("AppendMenuW")
	pTrackPopupMenu     = user32.NewProc("TrackPopupMenu")
	pSetForegroundWin   = user32.NewProc("SetForegroundWindow")
	pGetCursorPos       = user32.NewProc("GetCursorPos")
	pDestroyMenu        = user32.NewProc("DestroyMenu")
	pPostMessageW       = user32.NewProc("PostMessageW")
	pShellNotifyIconW   = shell32.NewProc("Shell_NotifyIconW")
	pCreateIconIndirect = user32.NewProc("CreateIconIndirect")
	pCreateBitmap       = gdi32.NewProc("CreateBitmap")
	pDeleteObject       = gdi32.NewProc("DeleteObject")
)

const (
	wmUser       = 0x0400
	wmTray       = wmUser + 1
	wmCommand    = 0x0111
	wmLButtonUp  = 0x0202
	wmRButtonUp  = 0x0205
	nimAdd       = 0x00000000
	nimDelete    = 0x00000002
	nifMessage   = 0x00000001
	nifIcon      = 0x00000002
	nifTip       = 0x00000004
	mfString     = 0x00000000
	mfSeparator  = 0x00000800
	tpmBottom    = 0x0020
	tpmLeftAlign = 0x0000
	idiApp       = 32512

	cmdOpen    = 1001
	cmdPause   = 1002
	cmdRestart = 1003
	cmdExit    = 1004
)

type wndClassEx struct {
	cbSize        uint32
	style         uint32
	lpfnWndProc   uintptr
	cbClsExtra    int32
	cbWndExtra    int32
	hInstance     uintptr
	hIcon         uintptr
	hCursor       uintptr
	hbrBackground uintptr
	lpszMenuName  *uint16
	lpszClassName *uint16
	hIconSm       uintptr
}

type point struct{ x, y int32 }

type msg struct {
	hwnd    uintptr
	message uint32
	wParam  uintptr
	lParam  uintptr
	time    uint32
	pt      point
}

type notifyIconData struct {
	cbSize           uint32
	hWnd             uintptr
	uID              uint32
	uFlags           uint32
	uCallbackMessage uint32
	hIcon            uintptr
	szTip            [128]uint16
	dwState          uint32
	dwStateMask      uint32
	szInfo           [256]uint16
	uVersion         uint32
	szInfoTitle      [64]uint16
	dwInfoFlags      uint32
}


type iconInfo struct {
	fIcon    int32
	xHotspot uint32
	yHotspot uint32
	hbmMask  uintptr
	hbmColor uintptr
}

func createKomandirTrayIcon() uintptr {
	const sz = 32
	var pixels [sz * sz]uint32
	const blue = 0xFF0057B7
	const yellow = 0xFFFFDD00
	const white = 0xFFFFFFFF
	for y := 0; y < sz; y++ {
		for x := 0; x < sz; x++ {
			c := uint32(blue)
			// Left pane (yellow) & right pane (white) matching ic_komandir_logo.xml
			if y >= 5 && y <= 26 {
				if x >= 4 && x <= 14 {
					c = yellow
					if x >= 6 && x <= 12 && ((y >= 10 && y <= 12) || (y >= 16 && y <= 18)) {
						c = blue
					}
				} else if x >= 17 && x <= 27 {
					c = white
					if x >= 19 && x <= 25 && ((y >= 10 && y <= 12) || (y >= 16 && y <= 18)) {
						c = blue
					}
				}
			}
			pixels[y*sz+x] = c
		}
	}
	hColor, _, _ := pCreateBitmap.Call(sz, sz, 1, 32, uintptr(unsafe.Pointer(&pixels[0])))
	var mask [sz]uint32
	hMask, _, _ := pCreateBitmap.Call(sz, sz, 1, 1, uintptr(unsafe.Pointer(&mask[0])))
	if hColor == 0 || hMask == 0 {
		return 0
	}
	ii := iconInfo{fIcon: 1, hbmMask: hMask, hbmColor: hColor}
	hIcon, _, _ := pCreateIconIndirect.Call(uintptr(unsafe.Pointer(&ii)))
	pDeleteObject.Call(hColor)
	pDeleteObject.Call(hMask)
	return hIcon
}

var trayHwnd uintptr

func removeTrayIcon() {
	if trayHwnd != 0 {
		var nid notifyIconData
		nid.cbSize = uint32(unsafe.Sizeof(nid))
		nid.hWnd = trayHwnd
		nid.uID = 1
		pShellNotifyIconW.Call(nimDelete, uintptr(unsafe.Pointer(&nid)))
	}
}

func showTrayMenu(hwnd uintptr, uiURL string) {
	hMenu, _, _ := pCreatePopupMenu.Call()
	if hMenu == 0 {
		return
	}
	defer pDestroyMenu.Call(hMenu)

	sOpen, _ := syscall.UTF16PtrFromString("Open Komandir Bridge")
	pauseTxt := "Pause"
	mu.RLock()
	if paused {
		pauseTxt = "Resume"
	}
	mu.RUnlock()
	sPause, _ := syscall.UTF16PtrFromString(pauseTxt)
	sRestart, _ := syscall.UTF16PtrFromString("Restart Tunnel")
	sExit, _ := syscall.UTF16PtrFromString("Exit")

	pAppendMenuW.Call(hMenu, mfString, cmdOpen, uintptr(unsafe.Pointer(sOpen)))
	pAppendMenuW.Call(hMenu, mfString, cmdPause, uintptr(unsafe.Pointer(sPause)))
	pAppendMenuW.Call(hMenu, mfString, cmdRestart, uintptr(unsafe.Pointer(sRestart)))
	pAppendMenuW.Call(hMenu, mfSeparator, 0, 0)
	pAppendMenuW.Call(hMenu, mfString, cmdExit, uintptr(unsafe.Pointer(sExit)))

	var pt point
	pGetCursorPos.Call(uintptr(unsafe.Pointer(&pt)))
	pSetForegroundWin.Call(hwnd)
	pTrackPopupMenu.Call(hMenu, tpmLeftAlign|tpmBottom, uintptr(pt.x), uintptr(pt.y), 0, hwnd, 0)
	pPostMessageW.Call(hwnd, 0, 0, 0)
}

func startTray(uiURL string) {
	go func() {
		runtime.LockOSThread()
		defer runtime.UnlockOSThread()

		hInst, _, _ := pGetModuleHandleW.Call(0)
		hIcon := createKomandirTrayIcon()
		if hIcon == 0 {
			hIcon, _, _ = pLoadIconW.Call(0, idiApp)
		}
		clsName, _ := syscall.UTF16PtrFromString("KomandirBridgeTrayClass")

		wndProc := syscall.NewCallback(func(hwnd uintptr, uMsg uint32, wParam, lParam uintptr) uintptr {
			switch uMsg {
			case wmTray:
				switch uint32(lParam) {
				case wmLButtonUp:
					go openBrowser(uiURL)
				case wmRButtonUp:
					showTrayMenu(hwnd, uiURL)
				}
				return 0
			case wmCommand:
				switch int(wParam & 0xFFFF) {
				case cmdOpen:
					go openBrowser(uiURL)
				case cmdPause:
					togglePause()
				case cmdRestart:
					restartTunnel()
				case cmdExit:
					stopTunnel()
					removeTrayIcon()
					syscall.Exit(0)
				}
				return 0
			}
			ret, _, _ := pDefWindowProcW.Call(hwnd, uintptr(uMsg), wParam, lParam)
			return ret
		})

		wc := wndClassEx{
			cbSize:        uint32(unsafe.Sizeof(wndClassEx{})),
			lpfnWndProc:   wndProc,
			hInstance:     hInst,
			hIcon:         hIcon,
			lpszClassName: clsName,
		}
		pRegisterClassExW.Call(uintptr(unsafe.Pointer(&wc)))

		hwnd, _, _ := pCreateWindowExW.Call(0, uintptr(unsafe.Pointer(clsName)), uintptr(unsafe.Pointer(clsName)), 0, 0, 0, 0, 0, 0, 0, hInst, 0)
		if hwnd == 0 {
			return
		}
		trayHwnd = hwnd

		var nid notifyIconData
		nid.cbSize = uint32(unsafe.Sizeof(nid))
		nid.hWnd = hwnd
		nid.uID = 1
		nid.uFlags = nifMessage | nifIcon | nifTip
		nid.uCallbackMessage = wmTray
		nid.hIcon = hIcon
		tip, _ := syscall.UTF16FromString("Komandir Bridge v" + bridgeVersion)
		copy(nid.szTip[:], tip)
		pShellNotifyIconW.Call(nimAdd, uintptr(unsafe.Pointer(&nid)))

		var m msg
		for {
			r, _, _ := pGetMessageW.Call(uintptr(unsafe.Pointer(&m)), 0, 0, 0)
			if int32(r) <= 0 {
				break
			}
			pTranslateMessage.Call(uintptr(unsafe.Pointer(&m)))
			pDispatchMessageW.Call(uintptr(unsafe.Pointer(&m)))
		}
	}()
}
