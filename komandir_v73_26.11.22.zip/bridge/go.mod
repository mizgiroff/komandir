module komandir-bridge

go 1.22

require (
	github.com/skip2/go-qrcode v0.0.0-20200617195104-da1b6568686e
	golang.org/x/net v0.29.0
)
