# ProGuard rules for Komandir
