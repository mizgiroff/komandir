package com.mizgiroff.komandir

import org.junit.Assert.assertEquals
import org.junit.Test

class KomandirTest {
    @Test
    fun formatSizeWorks() {
        assertEquals("512 B", formatFileSize(512))
        assertEquals("1.0 KB", formatFileSize(1024))
    }
}
