package com.mizgiroff.komandir

import android.database.Cursor
import android.database.MatrixCursor
import android.os.CancellationSignal
import android.os.Environment
import android.os.ParcelFileDescriptor
import android.provider.DocumentsContract.Document
import android.provider.DocumentsContract.Root
import android.provider.DocumentsProvider
import android.webkit.MimeTypeMap
import java.io.File
import java.io.FileNotFoundException

class KomandirDocumentsProvider : DocumentsProvider() {

    private val defaultRootProjection = arrayOf(
        Root.COLUMN_ROOT_ID,
        Root.COLUMN_MIME_TYPES,
        Root.COLUMN_FLAGS,
        Root.COLUMN_ICON,
        Root.COLUMN_TITLE,
        Root.COLUMN_SUMMARY,
        Root.COLUMN_DOCUMENT_ID
    )

    private val defaultDocumentProjection = arrayOf(
        Document.COLUMN_DOCUMENT_ID,
        Document.COLUMN_MIME_TYPE,
        Document.COLUMN_DISPLAY_NAME,
        Document.COLUMN_LAST_MODIFIED,
        Document.COLUMN_FLAGS,
        Document.COLUMN_SIZE
    )

    override fun onCreate(): Boolean = true

    override fun queryRoots(projection: Array<out String>?): Cursor {
        val result = MatrixCursor(projection ?: defaultRootProjection)
        val ctx = context ?: return result
        val phoneRoot = Environment.getExternalStorageDirectory().absolutePath

        result.newRow().apply {
            add(Root.COLUMN_ROOT_ID, "local")
            add(Root.COLUMN_DOCUMENT_ID, "local:$phoneRoot")
            add(Root.COLUMN_TITLE, "Komandir")
            add(Root.COLUMN_SUMMARY, "Телефон")
            add(Root.COLUMN_FLAGS, Root.FLAG_LOCAL_ONLY or Root.FLAG_SUPPORTS_IS_CHILD)
            add(Root.COLUMN_MIME_TYPES, "*/*")
            add(Root.COLUMN_ICON, R.drawable.ic_komandir_logo)
        }

        if (KomandirPrefs.getGdRefreshToken(ctx).isNotBlank()) {
            result.newRow().apply {
                add(Root.COLUMN_ROOT_ID, "gdrive")
                add(Root.COLUMN_DOCUMENT_ID, "gdrive:root")
                add(Root.COLUMN_TITLE, "Komandir (Google Диск)")
                add(Root.COLUMN_SUMMARY, "Google Drive")
                add(Root.COLUMN_FLAGS, Root.FLAG_SUPPORTS_IS_CHILD)
                add(Root.COLUMN_MIME_TYPES, "*/*")
                add(Root.COLUMN_ICON, R.drawable.ic_komandir_logo)
            }
        }
        return result
    }

    override fun queryDocument(documentId: String?, projection: Array<out String>?): Cursor {
        val result = MatrixCursor(projection ?: defaultDocumentProjection)
        val docId = documentId ?: return result
        if (docId.startsWith("local:")) {
            val file = File(docId.removePrefix("local:"))
            if (file.exists()) addLocalRow(result, file)
        } else if (docId.startsWith("gdrive:")) {
            val id = docId.removePrefix("gdrive:")
            val name = if (id == "root") "Google Диск" else id.substringAfter("|", id)
            result.newRow().apply {
                add(Document.COLUMN_DOCUMENT_ID, docId)
                add(Document.COLUMN_DISPLAY_NAME, name)
                add(Document.COLUMN_MIME_TYPE, Document.MIME_TYPE_DIR)
                add(Document.COLUMN_LAST_MODIFIED, System.currentTimeMillis())
                add(Document.COLUMN_FLAGS, 0)
                add(Document.COLUMN_SIZE, 0L)
            }
        }
        return result
    }

    override fun queryChildDocuments(
        parentDocumentId: String?,
        projection: Array<out String>?,
        sortOrder: String?
    ): Cursor {
        val result = MatrixCursor(projection ?: defaultDocumentProjection)
        val docId = parentDocumentId ?: return result
        val ctx = context ?: return result

        if (docId.startsWith("local:")) {
            val dir = File(docId.removePrefix("local:"))
            val files = dir.listFiles()?.sortedWith(
                compareBy<File> { !it.isDirectory }.thenBy { it.name.lowercase() }
            ) ?: emptyList()
            files.forEach { addLocalRow(result, it) }
        } else if (docId.startsWith("gdrive:")) {
            val folderId = docId.removePrefix("gdrive:").substringBefore("|")
            val dirResult = listGoogleDriveDirectory(ctx, folderId.ifBlank { "root" })
            dirResult.entries.forEach { entry ->
                val mime = if (entry.isDirectory) Document.MIME_TYPE_DIR else guessMime(entry.name)
                result.newRow().apply {
                    add(Document.COLUMN_DOCUMENT_ID, "gdrive:${entry.id}|${entry.name}")
                    add(Document.COLUMN_DISPLAY_NAME, entry.name)
                    add(Document.COLUMN_MIME_TYPE, mime)
                    add(Document.COLUMN_LAST_MODIFIED, entry.lastModified)
                    add(Document.COLUMN_FLAGS, 0)
                    add(Document.COLUMN_SIZE, entry.sizeBytes)
                }
            }
        }
        return result
    }

    override fun openDocument(
        documentId: String?,
        mode: String?,
        signal: CancellationSignal?
    ): ParcelFileDescriptor {
        val docId = documentId ?: throw FileNotFoundException("Empty documentId")
        val ctx = context ?: throw FileNotFoundException("No context")
        if (docId.startsWith("local:")) {
            val file = File(docId.removePrefix("local:"))
            if (!file.exists()) throw FileNotFoundException(file.absolutePath)
            val accessMode = ParcelFileDescriptor.parseMode(mode ?: "r")
            return ParcelFileDescriptor.open(file, accessMode)
        } else if (docId.startsWith("gdrive:")) {
            val payload = docId.removePrefix("gdrive:")
            val fileId = payload.substringBefore("|")
            val fileName = payload.substringAfter("|", "drive_file")
            val cacheDir = File(ctx.cacheDir, "doc_provider_cache").apply { mkdirs() }
            val entry = FileEntry(
                id = fileId,
                name = fileName,
                path = fileId,
                isDirectory = false,
                sizeBytes = 0L,
                lastModified = System.currentTimeMillis()
            )
            downloadGoogleDriveEntry(ctx, entry, cacheDir)
            val cached = File(cacheDir, fileName)
            if (!cached.exists()) throw FileNotFoundException("Drive download failed: $fileName")
            return ParcelFileDescriptor.open(cached, ParcelFileDescriptor.MODE_READ_ONLY)
        }
        throw FileNotFoundException("Unknown documentId: $docId")
    }

    override fun isChildDocument(parentDocumentId: String?, documentId: String?): Boolean {
        if (parentDocumentId == null || documentId == null) return false
        if (parentDocumentId.startsWith("local:") && documentId.startsWith("local:")) {
            val p = parentDocumentId.removePrefix("local:")
            val c = documentId.removePrefix("local:")
            return c.startsWith(p)
        }
        return parentDocumentId.startsWith("gdrive:") && documentId.startsWith("gdrive:")
    }

    private fun addLocalRow(cursor: MatrixCursor, file: File) {
        val mime = if (file.isDirectory) Document.MIME_TYPE_DIR else guessMime(file.name)
        cursor.newRow().apply {
            add(Document.COLUMN_DOCUMENT_ID, "local:${file.absolutePath}")
            add(Document.COLUMN_DISPLAY_NAME, file.name)
            add(Document.COLUMN_MIME_TYPE, mime)
            add(Document.COLUMN_LAST_MODIFIED, file.lastModified())
            add(Document.COLUMN_FLAGS, 0)
            add(Document.COLUMN_SIZE, if (file.isDirectory) 0L else file.length())
        }
    }

    private fun guessMime(name: String): String {
        val ext = name.substringAfterLast(".", "").lowercase()
        if (ext.isEmpty()) return "application/octet-stream"
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "application/octet-stream"
    }
}
