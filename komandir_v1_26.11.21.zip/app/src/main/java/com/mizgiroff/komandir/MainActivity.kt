package com.mizgiroff.komandir

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.Computer
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.CreateNewFolder
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DriveFileMove
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.InsertDriveFile
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ViewColumn
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            KomandirApp()
        }
    }
}

private val BrandBlue = Color(0xFF0057B7)
private val BrandYellow = Color(0xFFFFDD00)

@Composable
fun KomandirApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var themeMode by remember { mutableStateOf(KomandirPrefs.getTheme(context)) }
    var appLang by remember { mutableStateOf(KomandirPrefs.getLang(context)) }
    var showLangPrompt by remember { mutableStateOf(!KomandirPrefs.isLangChosen(context)) }

    val isDark = when (themeMode) {
        AppThemeMode.DARK -> true
        AppThemeMode.LIGHT -> false
        AppThemeMode.SYSTEM -> isSystemInDarkTheme()
    }

    val colorScheme = if (isDark) {
        darkColorScheme(
            primary = Color(0xFF3B82F6),
            background = Color(0xFF0F172A),
            surface = Color(0xFF1E293B),
            surfaceVariant = Color(0xFF162032)
        )
    } else {
        lightColorScheme(
            primary = BrandBlue,
            background = Color(0xFFF8FAFC),
            surface = Color(0xFFFFFFFF),
            surfaceVariant = Color(0xFFF1F5F9)
        )
    }

    MaterialTheme(colorScheme = colorScheme) {
        val t = remember(appLang) { stringsFor(appLang) }

        var customStorages by remember { mutableStateOf(KomandirPrefs.getCustomStorages(context)) }
        val builtInStorages = remember(appLang) {
            val phoneRoot = Environment.getExternalStorageDirectory().absolutePath
            listOf(
                StorageSource("phone", t.phoneName, StorageKind.LOCAL, phoneRoot),
                StorageSource("gdrive", t.gdriveName, StorageKind.GOOGLE_DRIVE, "My Drive"),
                StorageSource("web", t.webDriveName, StorageKind.WEB_DRIVE, "WebDAV / Cloud"),
                StorageSource("lan", t.lanName, StorageKind.LAN_SHARE, "LAN Shares")
            )
        }
        val allStorages = builtInStorages + customStorages

        var dualPane by remember { mutableStateOf(false) }
        var activePane by remember { mutableIntStateOf(0) }

        var leftStorageId by remember { mutableStateOf("phone") }
        var rightStorageId by remember { mutableStateOf("gdrive") }

        var leftPath by remember { mutableStateOf(Environment.getExternalStorageDirectory().absolutePath) }
        var rightPath by remember { mutableStateOf("My Drive") }

        var leftSelected by remember { mutableStateOf(setOf<String>()) }
        var rightSelected by remember { mutableStateOf(setOf<String>()) }

        var searchOpen by remember { mutableStateOf(false) }
        var searchQuery by remember { mutableStateOf("") }

        var showVersionDialog by remember { mutableStateOf(false) }
        var showSettingsDialog by remember { mutableStateOf(false) }
        var showAddStorageDialog by remember { mutableStateOf(false) }
        var showNewFolderDialog by remember { mutableStateOf(false) }
        var showRenameDialog by remember { mutableStateOf<FileEntry?>(null) }

        var refreshTick by remember { mutableIntStateOf(0) }

        fun hasStoragePermission(): Boolean {
            return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                Environment.isExternalStorageManager()
            } else {
                ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.READ_EXTERNAL_STORAGE
                ) == PackageManager.PERMISSION_GRANTED
            }
        }

        fun requestStoragePermission() {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION).apply {
                    data = Uri.parse("package:${context.packageName}")
                }
                context.startActivity(intent)
            } else {
                Toast.makeText(context, t.permissionTitle, Toast.LENGTH_SHORT).show()
            }
        }

        val currentPaneStorageId = if (activePane == 0) leftStorageId else rightStorageId
        val currentSelection = if (activePane == 0) leftSelected else rightSelected

        Scaffold(
            topBar = {
                KomandirHeader(
                    dualPane = dualPane,
                    onVersionClick = { showVersionDialog = true },
                    onToggleDualPane = {
                        dualPane = !dualPane
                        if (!dualPane) activePane = 0
                    },
                    onToggleSearch = {
                        searchOpen = !searchOpen
                        if (!searchOpen) searchQuery = ""
                    },
                    onOpenSettings = { showSettingsDialog = true }
                )
            },
            bottomBar = {
                KomandirBottomBar(
                    strings = t,
                    selectedCount = currentSelection.size,
                    onCopy = {
                        if (!dualPane) {
                            Toast.makeText(context, t.needDualPaneMsg, Toast.LENGTH_SHORT).show()
                        } else if (currentSelection.isEmpty()) {
                            Toast.makeText(context, t.selectFirstMsg, Toast.LENGTH_SHORT).show()
                        } else {
                            val srcId = if (activePane == 0) leftStorageId else rightStorageId
                            val dstId = if (activePane == 0) rightStorageId else leftStorageId
                            val dstPath = if (activePane == 0) rightPath else leftPath
                            if (srcId == "phone" && dstId == "phone") {
                                scope.launch(Dispatchers.IO) {
                                    currentSelection.forEach { p ->
                                        val src = File(p)
                                        val dst = File(dstPath, src.name)
                                        if (src.isDirectory) src.copyRecursively(dst, overwrite = true)
                                        else src.copyTo(dst, overwrite = true)
                                    }
                                    withContext(Dispatchers.Main) {
                                        if (activePane == 0) leftSelected = emptySet() else rightSelected = emptySet()
                                        refreshTick++
                                    }
                                }
                            } else {
                                Toast.makeText(context, "Transfer queued: ${currentSelection.size}", Toast.LENGTH_SHORT).show()
                            }
                        }
                    },
                    onMove = {
                        if (!dualPane) {
                            Toast.makeText(context, t.needDualPaneMsg, Toast.LENGTH_SHORT).show()
                        } else if (currentSelection.isEmpty()) {
                            Toast.makeText(context, t.selectFirstMsg, Toast.LENGTH_SHORT).show()
                        } else {
                            val srcId = if (activePane == 0) leftStorageId else rightStorageId
                            val dstId = if (activePane == 0) rightStorageId else leftStorageId
                            val dstPath = if (activePane == 0) rightPath else leftPath
                            if (srcId == "phone" && dstId == "phone") {
                                scope.launch(Dispatchers.IO) {
                                    currentSelection.forEach { p ->
                                        val src = File(p)
                                        val dst = File(dstPath, src.name)
                                        src.renameTo(dst)
                                    }
                                    withContext(Dispatchers.Main) {
                                        if (activePane == 0) leftSelected = emptySet() else rightSelected = emptySet()
                                        refreshTick++
                                    }
                                }
                            } else {
                                Toast.makeText(context, "Move queued: ${currentSelection.size}", Toast.LENGTH_SHORT).show()
                            }
                        }
                    },
                    onNewFolder = { showNewFolderDialog = true },
                    onRename = {
                        val first = currentSelection.firstOrNull()
                        if (first == null) {
                            Toast.makeText(context, t.selectFirstMsg, Toast.LENGTH_SHORT).show()
                        } else {
                            val f = File(first)
                            showRenameDialog = FileEntry(first, f.name, first, f.isDirectory, f.length(), f.lastModified())
                        }
                    },
                    onDelete = {
                        if (currentSelection.isEmpty()) {
                            Toast.makeText(context, t.selectFirstMsg, Toast.LENGTH_SHORT).show()
                        } else if (currentPaneStorageId == "phone") {
                            scope.launch(Dispatchers.IO) {
                                currentSelection.forEach { p -> File(p).deleteRecursively() }
                                withContext(Dispatchers.Main) {
                                    if (activePane == 0) leftSelected = emptySet() else rightSelected = emptySet()
                                    refreshTick++
                                }
                            }
                        }
                    }
                )
            }
        ) { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (searchOpen) {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        placeholder = { Text(t.searchHint, fontSize = 13.sp) },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    )
                }

                // Лента источников (Телефон, Google Диск, Веб-диски, Сеть LAN)
                Surface(
                    color = MaterialTheme.colorScheme.surface,
                    tonalElevation = 1.dp
                ) {
                    Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = t.storagesHeader.uppercase(),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = t.addDisk,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .clickable { showAddStorageDialog = true }
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(allStorages, key = { it.id }) { st ->
                                val selected = st.id == currentPaneStorageId
                                Surface(
                                    shape = RoundedCornerShape(10.dp),
                                    color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                                    border = BorderStroke(1.dp, if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant),
                                    modifier = Modifier.clickable {
                                        if (activePane == 0) {
                                            leftStorageId = st.id
                                            leftPath = st.rootPath
                                            leftSelected = emptySet()
                                        } else {
                                            rightStorageId = st.id
                                            rightPath = st.rootPath
                                            rightSelected = emptySet()
                                        }
                                    }
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(5.dp)
                                    ) {
                                        Icon(
                                            imageVector = when (st.kind) {
                                                StorageKind.LOCAL -> Icons.Default.PhoneAndroid
                                                StorageKind.GOOGLE_DRIVE -> Icons.Default.Cloud
                                                StorageKind.WEB_DRIVE -> Icons.Default.Language
                                                StorageKind.LAN_SHARE -> Icons.Default.Computer
                                            },
                                            contentDescription = null,
                                            tint = if (selected) Color.White else MaterialTheme.colorScheme.onSurface,
                                            modifier = Modifier.size(15.dp)
                                        )
                                        Text(
                                            text = st.title,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            color = if (selected) Color.White else MaterialTheme.colorScheme.onSurface
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // Панели файлов (1 или 2)
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .padding(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val leftSource = allStorages.firstOrNull { it.id == leftStorageId } ?: allStorages.first()
                    FilePaneView(
                        modifier = Modifier.weight(1f),
                        source = leftSource,
                        currentPath = leftPath,
                        selectedIds = leftSelected,
                        isActive = !dualPane || activePane == 0,
                        searchQuery = searchQuery,
                        hasPermission = hasStoragePermission(),
                        refreshTick = refreshTick,
                        strings = t,
                        onActivate = { activePane = 0 },
                        onRequestPermission = { requestStoragePermission() },
                        onNavigate = { newPath ->
                            activePane = 0
                            leftPath = newPath
                            leftSelected = emptySet()
                        },
                        onToggleSelect = { id ->
                            activePane = 0
                            leftSelected = if (id in leftSelected) leftSelected - id else leftSelected + id
                        },
                        onOpenFile = { entry ->
                            if (leftSource.kind == StorageKind.LOCAL) {
                                runCatching {
                                    val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", File(entry.path))
                                    val intent = Intent(Intent.ACTION_VIEW).apply {
                                        setDataAndType(uri, "*/*")
                                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                    }
                                    context.startActivity(intent)
                                }
                            }
                        }
                    )

                    if (dualPane) {
                        val rightSource = allStorages.firstOrNull { it.id == rightStorageId } ?: allStorages.first()
                        FilePaneView(
                            modifier = Modifier.weight(1f),
                            source = rightSource,
                            currentPath = rightPath,
                            selectedIds = rightSelected,
                            isActive = activePane == 1,
                            searchQuery = searchQuery,
                            hasPermission = hasStoragePermission(),
                            refreshTick = refreshTick,
                            strings = t,
                            onActivate = { activePane = 1 },
                            onRequestPermission = { requestStoragePermission() },
                            onNavigate = { newPath ->
                                activePane = 1
                                rightPath = newPath
                                rightSelected = emptySet()
                            },
                            onToggleSelect = { id ->
                                activePane = 1
                                rightSelected = if (id in rightSelected) rightSelected - id else rightSelected + id
                            },
                            onOpenFile = { entry ->
                                if (rightSource.kind == StorageKind.LOCAL) {
                                    runCatching {
                                        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", File(entry.path))
                                        val intent = Intent(Intent.ACTION_VIEW).apply {
                                            setDataAndType(uri, "*/*")
                                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                        }
                                        context.startActivity(intent)
                                    }
                                }
                            }
                        )
                    }
                }
            }
        }

        // Окно полной версии по тапу на "v.1 by mizgiroff"
        if (showVersionDialog) {
            AlertDialog(
                onDismissRequest = { showVersionDialog = false },
                title = { Text("Komandir · v.1 by mizgiroff", fontWeight = FontWeight.Bold) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("${t.versionFullLabel} v1_26.11.21 (код 1)", fontWeight = FontWeight.SemiBold)
                        Text("${t.versionAuthorLabel} mizgiroff")
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(t.versionDesc, fontSize = 13.sp)
                    }
                },
                confirmButton = {
                    Button(onClick = { showVersionDialog = false }) { Text(t.okBtn) }
                }
            )
        }

        // Окно настроек (Тема + Язык)
        if (showSettingsDialog) {
            AlertDialog(
                onDismissRequest = { showSettingsDialog = false },
                title = { Text(t.settingsTitle, fontWeight = FontWeight.Bold) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text(t.themeLabel, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf(
                                AppThemeMode.LIGHT to t.themeLight,
                                AppThemeMode.DARK to t.themeDark,
                                AppThemeMode.SYSTEM to t.themeSystem
                            ).forEach { (mode, label) ->
                                val active = themeMode == mode
                                OutlinedButton(
                                    onClick = {
                                        themeMode = mode
                                        KomandirPrefs.setTheme(context, mode)
                                    },
                                    modifier = Modifier.weight(1f),
                                    contentPadding = PaddingValues(horizontal = 4.dp, vertical = 6.dp),
                                    colors = ButtonDefaults.outlinedButtonColors(
                                        containerColor = if (active) MaterialTheme.colorScheme.primary else Color.Transparent,
                                        contentColor = if (active) Color.White else MaterialTheme.colorScheme.onSurface
                                    )
                                ) {
                                    Text(label, fontSize = 11.sp, maxLines = 1)
                                }
                            }
                        }

                        Text(t.langLabel, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            AppLang.entries.forEach { lang ->
                                val active = appLang == lang
                                OutlinedButton(
                                    onClick = {
                                        appLang = lang
                                        KomandirPrefs.setLang(context, lang)
                                    },
                                    modifier = Modifier.weight(1f),
                                    contentPadding = PaddingValues(horizontal = 4.dp, vertical = 6.dp),
                                    colors = ButtonDefaults.outlinedButtonColors(
                                        containerColor = if (active) MaterialTheme.colorScheme.primary else Color.Transparent,
                                        contentColor = if (active) Color.White else MaterialTheme.colorScheme.onSurface
                                    )
                                ) {
                                    Text(lang.label, fontSize = 11.sp, maxLines = 1)
                                }
                            }
                        }
                    }
                },
                confirmButton = {
                    Button(onClick = { showSettingsDialog = false }) { Text(t.done) }
                }
            )
        }

        // Первый запуск: выбор языка (как в Barvy)
        if (showLangPrompt) {
            AlertDialog(
                onDismissRequest = {},
                title = { Text(t.chooseLangTitle, fontWeight = FontWeight.Bold) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        AppLang.entries.forEach { lang ->
                            Button(
                                onClick = {
                                    appLang = lang
                                    KomandirPrefs.setLang(context, lang)
                                    showLangPrompt = false
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(lang.label)
                            }
                        }
                    }
                },
                confirmButton = {}
            )
        }

        // Подключение нового веб-диска / сетевой шары
        if (showAddStorageDialog) {
            var newName by remember { mutableStateOf("") }
            var newHost by remember { mutableStateOf("") }
            var newKind by remember { mutableStateOf(StorageKind.LAN_SHARE) }
            AlertDialog(
                onDismissRequest = { showAddStorageDialog = false },
                title = { Text(t.addStorageTitle, fontWeight = FontWeight.Bold) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            listOf(
                                StorageKind.LAN_SHARE to "SMB/FTP",
                                StorageKind.WEB_DRIVE to "WebDAV",
                                StorageKind.GOOGLE_DRIVE to "Cloud"
                            ).forEach { (kind, lbl) ->
                                OutlinedButton(
                                    onClick = { newKind = kind },
                                    modifier = Modifier.weight(1f),
                                    contentPadding = PaddingValues(4.dp),
                                    colors = ButtonDefaults.outlinedButtonColors(
                                        containerColor = if (newKind == kind) MaterialTheme.colorScheme.primary else Color.Transparent,
                                        contentColor = if (newKind == kind) Color.White else MaterialTheme.colorScheme.onSurface
                                    )
                                ) {
                                    Text(lbl, fontSize = 11.sp)
                                }
                            }
                        }
                        OutlinedTextField(
                            value = newName,
                            onValueChange = { newName = it },
                            label = { Text(t.storageNameLabel) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        OutlinedTextField(
                            value = newHost,
                            onValueChange = { newHost = it },
                            label = { Text(t.storageHostLabel) },
                            placeholder = { Text("smb://192.168.1.50/Public") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                },
                confirmButton = {
                    Button(onClick = {
                        val src = StorageSource(
                            id = "custom_${System.currentTimeMillis()}",
                            title = newName.ifBlank { "Network Drive" },
                            kind = newKind,
                            rootPath = newHost.ifBlank { "192.168.1.50" },
                            host = newHost.ifBlank { "192.168.1.50" },
                            isCustom = true
                        )
                        KomandirPrefs.addCustomStorage(context, src)
                        customStorages = KomandirPrefs.getCustomStorages(context)
                        showAddStorageDialog = false
                    }) { Text(t.connectBtn) }
                },
                dismissButton = {
                    TextButton(onClick = { showAddStorageDialog = false }) { Text(t.cancelBtn) }
                }
            )
        }

        // Новая папка
        if (showNewFolderDialog) {
            var folderName by remember { mutableStateOf("NewFolder") }
            AlertDialog(
                onDismissRequest = { showNewFolderDialog = false },
                title = { Text(t.newFolderTitle) },
                text = {
                    OutlinedTextField(
                        value = folderName,
                        onValueChange = { folderName = it },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                },
                confirmButton = {
                    Button(onClick = {
                        val targetDir = if (activePane == 0) leftPath else rightPath
                        if (currentPaneStorageId == "phone" && folderName.isNotBlank()) {
                            File(targetDir, folderName.trim()).mkdirs()
                            refreshTick++
                        }
                        showNewFolderDialog = false
                    }) { Text(t.okBtn) }
                },
                dismissButton = {
                    TextButton(onClick = { showNewFolderDialog = false }) { Text(t.cancelBtn) }
                }
            )
        }

        // Переименование
        showRenameDialog?.let { entry ->
            var newName by remember { mutableStateOf(entry.name) }
            AlertDialog(
                onDismissRequest = { showRenameDialog = null },
                title = { Text(t.renameTitle) },
                text = {
                    OutlinedTextField(
                        value = newName,
                        onValueChange = { newName = it },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                },
                confirmButton = {
                    Button(onClick = {
                        if (currentPaneStorageId == "phone" && newName.isNotBlank()) {
                            val src = File(entry.path)
                            src.renameTo(File(src.parentFile, newName.trim()))
                            if (activePane == 0) leftSelected = emptySet() else rightSelected = emptySet()
                            refreshTick++
                        }
                        showRenameDialog = null
                    }) { Text(t.okBtn) }
                },
                dismissButton = {
                    TextButton(onClick = { showRenameDialog = null }) { Text(t.cancelBtn) }
                }
            )
        }
    }
}

@Composable
private fun KomandirHeader(
    dualPane: Boolean,
    onVersionClick: () -> Unit,
    onToggleDualPane: () -> Unit,
    onToggleSearch: () -> Unit,
    onOpenSettings: () -> Unit
) {
    // Сине-жёлтая переливающаяся заливка (как в Barvy и MedAssist)
    val transition = rememberInfiniteTransition(label = "barvyShimmer")
    val shift by transition.animateFloat(
        initialValue = 0f,
        targetValue = 600f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 6000, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "shift"
    )
    val shimmerBrush = Brush.linearGradient(
        colors = listOf(BrandBlue, BrandBlue, BrandYellow, BrandBlue),
        start = Offset(shift - 250f, 0f),
        end = Offset(shift + 150f, 120f)
    )

    Surface(
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 2.dp
    ) {
        Column {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.Bottom,
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(shimmerBrush),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.ViewColumn,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Komandir",
                        style = TextStyle(
                            brush = shimmerBrush,
                            fontSize = 22.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = BrandBlue.copy(alpha = 0.12f),
                        modifier = Modifier
                            .padding(bottom = 2.dp)
                            .clickable { onVersionClick() }
                    ) {
                        Text(
                            text = "v.1 by mizgiroff",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.primary,
                            maxLines = 1,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onToggleDualPane, modifier = Modifier.size(36.dp)) {
                        Icon(
                            imageVector = Icons.Default.ViewColumn,
                            contentDescription = "Dual Pane",
                            tint = if (dualPane) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                        )
                    }
                    IconButton(onClick = onToggleSearch, modifier = Modifier.size(36.dp)) {
                        Icon(imageVector = Icons.Default.Search, contentDescription = "Search")
                    }
                    IconButton(onClick = onOpenSettings, modifier = Modifier.size(36.dp)) {
                        Icon(imageVector = Icons.Default.Settings, contentDescription = "Settings")
                    }
                }
            }
            HorizontalDivider()
        }
    }
}

@Composable
private fun FilePaneView(
    modifier: Modifier,
    source: StorageSource,
    currentPath: String,
    selectedIds: Set<String>,
    isActive: Boolean,
    searchQuery: String,
    hasPermission: Boolean,
    refreshTick: Int,
    strings: UiStrings,
    onActivate: () -> Unit,
    onRequestPermission: () -> Unit,
    onNavigate: (String) -> Unit,
    onToggleSelect: (String) -> Unit,
    onOpenFile: (FileEntry) -> Unit
) {
    var entries by remember { mutableStateOf<List<FileEntry>>(emptyList()) }

    LaunchedEffect(source.id, currentPath, refreshTick, hasPermission) {
        entries = withContext(Dispatchers.IO) {
            when (source.kind) {
                StorageKind.LOCAL -> {
                    if (!hasPermission) emptyList()
                    else listLocalDirectory(File(currentPath))
                }
                StorageKind.GOOGLE_DRIVE -> listOf(
                    FileEntry("gd_1", "Barvy", "My Drive/Barvy", true, 0L, 0L, "Google Drive"),
                    FileEntry("gd_2", "MedAssist", "My Drive/MedAssist", true, 0L, 0L, "Google Drive"),
                    FileEntry("gd_3", "Здоровье.gsheet", "My Drive/Здоровье.gsheet", false, 0L, 0L, "Google Sheet")
                )
                StorageKind.WEB_DRIVE -> listOf(
                    FileEntry("wd_1", "OneDrive (Personal)", "OneDrive", true, 0L, 0L, "Cloud"),
                    FileEntry("wd_2", "Nextcloud (WebDAV)", "Nextcloud", true, 0L, 0L, "WebDAV")
                )
                StorageKind.LAN_SHARE -> listOf(
                    FileEntry("lan_1", "NAS-Home (SMB 3.0)", "smb://192.168.1.50", true, 0L, 0L, "192.168.1.50"),
                    FileEntry("lan_2", "Router-USB (FTP)", "ftp://192.168.88.1", true, 0L, 0L, "192.168.88.1")
                )
            }
        }
    }

    val filtered = remember(entries, searchQuery) {
        if (searchQuery.isBlank()) entries
        else entries.filter { it.name.contains(searchQuery, ignoreCase = true) }
    }

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .clickable { onActivate() },
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(
            width = if (isActive) 1.5.dp else 1.dp,
            color = if (isActive) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant
        )
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "${source.title}: $currentPath",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = source.kind.badge,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
            }

            if (source.kind == StorageKind.LOCAL && !hasPermission) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(strings.permissionTitle, fontSize = 13.sp)
                        Spacer(modifier = Modifier.height(10.dp))
                        Button(onClick = onRequestPermission) {
                            Text(strings.permissionBtn)
                        }
                    }
                }
            } else {
                LazyColumn(modifier = Modifier.fillMaxSize()) {
                    val canGoUp = source.kind == StorageKind.LOCAL && currentPath != source.rootPath && File(currentPath).parentFile != null
                    if (canGoUp) {
                        item(key = "up_dir") {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        File(currentPath).parentFile?.absolutePath?.let(onNavigate)
                                    }
                                    .padding(horizontal = 12.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.Folder, contentDescription = null, tint = BrandYellow)
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(strings.upDir, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                            }
                            HorizontalDivider()
                        }
                    }

                    if (filtered.isEmpty()) {
                        item(key = "empty") {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(24.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(strings.emptyDir, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    } else {
                        items(filtered, key = { it.id }) { item ->
                            val isSel = item.id in selectedIds
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(if (isSel) MaterialTheme.colorScheme.primary.copy(alpha = 0.1f) else Color.Transparent)
                                    .clickable {
                                        if (item.isDirectory && source.kind == StorageKind.LOCAL) {
                                            onNavigate(item.path)
                                        } else {
                                            onOpenFile(item)
                                        }
                                    }
                                    .padding(horizontal = 8.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Checkbox(
                                    checked = isSel,
                                    onCheckedChange = { onToggleSelect(item.id) }
                                )
                                Icon(
                                    imageVector = if (item.isDirectory) Icons.Default.Folder else Icons.Default.InsertDriveFile,
                                    contentDescription = null,
                                    tint = if (item.isDirectory) Color(0xFFEAB308) else MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(22.dp)
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = item.name,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Medium,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = item.subtitle,
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                            HorizontalDivider()
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun KomandirBottomBar(
    strings: UiStrings,
    selectedCount: Int,
    onCopy: () -> Unit,
    onMove: () -> Unit,
    onNewFolder: () -> Unit,
    onRename: () -> Unit,
    onDelete: () -> Unit
) {
    Surface(
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 3.dp
    ) {
        Column(modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)) {
            Text(
                text = if (selectedCount > 0) strings.selectedCount(selectedCount) else strings.nothingSelected,
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                ActionChip(Modifier.weight(1f), Icons.Default.ContentCopy, strings.actCopy, onCopy)
                ActionChip(Modifier.weight(1f), Icons.Default.DriveFileMove, strings.actMove, onMove)
                ActionChip(Modifier.weight(1f), Icons.Default.CreateNewFolder, strings.actNewFolder, onNewFolder)
                ActionChip(Modifier.weight(1f), Icons.Default.Edit, strings.actRename, onRename)
                ActionChip(Modifier.weight(1f), Icons.Default.Delete, strings.actDelete, onDelete, isDanger = true)
            }
        }
    }
}

@Composable
private fun ActionChip(
    modifier: Modifier,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    onClick: () -> Unit,
    isDanger: Boolean = false
) {
    Surface(
        modifier = modifier
            .heightIn(min = 44.dp)
            .clip(RoundedCornerShape(10.dp))
            .clickable { onClick() },
        shape = RoundedCornerShape(10.dp),
        color = MaterialTheme.colorScheme.surfaceVariant
    ) {
        Column(
            modifier = Modifier.padding(vertical = 6.dp, horizontal = 2.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = if (isDanger) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = label,
                fontSize = 10.sp,
                fontWeight = FontWeight.Medium,
                color = if (isDanger) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface,
                maxLines = 1
            )
        }
    }
}
