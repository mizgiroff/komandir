package main

import (
	"bufio"
	"crypto/rand"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"log"
	"net"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"runtime"
	"strings"
	"sync"

	"github.com/skip2/go-qrcode"
	"golang.org/x/net/webdav"
)

type BridgeConfig struct {
	DeviceID string `json:"deviceId"`
	Name     string `json:"name"`
	Folder   string `json:"folder"`
	User     string `json:"user"`
	Pass     string `json:"pass"`
	Port     int    `json:"port"`
}

type QrPayload struct {
	Type      string `json:"type"`
	DeviceID  string `json:"deviceId"`
	Name      string `json:"name"`
	LanURL    string `json:"lanUrl"`
	TunnelURL string `json:"tunnelUrl"`
	User      string `json:"user"`
	Pass      string `json:"pass"`
}

var (
	mu        sync.RWMutex
	cfg       BridgeConfig
	tunnelURL string
)

func randHex(n int) string {
	b := make([]byte, n)
	_, _ = rand.Read(b)
	return hex.EncodeToString(b)
}

func configPath() string {
	dir, err := os.UserConfigDir()
	if err != nil {
		dir = "."
	}
	appDir := filepath.Join(dir, "KomandirBridge")
	_ = os.MkdirAll(appDir, 0755)
	return filepath.Join(appDir, "config.json")
}

func loadOrCreateConfig() BridgeConfig {
	p := configPath()
	if data, err := os.ReadFile(p); err == nil {
		var c BridgeConfig
		if json.Unmarshal(data, &c) == nil && c.DeviceID != "" {
			if c.Port == 0 {
				c.Port = 8765
			}
			return c
		}
	}
	host, _ := os.Hostname()
	if host == "" {
		host = "Windows-PC"
	}
	home, _ := os.UserHomeDir()
	c := BridgeConfig{
		DeviceID: "pc_" + randHex(6),
		Name:     host,
		Folder:   home,
		User:     "komandir",
		Pass:     randHex(8),
		Port:     8765,
	}
	saveConfig(c)
	return c
}

func saveConfig(c BridgeConfig) {
	data, _ := json.MarshalIndent(c, "", "  ")
	_ = os.WriteFile(configPath(), data, 0600)
}

func getLocalIP() string {
	conn, err := net.Dial("udp", "8.8.8.8:80")
	if err == nil {
		defer conn.Close()
		if addr, ok := conn.LocalAddr().(*net.UDPAddr); ok {
			return addr.IP.String()
		}
	}
	return "127.0.0.1"
}

func ensureCloudflared() (string, error) {
	exeName := "cloudflared"
	if runtime.GOOS == "windows" {
		exeName = "cloudflared.exe"
	}
	if p, err := exec.LookPath(exeName); err == nil {
		return p, nil
	}
	dir, _ := os.UserConfigDir()
	localBin := filepath.Join(dir, "KomandirBridge", exeName)
	if _, err := os.Stat(localBin); err == nil {
		return localBin, nil
	}
	if runtime.GOOS != "windows" {
		return "", fmt.Errorf("cloudflared not found in PATH")
	}
	log.Println("Downloading cloudflared.exe for free HTTPS tunnel...")
	resp, err := http.Get("https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-windows-amd64.exe")
	if err != nil {
		return "", err
	}
	defer resp.Body.Close()
	out, err := os.Create(localBin)
	if err != nil {
		return "", err
	}
	defer out.Close()
	if _, err := io.Copy(out, resp.Body); err != nil {
		return "", err
	}
	return localBin, nil
}

func startTunnel(port int) {
	bin, err := ensureCloudflared()
	if err != nil {
		log.Println("Tunnel unavailable (LAN only):", err)
		return
	}
	cmd := exec.Command(bin, "tunnel", "--url", fmt.Sprintf("http://127.0.0.1:%d", port))
	stderr, err := cmd.StderrPipe()
	if err != nil {
		return
	}
	if err := cmd.Start(); err != nil {
		log.Println("cloudflared start error:", err)
		return
	}
	re := regexp.MustCompile(`https://[a-zA-Z0-9-]+\.trycloudflare\.com`)
	sc := bufio.NewScanner(stderr)
	for sc.Scan() {
		line := sc.Text()
		if m := re.FindString(line); m != "" {
			mu.Lock()
			tunnelURL = m + "/"
			mu.Unlock()
			log.Println("Cloudflare Tunnel ready:", m)
		}
	}
}

func openBrowser(url string) {
	if runtime.GOOS == "windows" {
		_ = exec.Command("rundll32", "url.dll,FileProtocolHandler", url).Start()
	}
}

func main() {
	cfg = loadOrCreateConfig()
	if len(os.Args) > 1 && os.Args[1] != "" {
		if info, err := os.Stat(os.Args[1]); err == nil && info.IsDir() {
			cfg.Folder = os.Args[1]
			saveConfig(cfg)
		}
	}

	ln, err := net.Listen("tcp", fmt.Sprintf("0.0.0.0:%d", cfg.Port))
	if err != nil {
		ln, err = net.Listen("tcp", "0.0.0.0:0")
		if err != nil {
			log.Fatal(err)
		}
		cfg.Port = ln.Addr().(*net.TCPAddr).Port
		saveConfig(cfg)
	}

	go startTunnel(cfg.Port)

	mux := http.NewServeMux()
	mux.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		// Local setup UI only on 127.0.0.1 /_ui
		if strings.HasPrefix(r.URL.Path, "/_ui") {
			if r.Method == http.MethodPost {
				_ = r.ParseForm()
				if f := strings.TrimSpace(r.FormValue("folder")); f != "" {
					if info, err := os.Stat(f); err == nil && info.IsDir() {
						mu.Lock()
						cfg.Folder = f
						saveConfig(cfg)
						mu.Unlock()
					}
				}
				http.Redirect(w, r, "/_ui", http.StatusSeeOther)
				return
			}
			mu.RLock()
			c := cfg
			tURL := tunnelURL
			mu.RUnlock()
			lan := fmt.Sprintf("http://%s:%d/", getLocalIP(), c.Port)
			payload := QrPayload{
				Type:      "komandir_bridge",
				DeviceID:  c.DeviceID,
				Name:      c.Name,
				LanURL:    lan,
				TunnelURL: tURL,
				User:      c.User,
				Pass:      c.Pass,
			}
			rawJSON, _ := json.Marshal(payload)
			pngBytes, _ := qrcode.Encode(string(rawJSON), qrcode.Medium, 280)
			b64 := base64.StdEncoding.EncodeToString(pngBytes)
			tStatus := tURL
			if tStatus == "" {
				tStatus = "Connecting Cloudflare Tunnel..."
			}
			w.Header().Set("Content-Type", "text/html; charset=utf-8")
			fmt.Fprintf(w, `<!doctype html><html><head><meta charset="utf-8"><title>Komandir Bridge</title>
<style>body{font-family:sans-serif;background:#121216;color:#eee;max-width:560px;margin:24px auto;padding:16px}
.card{background:#1e1e26;padding:18px;border-radius:14px;border:1px solid #333}
input{width:100%%;padding:10px;border-radius:8px;border:1px solid #444;background:#121216;color:#fff;margin:8px 0}
button{background:#0057B7;color:#FFDD00;border:none;padding:10px 18px;border-radius:8px;font-weight:bold;cursor:pointer}
.qr{background:#fff;padding:12px;border-radius:12px;display:inline-block;margin:12px 0}
code{word-break:break-all;font-size:12px;color:#9ecbff}</style></head>
<body><div class="card"><h2>Komandir Bridge (%s)</h2>
<form method="post" action="/_ui">
<label>Shared Folder:</label>
<input name="folder" value="%s" />
<button type="submit">Save Folder</button></form>
<p><b>LAN:</b> <code>%s</code><br><b>Tunnel:</b> <code>%s</code></p>
<div class="qr"><img src="data:image/png;base64,%s" /></div>
<p style="font-size:12px;color:#aaa">Scan this QR code in Komandir (+ Connect → PC via QR code). Keep this window open while syncing.</p>
<details><summary>JSON (manual fallback)</summary><code>%s</code></details>
</div><script>if(!%t){setTimeout(()=>location.reload(),2500)}</script></body></html>`,
				c.Name, c.Folder, lan, tStatus, b64, string(rawJSON), tURL != "")
			return
		}

		// WebDAV Basic Auth
		user, pass, ok := r.BasicAuth()
		mu.RLock()
		c := cfg
		mu.RUnlock()
		if !ok || user != c.User || pass != c.Pass {
			w.Header().Set("WWW-Authenticate", `Basic realm="KomandirBridge"`)
			http.Error(w, "Unauthorized", http.StatusUnauthorized)
			return
		}
		handler := &webdav.Handler{
			FileSystem: webdav.Dir(c.Folder),
			LockSystem: webdav.NewMemLS(),
		}
		handler.ServeHTTP(w, r)
	})

	uiURL := fmt.Sprintf("http://127.0.0.1:%d/_ui", cfg.Port)
	log.Println("Komandir Bridge running! Open:", uiURL)
	openBrowser(uiURL)
	log.Fatal(http.Serve(ln, mux))
}
