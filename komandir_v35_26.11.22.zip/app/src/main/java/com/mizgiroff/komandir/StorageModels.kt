package com.mizgiroff.komandir

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

enum class AppThemeMode(val key: String) {
    LIGHT("light"),
    DARK("dark"),
    SYSTEM("system");

    companion object {
        fun fromKey(key: String?): AppThemeMode =
            entries.firstOrNull { it.key == key } ?: SYSTEM
    }
}

enum class AppLang(val key: String, val label: String) {
    UK("uk", "Українська"),
    EN("en", "English"),
    RU("ru", "Русский");

    companion object {
        fun fromKey(key: String?): AppLang =
            entries.firstOrNull { it.key == key } ?: UK
    }
}

enum class StorageKind(val badge: String) {
    LOCAL("Local"),
    GDRIVE_API("Drive API"),
    SAF_CLOUD("Cloud / SAF"),
    WEBDAV("WebDAV"),
    SMB("SMB"),
    FTP("FTP")
}

data class StorageSource(
    val id: String,
    val title: String,
    val kind: StorageKind,
    val rootPath: String,
    val host: String = "",
    val shareName: String = "",
    val username: String = "",
    val password: String = "",
    val isCustom: Boolean = false
)

data class FileEntry(
    val id: String,
    val name: String,
    val path: String,
    val isDirectory: Boolean,
    val sizeBytes: Long,
    val lastModified: Long,
    val subtitle: String = ""
)

object KomandirPrefs {
    private const val PREFS_NAME = "komandir_prefs"
    private const val KEY_THEME = "theme_mode"
    private const val KEY_LANG = "app_lang"
    private const val KEY_LANG_SET = "app_lang_chosen"
    private const val KEY_DEFAULT_PROMPT_SHOWN = "default_prompt_shown"
    private const val KEY_CUSTOM_STORAGES = "custom_storages"
    private const val KEY_GD_CLIENT_ID = "gd_client_id"
    private const val KEY_GD_CLIENT_SECRET = "gd_client_secret"
    private const val KEY_GD_ACCESS = "gd_access_token"
    private const val KEY_GD_REFRESH = "gd_refresh_token"
    private const val KEY_GD_VERIFIER = "gd_pkce_verifier"
    private const val KEY_GEMINI_BRANCH = "gemini_branch_url"

    fun getTheme(context: Context): AppThemeMode {
        val sp = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return AppThemeMode.fromKey(sp.getString(KEY_THEME, AppThemeMode.SYSTEM.key))
    }

    fun setTheme(context: Context, mode: AppThemeMode) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit().putString(KEY_THEME, mode.key).apply()
    }

    fun isDefaultPromptShown(context: Context): Boolean =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getBoolean(KEY_DEFAULT_PROMPT_SHOWN, false)

    fun setDefaultPromptShown(context: Context) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit().putBoolean(KEY_DEFAULT_PROMPT_SHOWN, true).apply()
    }

    fun isLangChosen(context: Context): Boolean =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getBoolean(KEY_LANG_SET, false)

    fun getLang(context: Context): AppLang {
        val sp = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return AppLang.fromKey(sp.getString(KEY_LANG, AppLang.UK.key))
    }

    fun setLang(context: Context, lang: AppLang) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_LANG, lang.key)
            .putBoolean(KEY_LANG_SET, true)
            .apply()
    }

    fun getCustomStorages(context: Context): List<StorageSource> {
        val raw = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getString(KEY_CUSTOM_STORAGES, "[]") ?: "[]"
        val list = mutableListOf<StorageSource>()
        return try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                val kind = runCatching { StorageKind.valueOf(obj.getString("kind")) }
                    .getOrDefault(StorageKind.SMB)
                list.add(
                    StorageSource(
                        id = obj.getString("id"),
                        title = obj.getString("title"),
                        kind = kind,
                        rootPath = obj.optString("rootPath", "/"),
                        host = obj.optString("host", ""),
                        shareName = obj.optString("shareName", ""),
                        username = obj.optString("username", ""),
                        password = obj.optString("password", ""),
                        isCustom = true
                    )
                )
            }
            list
        } catch (_: Exception) {
            emptyList()
        }
    }

    const val DEFAULT_GD_CLIENT_ID = "864168741040-7r9g0vd266q4nse01qfvaudqi2ldos3k.apps.googleusercontent.com"
    const val DEFAULT_GD_CLIENT_SECRET = "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"

    fun getGeminiBranchUrl(context: Context): String {
        val sp = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return sp.getString(KEY_GEMINI_BRANCH, "") ?: ""
    }

    fun setGeminiBranchUrl(context: Context, url: String) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit().putString(KEY_GEMINI_BRANCH, url.trim()).apply()
    }

    fun getGdClientId(context: Context): String =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).getString(KEY_GD_CLIENT_ID, "") ?: ""

    fun getGdClientSecret(context: Context): String =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).getString(KEY_GD_CLIENT_SECRET, "") ?: ""

    fun setGdClientSecret(context: Context, secret: String) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit().putString(KEY_GD_CLIENT_SECRET, secret).apply()
    }

    fun setGdClientId(context: Context, id: String) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit().putString(KEY_GD_CLIENT_ID, id).apply()
    }

    fun getGdAccessToken(context: Context): String =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).getString(KEY_GD_ACCESS, "") ?: ""

    fun getGdRefreshToken(context: Context): String =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).getString(KEY_GD_REFRESH, "") ?: ""

    fun saveGdTokens(context: Context, access: String, refresh: String) {
        val ed = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit().putString(KEY_GD_ACCESS, access)
        if (refresh.isNotBlank()) ed.putString(KEY_GD_REFRESH, refresh)
        ed.apply()
    }

    fun getGdVerifier(context: Context): String =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).getString(KEY_GD_VERIFIER, "") ?: ""

    fun setGdVerifier(context: Context, v: String) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit().putString(KEY_GD_VERIFIER, v).apply()
    }

    fun removeCustomStorage(context: Context, id: String) {
        val updated = getCustomStorages(context).filterNot { it.id == id }
        val arr = JSONArray()
        updated.forEach { s ->
            arr.put(JSONObject().apply {
                put("id", s.id)
                put("title", s.title)
                put("kind", s.kind.name)
                put("rootPath", s.rootPath)
                put("host", s.host)
                put("shareName", s.shareName)
                put("username", s.username)
                put("password", s.password)
            })
        }
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit().putString(KEY_CUSTOM_STORAGES, arr.toString()).apply()
    }

    fun addCustomStorage(context: Context, source: StorageSource) {
        val current = getCustomStorages(context) + source
        val arr = JSONArray()
        current.forEach { s ->
            arr.put(JSONObject().apply {
                put("id", s.id)
                put("title", s.title)
                put("kind", s.kind.name)
                put("rootPath", s.rootPath)
                put("host", s.host)
                put("shareName", s.shareName)
                put("username", s.username)
                put("password", s.password)
            })
        }
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit().putString(KEY_CUSTOM_STORAGES, arr.toString()).apply()
    }
}

fun formatFileSize(bytes: Long): String {
    if (bytes < 1024) return "$bytes B"
    val kb = bytes / 1024.0
    if (kb < 1024) return String.format("%.1f KB", kb)
    val mb = kb / 1024.0
    if (mb < 1024) return String.format("%.1f MB", mb)
    return String.format("%.2f GB", mb / 1024.0)
}

fun listLocalDirectory(dir: File): List<FileEntry> {
    val files = dir.listFiles() ?: return emptyList()
    return files
        .sortedWith(compareBy<File> { !it.isDirectory }.thenBy { it.name.lowercase() })
        .map { f ->
            FileEntry(
                id = f.absolutePath,
                name = f.name,
                path = f.absolutePath,
                isDirectory = f.isDirectory,
                sizeBytes = if (f.isDirectory) 0L else f.length(),
                lastModified = f.lastModified(),
                subtitle = if (f.isDirectory) {
                    val count = f.list()?.size ?: 0
                    "$count"
                } else {
                    formatFileSize(f.length())
                }
            )
        }

}
