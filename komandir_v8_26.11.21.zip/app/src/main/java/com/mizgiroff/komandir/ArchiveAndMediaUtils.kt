package com.mizgiroff.komandir

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

data class ZipItemInfo(
    val name: String,
    val sizeBytes: Long,
    val isDirectory: Boolean
)

fun isImageFileName(name: String): Boolean {
    val low = name.lowercase()
    return low.endsWith(".jpg") || low.endsWith(".jpeg") ||
        low.endsWith(".png") || low.endsWith(".webp") ||
        low.endsWith(".gif") || low.endsWith(".bmp")
}

fun isZipFileName(name: String): Boolean = name.lowercase().endsWith(".zip")

fun listZipEntries(file: File): List<ZipItemInfo> {
    val result = mutableListOf<ZipItemInfo>()
    ZipInputStream(BufferedInputStream(FileInputStream(file))).use { zis ->
        var entry: ZipEntry? = zis.nextEntry
        while (entry != null) {
            result.add(ZipItemInfo(entry.name, entry.size.coerceAtLeast(0L), entry.isDirectory))
            zis.closeEntry()
            entry = zis.nextEntry
        }
    }
    return result
}

fun listZipEntriesFromUri(context: Context, uri: Uri): List<ZipItemInfo> {
    val result = mutableListOf<ZipItemInfo>()
    context.contentResolver.openInputStream(uri)?.use { stream ->
        ZipInputStream(BufferedInputStream(stream)).use { zis ->
            var entry: ZipEntry? = zis.nextEntry
            while (entry != null) {
                result.add(ZipItemInfo(entry.name, entry.size.coerceAtLeast(0L), entry.isDirectory))
                zis.closeEntry()
                entry = zis.nextEntry
            }
        }
    }
    return result
}

fun extractZipFile(zipFile: File, targetDir: File): Int {
    if (!targetDir.exists()) targetDir.mkdirs()
    var count = 0
    val targetCanonical = targetDir.canonicalPath
    ZipInputStream(BufferedInputStream(FileInputStream(zipFile))).use { zis ->
        var entry: ZipEntry? = zis.nextEntry
        while (entry != null) {
            val outFile = File(targetDir, entry.name)
            if (outFile.canonicalPath.startsWith(targetCanonical)) {
                if (entry.isDirectory) {
                    outFile.mkdirs()
                } else {
                    outFile.parentFile?.mkdirs()
                    BufferedOutputStream(FileOutputStream(outFile)).use { bos ->
                        zis.copyTo(bos)
                    }
                    count++
                }
            }
            zis.closeEntry()
            entry = zis.nextEntry
        }
    }
    return count
}

fun extractZipFromUri(context: Context, uri: Uri, targetDir: File): Int {
    if (!targetDir.exists()) targetDir.mkdirs()
    var count = 0
    val targetCanonical = targetDir.canonicalPath
    context.contentResolver.openInputStream(uri)?.use { stream ->
        ZipInputStream(BufferedInputStream(stream)).use { zis ->
            var entry: ZipEntry? = zis.nextEntry
            while (entry != null) {
                val outFile = File(targetDir, entry.name)
                if (outFile.canonicalPath.startsWith(targetCanonical)) {
                    if (entry.isDirectory) {
                        outFile.mkdirs()
                    } else {
                        outFile.parentFile?.mkdirs()
                        BufferedOutputStream(FileOutputStream(outFile)).use { bos ->
                            zis.copyTo(bos)
                        }
                        count++
                    }
                }
                zis.closeEntry()
                entry = zis.nextEntry
            }
        }
    }
    return count
}

fun createZipArchive(sources: List<File>, destZip: File) {
    ZipOutputStream(BufferedOutputStream(FileOutputStream(destZip))).use { zos ->
        fun addFile(file: File, baseName: String) {
            if (file.isDirectory) {
                val children = file.listFiles() ?: emptyArray()
                if (children.isEmpty()) {
                    zos.putNextEntry(ZipEntry("$baseName/"))
                    zos.closeEntry()
                } else {
                    children.forEach { child -> addFile(child, "$baseName/${child.name}") }
                }
            } else {
                FileInputStream(file).use { fis ->
                    zos.putNextEntry(ZipEntry(baseName))
                    fis.copyTo(zos)
                    zos.closeEntry()
                }
            }
        }
        sources.forEach { src -> addFile(src, src.name) }
    }
}

fun decodeSampledBitmap(file: File, maxDim: Int = 2048): Bitmap? {
    val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeFile(file.absolutePath, opts)
    var sample = 1
    while (opts.outWidth / sample > maxDim || opts.outHeight / sample > maxDim) {
        sample *= 2
    }
    val decodeOpts = BitmapFactory.Options().apply { inSampleSize = sample }
    return BitmapFactory.decodeFile(file.absolutePath, decodeOpts)
}

fun decodeSampledBitmapFromUri(context: Context, uri: Uri, maxDim: Int = 2048): Bitmap? {
    val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
    var sample = 1
    while (opts.outWidth / sample > maxDim || opts.outHeight / sample > maxDim) {
        sample *= 2
    }
    val decodeOpts = BitmapFactory.Options().apply { inSampleSize = sample }
    return context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, decodeOpts) }
}
