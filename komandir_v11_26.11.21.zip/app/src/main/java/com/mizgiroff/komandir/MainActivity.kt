package com.mizgiroff.komandir

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.Computer
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.CreateNewFolder
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DriveFileMove
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.InsertDriveFile
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ViewColumn
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material.icons.filled.Check
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.layout.offset
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.unit.IntOffset
import kotlin.math.roundToInt
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val isPickMode = intent?.action in listOf(
            Intent.ACTION_GET_CONTENT,
            Intent.ACTION_OPEN_DOCUMENT,
            Intent.ACTION_PICK
        )
        val viewUri = if (intent?.action == Intent.ACTION_VIEW) intent?.data else null
        val viewMime = if (intent?.action == Intent.ACTION_VIEW) intent?.type else null
        setContent {
            KomandirApp(
                isPickMode = isPickMode,
                initialViewUri = viewUri,
                initialViewMime = viewMime,
                onPickFile = { file ->
                    val uri = FileProvider.getUriForFile(
                        this,
                        "${packageName}.fileprovider",
                        file
                    )
                    val res = Intent().apply {
                        data = uri
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    setResult(RESULT_OK, res)
                    finish()
                },
                onCancelPick = {
                    setResult(RESULT_CANCELED)
                    finish()
                }
            )
        }
    }
}

private val BrandBlue = Color(0xFF0057B7)
private val BrandYellow = Color(0xFFFFDD00)

@Composable
fun KomandirApp(
    isPickMode: Boolean = false,
    initialViewUri: Uri? = null,
    initialViewMime: String? = null,
    onPickFile: (File) -> Unit = {},
    onCancelPick: () -> Unit = {}
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var themeMode by remember { mutableStateOf(KomandirPrefs.getTheme(context)) }
    var appLang by remember { mutableStateOf(KomandirPrefs.getLang(context)) }
    var showLangPrompt by remember { mutableStateOf(!KomandirPrefs.isLangChosen(context)) }
    var showDefaultPrompt by remember { mutableStateOf(!KomandirPrefs.isDefaultPromptShown(context)) }

    val isDark = when (themeMode) {
        AppThemeMode.DARK -> true
        AppThemeMode.LIGHT -> false
        AppThemeMode.SYSTEM -> isSystemInDarkTheme()
    }

    val colorScheme = if (isDark) {
        darkColorScheme(
            primary = Color(0xFF7C83FD),
            background = Color(0xFF121216),
            surface = Color(0xFF1C1C22),
            surfaceVariant = Color(0xFF26262E)
        )
    } else {
        lightColorScheme(
            primary = BrandBlue,
            background = Color(0xFFF8FAFC),
            surface = Color(0xFFFFFFFF),
            surfaceVariant = Color(0xFFF1F5F9)
        )
    }

    MaterialTheme(colorScheme = colorScheme) {
        val t = remember(appLang) { stringsFor(appLang) }

        var customStorages by remember { mutableStateOf(KomandirPrefs.getCustomStorages(context)) }
        val builtInStorages = remember(appLang) {
            val phoneRoot = Environment.getExternalStorageDirectory().absolutePath
            listOf(
                StorageSource("phone", t.phoneName, StorageKind.LOCAL, phoneRoot)
            )
        }
        val allStorages = builtInStorages + customStorages

        var dualPane by remember { mutableStateOf(false) }
        var activePane by remember { mutableIntStateOf(0) }

        var leftStorageId by remember { mutableStateOf("phone") }
        var rightStorageId by remember { mutableStateOf("phone") }

        var leftPath by remember { mutableStateOf(Environment.getExternalStorageDirectory().absolutePath) }
        var rightPath by remember { mutableStateOf(Environment.getExternalStorageDirectory().absolutePath) }

        var leftSelected by remember { mutableStateOf(setOf<String>()) }
        var rightSelected by remember { mutableStateOf(setOf<String>()) }

        var searchOpen by remember { mutableStateOf(false) }
        var searchQuery by remember { mutableStateOf("") }

        var showVersionDialog by remember { mutableStateOf(false) }
        var showSettingsDialog by remember { mutableStateOf(false) }
        var showAddStorageDialog by remember { mutableStateOf(false) }
        var showNewFolderDialog by remember { mutableStateOf(false) }
        var showRenameDialog by remember { mutableStateOf<FileEntry?>(null) }
        var showCreateZipDialog by remember { mutableStateOf(false) }
        var viewerImageFile by remember { mutableStateOf<File?>(null) }
        var viewerImageGallery by remember { mutableStateOf<List<File>>(emptyList()) }
        var viewerExternalUri by remember {
            mutableStateOf<Uri?>(
                if (initialViewUri != null && (initialViewMime?.startsWith("image/") == true || isImageFileName(initialViewUri.toString()))) initialViewUri else null
            )
        }
        var zipViewerFile by remember { mutableStateOf<File?>(null) }
        var zipViewerUri by remember {
            mutableStateOf<Uri?>(
                if (initialViewUri != null && (initialViewMime?.contains("zip") == true || initialViewUri.toString().lowercase().endsWith(".zip"))) initialViewUri else null
            )
        }

        var refreshTick by remember { mutableIntStateOf(0) }
        var hasPermissionState by remember { mutableStateOf(false) }

        var leftPaneBounds by remember { mutableStateOf<Rect?>(null) }
        var rightPaneBounds by remember { mutableStateOf<Rect?>(null) }
        var draggingFromPane by remember { mutableStateOf<Int?>(null) }
        var draggingItems by remember { mutableStateOf<List<FileEntry>>(emptyList()) }
        var dragPointerRoot by remember { mutableStateOf(Offset.Zero) }
        var pendingDrop by remember { mutableStateOf<Triple<Int, Int, List<FileEntry>>?>(null) }

        fun hasStoragePermission(): Boolean {
            return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                Environment.isExternalStorageManager()
            } else {
                ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.READ_EXTERNAL_STORAGE
                ) == PackageManager.PERMISSION_GRANTED
            }
        }


        val lifecycleOwner = LocalLifecycleOwner.current
        DisposableEffect(lifecycleOwner) {
            hasPermissionState = hasStoragePermission()
            val observer = LifecycleEventObserver { _, event ->
                if (event == Lifecycle.Event.ON_RESUME) {
                    hasPermissionState = hasStoragePermission()
                    refreshTick++
                }
            }
            lifecycleOwner.lifecycle.addObserver(observer)
            onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
        }

        fun requestStoragePermission() {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION).apply {
                    data = Uri.parse("package:${context.packageName}")
                }
                context.startActivity(intent)
            } else {
                Toast.makeText(context, t.permissionTitle, Toast.LENGTH_SHORT).show()
            }
        }

        fun grantFileAccess() {
            if (hasStoragePermission()) {
                Toast.makeText(context, t.accessGrantedMsg, Toast.LENGTH_SHORT).show()
            } else {
                requestStoragePermission()
            }
        }

        val leftSource = allStorages.firstOrNull { it.id == leftStorageId } ?: allStorages.first()
        val rightSource = allStorages.firstOrNull { it.id == rightStorageId } ?: allStorages.first()
        val currentPaneStorageId = if (activePane == 0) leftStorageId else rightStorageId
        val currentSelection = if (activePane == 0) leftSelected else rightSelected

        val hoverTargetPane = when (draggingFromPane) {
            0 -> if (rightPaneBounds?.contains(dragPointerRoot) == true) 1 else null
            1 -> if (leftPaneBounds?.contains(dragPointerRoot) == true) 0 else null
            else -> null
        }

        Box(modifier = Modifier.fillMaxSize()) {
        Scaffold(
            bottomBar = {
                Column {
                    KomandirBottomBar(
                        strings = t,
                        selectedCount = currentSelection.size,
                    onCopy = {
                        if (!dualPane) {
                            Toast.makeText(context, t.needDualPaneMsg, Toast.LENGTH_SHORT).show()
                        } else if (currentSelection.isEmpty()) {
                            Toast.makeText(context, t.selectFirstMsg, Toast.LENGTH_SHORT).show()
                        } else {
                            val srcId = if (activePane == 0) leftStorageId else rightStorageId
                            val dstId = if (activePane == 0) rightStorageId else leftStorageId
                            val dstPath = if (activePane == 0) rightPath else leftPath
                            if (srcId == "phone" && dstId == "phone") {
                                scope.launch(Dispatchers.IO) {
                                    currentSelection.forEach { p ->
                                        val src = File(p)
                                        val dst = File(dstPath, src.name)
                                        if (src.isDirectory) src.copyRecursively(dst, overwrite = true)
                                        else src.copyTo(dst, overwrite = true)
                                    }
                                    withContext(Dispatchers.Main) {
                                        if (activePane == 0) leftSelected = emptySet() else rightSelected = emptySet()
                                        refreshTick++
                                    }
                                }
                            } else {
                                Toast.makeText(context, "Transfer queued: ${currentSelection.size}", Toast.LENGTH_SHORT).show()
                            }
                        }
                    },
                    onMove = {
                        if (!dualPane) {
                            Toast.makeText(context, t.needDualPaneMsg, Toast.LENGTH_SHORT).show()
                        } else if (currentSelection.isEmpty()) {
                            Toast.makeText(context, t.selectFirstMsg, Toast.LENGTH_SHORT).show()
                        } else {
                            val srcId = if (activePane == 0) leftStorageId else rightStorageId
                            val dstId = if (activePane == 0) rightStorageId else leftStorageId
                            val dstPath = if (activePane == 0) rightPath else leftPath
                            if (srcId == "phone" && dstId == "phone") {
                                scope.launch(Dispatchers.IO) {
                                    currentSelection.forEach { p ->
                                        val src = File(p)
                                        val dst = File(dstPath, src.name)
                                        src.renameTo(dst)
                                    }
                                    withContext(Dispatchers.Main) {
                                        if (activePane == 0) leftSelected = emptySet() else rightSelected = emptySet()
                                        refreshTick++
                                    }
                                }
                            } else {
                                Toast.makeText(context, "Move queued: ${currentSelection.size}", Toast.LENGTH_SHORT).show()
                            }
                        }
                    },
                    onNewFolder = { showNewFolderDialog = true },
                    onZip = {
                        if (currentSelection.isEmpty()) {
                            Toast.makeText(context, t.selectFirstMsg, Toast.LENGTH_SHORT).show()
                        } else if (currentPaneStorageId == "phone") {
                            showCreateZipDialog = true
                        }
                    },
                    onRename = {
                        val first = currentSelection.firstOrNull()
                        if (first == null) {
                            Toast.makeText(context, t.selectFirstMsg, Toast.LENGTH_SHORT).show()
                        } else {
                            val f = File(first)
                            showRenameDialog = FileEntry(first, f.name, first, f.isDirectory, f.length(), f.lastModified())
                        }
                    },
                    onDelete = {
                        if (currentSelection.isEmpty()) {
                            Toast.makeText(context, t.selectFirstMsg, Toast.LENGTH_SHORT).show()
                        } else if (currentPaneStorageId == "phone") {
                            scope.launch(Dispatchers.IO) {
                                currentSelection.forEach { p -> File(p).deleteRecursively() }
                                withContext(Dispatchers.Main) {
                                    if (activePane == 0) leftSelected = emptySet() else rightSelected = emptySet()
                                    refreshTick++
                                }
                            }
                        }
                    }
                )
                KomandirHeader(
                    dualPane = dualPane,
                    onVersionClick = { showVersionDialog = true },
                    onToggleDualPane = {
                        dualPane = !dualPane
                        if (!dualPane) activePane = 0
                    },
                    onToggleSearch = {
                        searchOpen = !searchOpen
                        if (!searchOpen) searchQuery = ""
                    },
                    onOpenSettings = { showSettingsDialog = true }
                )
                }
            }
        ) { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (isPickMode) {
                    Surface(
                        color = BrandBlue,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = t.pickModeBanner,
                                color = Color.White,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.weight(1f)
                            )
                            Text(
                                text = t.cancelBtn,
                                color = BrandYellow,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier
                                    .clickable { onCancelPick() }
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }
                if (searchOpen) {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        placeholder = { Text(t.searchHint, fontSize = 13.sp) },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    )
                }

                // Лента источников (Телефон, Google Диск, Веб-диски, Сеть LAN)
                Surface(
                    color = MaterialTheme.colorScheme.surface,
                    tonalElevation = 1.dp
                ) {
                    Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = t.storagesHeader.uppercase(),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = t.addDisk,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .clickable { showAddStorageDialog = true }
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(allStorages, key = { it.id }) { st ->
                                val selected = st.id == currentPaneStorageId
                                Surface(
                                    shape = RoundedCornerShape(10.dp),
                                    color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                                    border = BorderStroke(1.dp, if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant),
                                    modifier = Modifier.clickable {
                                        if (activePane == 0) {
                                            leftStorageId = st.id
                                            leftPath = st.rootPath
                                            leftSelected = emptySet()
                                        } else {
                                            rightStorageId = st.id
                                            rightPath = st.rootPath
                                            rightSelected = emptySet()
                                        }
                                    }
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(5.dp)
                                    ) {
                                        Icon(
                                            imageVector = when (st.kind) {
                                                StorageKind.LOCAL -> Icons.Default.PhoneAndroid
                                                StorageKind.SAF_CLOUD -> Icons.Default.Cloud
                                                StorageKind.WEBDAV -> Icons.Default.Language
                                                StorageKind.SMB, StorageKind.FTP -> Icons.Default.Computer
                                            },
                                            contentDescription = null,
                                            tint = if (selected) Color.White else MaterialTheme.colorScheme.onSurface,
                                            modifier = Modifier.size(15.dp)
                                        )
                                        Text(
                                            text = st.title,
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            color = if (selected) Color.White else MaterialTheme.colorScheme.onSurface
                                        )
                                        if (st.isCustom) {
                                            Icon(
                                                imageVector = Icons.Default.Close,
                                                contentDescription = "Remove",
                                                tint = if (selected) Color.White.copy(alpha = 0.85f) else MaterialTheme.colorScheme.onSurfaceVariant,
                                                modifier = Modifier
                                                    .size(14.dp)
                                                    .clickable {
                                                        KomandirPrefs.removeCustomStorage(context, st.id)
                                                        customStorages = KomandirPrefs.getCustomStorages(context)
                                                        if (leftStorageId == st.id) {
                                                            leftStorageId = "phone"
                                                            leftPath = Environment.getExternalStorageDirectory().absolutePath
                                                        }
                                                        if (rightStorageId == st.id) {
                                                            rightStorageId = "phone"
                                                            rightPath = Environment.getExternalStorageDirectory().absolutePath
                                                        }
                                                    }
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // Панели файлов (1 или 2)
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .padding(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilePaneView(
                        modifier = Modifier
                            .weight(1f)
                            .onGloballyPositioned { leftPaneBounds = it.boundsInRoot() },
                        source = leftSource,
                        currentPath = leftPath,
                        selectedIds = leftSelected,
                        isActive = !dualPane || activePane == 0,
                        isDropTarget = hoverTargetPane == 0,
                        dualPane = dualPane,
                        searchQuery = searchQuery,
                        hasPermission = hasPermissionState,
                        refreshTick = refreshTick,
                        strings = t,
                        onActivate = { activePane = 0 },
                        onRequestPermission = { requestStoragePermission() },
                        onDragStart = { items, startOffset ->
                            activePane = 0
                            draggingFromPane = 0
                            draggingItems = items
                            dragPointerRoot = startOffset
                        },
                        onDragMove = { delta ->
                            dragPointerRoot += delta
                        },
                        onDragEnd = {
                            val droppedInRight = rightPaneBounds?.contains(dragPointerRoot) == true
                            if (droppedInRight && draggingItems.isNotEmpty()) {
                                pendingDrop = Triple(0, 1, draggingItems)
                            }
                            draggingFromPane = null
                            draggingItems = emptyList()
                        },
                        onNavigate = { newPath ->
                            activePane = 0
                            leftPath = newPath
                            leftSelected = emptySet()
                        },
                        onToggleSelect = { id ->
                            activePane = 0
                            leftSelected = if (id in leftSelected) leftSelected - id else leftSelected + id
                        },
                        onOpenFile = { entry ->
                            if (leftSource.kind == StorageKind.LOCAL) {
                                val f = File(entry.path)
                                if (isPickMode) {
                                    onPickFile(f)
                                } else if (isImageFileName(entry.name)) {
                                    val siblings = f.parentFile?.listFiles()?.filter { !it.isDirectory && isImageFileName(it.name) }?.sortedBy { it.name.lowercase() } ?: listOf(f)
                                    viewerImageGallery = siblings
                                    viewerImageFile = f
                                } else if (isZipFileName(entry.name)) {
                                    zipViewerFile = f
                                } else {
                                    runCatching {
                                        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", f)
                                        val intent = Intent(Intent.ACTION_VIEW).apply {
                                            setDataAndType(uri, "*/*")
                                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                        }
                                        context.startActivity(intent)
                                    }
                                }
                            }
                        }
                    )

                    if (dualPane) {
                        FilePaneView(
                            modifier = Modifier
                                .weight(1f)
                                .onGloballyPositioned { rightPaneBounds = it.boundsInRoot() },
                            source = rightSource,
                            currentPath = rightPath,
                            selectedIds = rightSelected,
                            isActive = activePane == 1,
                            isDropTarget = hoverTargetPane == 1,
                            dualPane = dualPane,
                            searchQuery = searchQuery,
                            hasPermission = hasPermissionState,
                            refreshTick = refreshTick,
                            strings = t,
                            onActivate = { activePane = 1 },
                            onRequestPermission = { requestStoragePermission() },
                            onDragStart = { items, startOffset ->
                                activePane = 1
                                draggingFromPane = 1
                                draggingItems = items
                                dragPointerRoot = startOffset
                            },
                            onDragMove = { delta ->
                                dragPointerRoot += delta
                            },
                            onDragEnd = {
                                val droppedInLeft = leftPaneBounds?.contains(dragPointerRoot) == true
                                if (droppedInLeft && draggingItems.isNotEmpty()) {
                                    pendingDrop = Triple(1, 0, draggingItems)
                                }
                                draggingFromPane = null
                                draggingItems = emptyList()
                            },
                            onNavigate = { newPath ->
                                activePane = 1
                                rightPath = newPath
                                rightSelected = emptySet()
                            },
                            onToggleSelect = { id ->
                                activePane = 1
                                rightSelected = if (id in rightSelected) rightSelected - id else rightSelected + id
                            },
                            onOpenFile = { entry ->
                                if (rightSource.kind == StorageKind.LOCAL) {
                                val f = File(entry.path)
                                if (isPickMode) {
                                    onPickFile(f)
                                } else if (isImageFileName(entry.name)) {
                                    val siblings = f.parentFile?.listFiles()?.filter { !it.isDirectory && isImageFileName(it.name) }?.sortedBy { it.name.lowercase() } ?: listOf(f)
                                    viewerImageGallery = siblings
                                    viewerImageFile = f
                                } else if (isZipFileName(entry.name)) {
                                    zipViewerFile = f
                                } else {
                                    runCatching {
                                        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", f)
                                        val intent = Intent(Intent.ACTION_VIEW).apply {
                                            setDataAndType(uri, "*/*")
                                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                        }
                                        context.startActivity(intent)
                                    }
                                }
                                }
                            }
                        )
                    }
                }
            }
        }

        // Окно полной версии по тапу на "v.4 by mizgiroff"
        if (showVersionDialog) {
            AlertDialog(
                onDismissRequest = { showVersionDialog = false },
                title = { Text("Komandir · v.4 by mizgiroff", fontWeight = FontWeight.Bold) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("${t.versionFullLabel} v4_26.11.21 (код 4)", fontWeight = FontWeight.SemiBold)
                        Text("${t.versionAuthorLabel} mizgiroff")
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(t.versionDesc, fontSize = 13.sp)
                    }
                },
                confirmButton = {
                    Button(onClick = { showVersionDialog = false }) { Text(t.okBtn) }
                }
            )
        }

        // Окно настроек (Тема + Язык)
        if (showSettingsDialog) {
            AlertDialog(
                onDismissRequest = { showSettingsDialog = false },
                title = { Text(t.settingsTitle, fontWeight = FontWeight.Bold) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text(t.themeLabel, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf(
                                AppThemeMode.LIGHT to t.themeLight,
                                AppThemeMode.DARK to t.themeDark,
                                AppThemeMode.SYSTEM to t.themeSystem
                            ).forEach { (mode, label) ->
                                val active = themeMode == mode
                                OutlinedButton(
                                    onClick = {
                                        themeMode = mode
                                        KomandirPrefs.setTheme(context, mode)
                                    },
                                    modifier = Modifier.weight(1f),
                                    contentPadding = PaddingValues(horizontal = 4.dp, vertical = 6.dp),
                                    colors = ButtonDefaults.outlinedButtonColors(
                                        containerColor = if (active) MaterialTheme.colorScheme.primary else Color.Transparent,
                                        contentColor = if (active) Color.White else MaterialTheme.colorScheme.onSurface
                                    )
                                ) {
                                    Text(label, fontSize = 11.sp, maxLines = 1)
                                }
                            }
                        }

                        Text(t.langLabel, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            AppLang.entries.forEach { lang ->
                                val active = appLang == lang
                                OutlinedButton(
                                    onClick = {
                                        appLang = lang
                                        KomandirPrefs.setLang(context, lang)
                                    },
                                    modifier = Modifier.weight(1f),
                                    contentPadding = PaddingValues(horizontal = 4.dp, vertical = 6.dp),
                                    colors = ButtonDefaults.outlinedButtonColors(
                                        containerColor = if (active) MaterialTheme.colorScheme.primary else Color.Transparent,
                                        contentColor = if (active) Color.White else MaterialTheme.colorScheme.onSurface
                                    )
                                ) {
                                    Text(lang.label, fontSize = 11.sp, maxLines = 1)
                                }
                            }
                        }
                        OutlinedButton(
                            onClick = { grantFileAccess() },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(t.allowBtn, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }
                },
                confirmButton = {
                    Button(onClick = { showSettingsDialog = false }) { Text(t.done) }
                }
            )
        }

        // Первый запуск: выбор языка (как в Barvy)
        if (showLangPrompt) {
            AlertDialog(
                onDismissRequest = {},
                title = { Text(t.chooseLangTitle, fontWeight = FontWeight.Bold) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        AppLang.entries.forEach { lang ->
                            Button(
                                onClick = {
                                    appLang = lang
                                    KomandirPrefs.setLang(context, lang)
                                    showLangPrompt = false
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(lang.label)
                            }
                        }
                    }
                },
                confirmButton = {}
            )
        }

        // Пошаговый мастер подключения реальных дисков (Google Диск/SAF, WebDAV, SMB, FTP)
        if (showAddStorageDialog) {
            var step by remember { mutableIntStateOf(1) }
            var selectedPreset by remember { mutableStateOf("saf") }
            var newName by remember { mutableStateOf("") }
            var newHost by remember { mutableStateOf("") }
            var newShare by remember { mutableStateOf("") }
            var newLogin by remember { mutableStateOf("") }
            var newPass by remember { mutableStateOf("") }

            val safLauncher = rememberLauncherForActivityResult(
                contract = ActivityResultContracts.OpenDocumentTree()
            ) { treeUri ->
                if (treeUri != null) {
                    runCatching {
                        val flags = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                        context.contentResolver.takePersistableUriPermission(treeUri, flags)
                    }
                    val docName = androidx.documentfile.provider.DocumentFile.fromTreeUri(context, treeUri)?.name
                    val src = StorageSource(
                        id = "saf_${System.currentTimeMillis()}",
                        title = newName.ifBlank { docName ?: "Google Диск" },
                        kind = StorageKind.SAF_CLOUD,
                        rootPath = treeUri.toString(),
                        host = treeUri.toString(),
                        isCustom = true
                    )
                    KomandirPrefs.addCustomStorage(context, src)
                    customStorages = KomandirPrefs.getCustomStorages(context)
                    if (activePane == 0) {
                        leftStorageId = src.id
                        leftPath = src.rootPath
                        leftSelected = emptySet()
                    } else {
                        rightStorageId = src.id
                        rightPath = src.rootPath
                        rightSelected = emptySet()
                    }
                    showAddStorageDialog = false
                }
            }

            val presets = listOf(
                Triple("saf", "Google Диск / Облако (SAF)", StorageKind.SAF_CLOUD),
                Triple("webdav", "WebDAV (Nextcloud / Яндекс)", StorageKind.WEBDAV),
                Triple("smb", "Сеть LAN — SMB (Windows / NAS)", StorageKind.SMB),
                Triple("ftp", "FTP сервер (Роутер / NAS)", StorageKind.FTP)
            )

            AlertDialog(
                onDismissRequest = { showAddStorageDialog = false },
                title = {
                    Text(
                        text = if (step == 1) t.addStorageTitle else (presets.firstOrNull { it.first == selectedPreset }?.second ?: t.addStorageTitle),
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                },
                text = {
                    if (step == 1) {
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(t.wizardStep1, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            presets.forEach { (key, title, kind) ->
                                Surface(
                                    shape = RoundedCornerShape(10.dp),
                                    color = MaterialTheme.colorScheme.surfaceVariant,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            selectedPreset = key
                                            newName = when (key) {
                                                "saf" -> "Google Диск"
                                                "webdav" -> "WebDAV"
                                                "smb" -> "Home NAS"
                                                else -> "FTP"
                                            }
                                            newHost = when (key) {
                                                "webdav" -> "https://cloud.example.com/remote.php/dav/files/user/"
                                                "smb" -> "192.168.1.50"
                                                "ftp" -> "192.168.88.1:21"
                                                else -> ""
                                            }
                                            newShare = if (key == "smb") "Public" else ""
                                            step = 2
                                        }
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(title, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                                        Text(kind.badge, fontSize = 10.sp, color = MaterialTheme.colorScheme.primary)
                                    }
                                }
                            }
                        }
                    } else {
                        Column(
                            modifier = Modifier.verticalScroll(rememberScrollState()),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            val hintText = when (selectedPreset) {
                                "saf" -> t.safHint
                                "webdav" -> t.webdavHint
                                "smb" -> t.smbHint
                                else -> t.ftpHint
                            }
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = MaterialTheme.colorScheme.primary.copy(alpha = 0.1f)
                            ) {
                                Text(
                                    text = hintText,
                                    fontSize = 11.sp,
                                    lineHeight = 15.sp,
                                    modifier = Modifier.padding(8.dp)
                                )
                            }
                            OutlinedTextField(
                                value = newName,
                                onValueChange = { newName = it },
                                label = { Text(t.storageNameLabel) },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                            if (selectedPreset == "saf") {
                                Button(
                                    onClick = { safLauncher.launch(null) },
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text(t.safPickBtn)
                                }
                            } else {
                                OutlinedTextField(
                                    value = newHost,
                                    onValueChange = { newHost = it },
                                    label = { Text(t.storageHostLabel) },
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth()
                                )
                                if (selectedPreset == "smb") {
                                    OutlinedTextField(
                                        value = newShare,
                                        onValueChange = { newShare = it },
                                        label = { Text(t.shareLabel) },
                                        singleLine = true,
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                }
                                OutlinedTextField(
                                    value = newLogin,
                                    onValueChange = { newLogin = it },
                                    label = { Text(t.storageLoginLabel) },
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth()
                                )
                                OutlinedTextField(
                                    value = newPass,
                                    onValueChange = { newPass = it },
                                    label = { Text(t.storagePassLabel) },
                                    visualTransformation = PasswordVisualTransformation(),
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                        }
                    }
                },
                confirmButton = {
                    if (step == 2 && selectedPreset != "saf") {
                        Button(onClick = {
                            val kind = presets.firstOrNull { it.first == selectedPreset }?.third ?: StorageKind.SMB
                            val initialPath = when (kind) {
                                StorageKind.WEBDAV -> newHost.trim()
                                else -> "/"
                            }
                            val src = StorageSource(
                                id = "net_${System.currentTimeMillis()}",
                                title = newName.ifBlank { kind.badge },
                                kind = kind,
                                rootPath = initialPath,
                                host = newHost.trim(),
                                shareName = newShare.trim(),
                                username = newLogin.trim(),
                                password = newPass,
                                isCustom = true
                            )
                            KomandirPrefs.addCustomStorage(context, src)
                            customStorages = KomandirPrefs.getCustomStorages(context)
                            if (activePane == 0) {
                                leftStorageId = src.id
                                leftPath = src.rootPath
                                leftSelected = emptySet()
                            } else {
                                rightStorageId = src.id
                                rightPath = src.rootPath
                                rightSelected = emptySet()
                            }
                            showAddStorageDialog = false
                        }) {
                            Text(t.wizardConnect)
                        }
                    }
                },
                dismissButton = {
                    if (step == 2) {
                        TextButton(onClick = { step = 1 }) { Text(t.wizardBack) }
                    } else {
                        TextButton(onClick = { showAddStorageDialog = false }) { Text(t.cancelBtn) }
                    }
                }
            )
        }

        // Диалог при отпускании файла в другую панель (Копировать / Переместить)
        pendingDrop?.let { (srcPane, dstPane, items) ->
            val dstSource = if (dstPane == 0) leftSource else rightSource
            val srcId = if (srcPane == 0) leftStorageId else rightStorageId
            val dstId = if (dstPane == 0) leftStorageId else rightStorageId
            val dstPath = if (dstPane == 0) leftPath else rightPath
            AlertDialog(
                onDismissRequest = { pendingDrop = null },
                title = { Text(t.dropTitle, fontWeight = FontWeight.Bold) },
                text = { Text(t.dropMessage(items.size, dstSource.title)) },
                confirmButton = {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Button(onClick = {
                            if (srcId == "phone" && dstId == "phone") {
                                scope.launch(Dispatchers.IO) {
                                    items.forEach { entry ->
                                        val src = File(entry.path)
                                        val dst = File(dstPath, src.name)
                                        if (src.isDirectory) src.copyRecursively(dst, overwrite = true)
                                        else src.copyTo(dst, overwrite = true)
                                    }
                                    withContext(Dispatchers.Main) {
                                        if (srcPane == 0) leftSelected = emptySet() else rightSelected = emptySet()
                                        refreshTick++
                                    }
                                }
                            } else {
                                Toast.makeText(context, "Copy queued: ${items.size}", Toast.LENGTH_SHORT).show()
                            }
                            pendingDrop = null
                        }) {
                            Text(t.actCopy)
                        }
                        OutlinedButton(onClick = {
                            if (srcId == "phone" && dstId == "phone") {
                                scope.launch(Dispatchers.IO) {
                                    items.forEach { entry ->
                                        val src = File(entry.path)
                                        val dst = File(dstPath, src.name)
                                        if (!src.renameTo(dst)) {
                                            if (src.isDirectory) src.copyRecursively(dst, overwrite = true)
                                            else src.copyTo(dst, overwrite = true)
                                            src.deleteRecursively()
                                        }
                                    }
                                    withContext(Dispatchers.Main) {
                                        if (srcPane == 0) leftSelected = emptySet() else rightSelected = emptySet()
                                        refreshTick++
                                    }
                                }
                            } else {
                                Toast.makeText(context, "Move queued: ${items.size}", Toast.LENGTH_SHORT).show()
                            }
                            pendingDrop = null
                        }) {
                            Text(t.actMove)
                        }
                    }
                },
                dismissButton = {
                    TextButton(onClick = { pendingDrop = null }) { Text(t.cancelBtn) }
                }
            )
        }

        // Переименование
        showRenameDialog?.let { entry ->
            var newName by remember { mutableStateOf(entry.name) }
            AlertDialog(
                onDismissRequest = { showRenameDialog = null },
                title = { Text(t.renameTitle) },
                text = {
                    OutlinedTextField(
                        value = newName,
                        onValueChange = { newName = it },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                },
                confirmButton = {
                    Button(onClick = {
                        if (currentPaneStorageId == "phone" && newName.isNotBlank()) {
                            val src = File(entry.path)
                            src.renameTo(File(src.parentFile, newName.trim()))
                            if (activePane == 0) leftSelected = emptySet() else rightSelected = emptySet()
                            refreshTick++
                        }
                        showRenameDialog = null
                    }) { Text(t.okBtn) }
                },
                dismissButton = {
                    TextButton(onClick = { showRenameDialog = null }) { Text(t.cancelBtn) }
                }
            )
        }

        // Создание ZIP-архива
        if (showCreateZipDialog) {
            var zipName by remember { mutableStateOf("archive.zip") }
            AlertDialog(
                onDismissRequest = { showCreateZipDialog = false },
                title = { Text(t.zipCreateTitle, fontWeight = FontWeight.Bold) },
                text = {
                    OutlinedTextField(
                        value = zipName,
                        onValueChange = { zipName = it },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                },
                confirmButton = {
                    Button(onClick = {
                        val finalName = if (zipName.lowercase().endsWith(".zip")) zipName.trim() else "${zipName.trim()}.zip"
                        val targetDir = File(if (activePane == 0) leftPath else rightPath)
                        val sources = currentSelection.map { File(it) }
                        scope.launch(Dispatchers.IO) {
                            createZipArchive(sources, File(targetDir, finalName))
                            withContext(Dispatchers.Main) {
                                if (activePane == 0) leftSelected = emptySet() else rightSelected = emptySet()
                                refreshTick++
                                Toast.makeText(context, t.zipDoneMsg(finalName), Toast.LENGTH_SHORT).show()
                            }
                        }
                        showCreateZipDialog = false
                    }) { Text(t.okBtn) }
                },
                dismissButton = {
                    TextButton(onClick = { showCreateZipDialog = false }) { Text(t.cancelBtn) }
                }
            )
        }

        // Просмотрщик и распаковщик ZIP-архивов
        if (zipViewerFile != null || zipViewerUri != null) {
            var zipEntries by remember { mutableStateOf<List<ZipItemInfo>>(emptyList()) }
            LaunchedEffect(zipViewerFile, zipViewerUri) {
                zipEntries = withContext(Dispatchers.IO) {
                    when {
                        zipViewerFile != null -> runCatching { listZipEntries(zipViewerFile!!) }.getOrDefault(emptyList())
                        zipViewerUri != null -> runCatching { listZipEntriesFromUri(context, zipViewerUri!!) }.getOrDefault(emptyList())
                        else -> emptyList()
                    }
                }
            }
            AlertDialog(
                onDismissRequest = { zipViewerFile = null; zipViewerUri = null },
                title = { Text(zipViewerFile?.name ?: t.zipTitle, fontWeight = FontWeight.Bold, fontSize = 15.sp) },
                text = {
                    LazyColumn(modifier = Modifier.heightIn(max = 360.dp)) {
                        items(zipEntries) { ze ->
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(ze.name, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                                if (!ze.isDirectory) {
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(formatFileSize(ze.sizeBytes), fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                            HorizontalDivider(thickness = 0.5.dp)
                        }
                    }
                },
                confirmButton = {
                    Button(onClick = {
                        val destBase = File(if (activePane == 0) leftPath else rightPath)
                        val folderName = (zipViewerFile?.nameWithoutExtension ?: "Extracted")
                        val destDir = File(destBase, folderName)
                        val fRef = zipViewerFile
                        val uRef = zipViewerUri
                        scope.launch(Dispatchers.IO) {
                            val count = when {
                                fRef != null -> extractZipFile(fRef, destDir)
                                uRef != null -> extractZipFromUri(context, uRef, destDir)
                                else -> 0
                            }
                            withContext(Dispatchers.Main) {
                                refreshTick++
                                Toast.makeText(context, t.unzipDoneMsg(count), Toast.LENGTH_SHORT).show()
                            }
                        }
                        zipViewerFile = null
                        zipViewerUri = null
                    }) { Text(t.zipExtractBtn) }
                },
                dismissButton = {
                    TextButton(onClick = { zipViewerFile = null; zipViewerUri = null }) { Text(t.cancelBtn) }
                }
            )
        }

        // Полноэкранный просмотрщик фото с зумом и листанием
        if (viewerImageFile != null || viewerExternalUri != null) {
            var scale by remember { mutableStateOf(1f) }
            var offset by remember { mutableStateOf(Offset.Zero) }
            val bitmap = remember(viewerImageFile, viewerExternalUri) {
                scale = 1f
                offset = Offset.Zero
                when {
                    viewerImageFile != null -> decodeSampledBitmap(viewerImageFile!!)
                    viewerExternalUri != null -> decodeSampledBitmapFromUri(context, viewerExternalUri!!)
                    else -> null
                }
            }
            val currentIdx = viewerImageFile?.let { f -> viewerImageGallery.indexOfFirst { it.absolutePath == f.absolutePath } } ?: -1

            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black)
                    .pointerInput(viewerImageFile, viewerExternalUri) {
                        detectTransformGestures { _, pan, zoom, _ ->
                            scale = (scale * zoom).coerceIn(1f, 5f)
                            if (scale > 1f) {
                                offset += pan
                            } else {
                                offset = Offset.Zero
                            }
                        }
                    }
            ) {
                if (bitmap != null) {
                    Image(
                        bitmap = bitmap.asImageBitmap(),
                        contentDescription = viewerImageFile?.name,
                        contentScale = ContentScale.Fit,
                        modifier = Modifier
                            .fillMaxSize()
                            .graphicsLayer(
                                scaleX = scale,
                                scaleY = scale,
                                translationX = offset.x,
                                translationY = offset.y
                            )
                    )
                }
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.TopCenter)
                        .background(Color.Black.copy(alpha = 0.55f))
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = viewerImageFile?.name ?: "Photo",
                        color = Color.White,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    IconButton(onClick = { viewerImageFile = null; viewerExternalUri = null }) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White)
                    }
                }
                if (viewerImageGallery.size > 1 && currentIdx >= 0) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .align(Alignment.BottomCenter)
                            .background(Color.Black.copy(alpha = 0.55f))
                            .padding(horizontal = 16.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            enabled = currentIdx > 0,
                            onClick = { if (currentIdx > 0) viewerImageFile = viewerImageGallery[currentIdx - 1] }
                        ) {
                            Icon(Icons.Default.ArrowBack, contentDescription = "Prev", tint = if (currentIdx > 0) Color.White else Color.Gray)
                        }
                        Text("${currentIdx + 1} / ${viewerImageGallery.size}", color = Color.White, fontSize = 12.sp)
                        IconButton(
                            enabled = currentIdx < viewerImageGallery.lastIndex,
                            onClick = { if (currentIdx < viewerImageGallery.lastIndex) viewerImageFile = viewerImageGallery[currentIdx + 1] }
                        ) {
                            Icon(Icons.Default.ArrowForward, contentDescription = "Next", tint = if (currentIdx < viewerImageGallery.lastIndex) Color.White else Color.Gray)
                        }
                    }
                }
            }
        }

        if (draggingFromPane != null && draggingItems.isNotEmpty()) {
            val label = if (draggingItems.size == 1) draggingItems.first().name else "${draggingItems.size} items"
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = BrandBlue,
                shadowElevation = 8.dp,
                modifier = Modifier.offset {
                    IntOffset(
                        (dragPointerRoot.x - 80f).roundToInt(),
                        (dragPointerRoot.y - 60f).roundToInt()
                    )
                }
            ) {
                Text(
                    text = label,
                    color = Color.White,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                )
            }
        }
        }
    }
}

@Composable
private fun KomandirHeader(
    dualPane: Boolean,
    onVersionClick: () -> Unit,
    onToggleDualPane: () -> Unit,
    onToggleSearch: () -> Unit,
    onOpenSettings: () -> Unit
) {
    // Сине-жёлтая переливающаяся заливка (как в MedAssist)
    val baseTextColor = MaterialTheme.colorScheme.onSurface
    val transition = rememberInfiniteTransition(label = "medAssistShimmer")
    val shift by transition.animateFloat(
        initialValue = -300f,
        targetValue = 900f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 12000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "shift"
    )
    val shimmerBrush = Brush.linearGradient(
        colors = listOf(baseTextColor, baseTextColor, BrandBlue, BrandYellow, BrandBlue, baseTextColor, baseTextColor),
        start = Offset(shift - 220f, 0f),
        end = Offset(shift + 120f, 80f)
    )
    val logoBrush = Brush.linearGradient(
        colors = listOf(BrandBlue, BrandBlue, BrandYellow, BrandBlue),
        start = Offset(shift - 220f, 0f),
        end = Offset(shift + 120f, 80f)
    )

    Surface(
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 2.dp
    ) {
        Column {
            HorizontalDivider(thickness = 0.5.dp)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(24.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(logoBrush),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.ViewColumn,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(15.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "Komandir",
                            style = TextStyle(
                                brush = shimmerBrush,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold
                            )
                        )
                        Spacer(modifier = Modifier.width(3.dp))
                        Text(
                            text = "v4 by mizgiroff",
                            style = TextStyle(
                                brush = shimmerBrush,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Medium
                            ),
                            maxLines = 1,
                            modifier = Modifier
                                .offset(y = (-5).dp)
                                .clickable { onVersionClick() }
                        )
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onToggleDualPane, modifier = Modifier.size(34.dp)) {
                        Icon(
                            imageVector = Icons.Default.ViewColumn,
                            contentDescription = "Dual Pane",
                            modifier = Modifier.size(20.dp),
                            tint = if (dualPane) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                        )
                    }
                    IconButton(onClick = onToggleSearch, modifier = Modifier.size(34.dp)) {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = "Search",
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    IconButton(onClick = onOpenSettings, modifier = Modifier.size(34.dp)) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = "Settings",
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun FilePaneView(
    modifier: Modifier,
    source: StorageSource,
    currentPath: String,
    selectedIds: Set<String>,
    isActive: Boolean,
    isDropTarget: Boolean,
    dualPane: Boolean,
    searchQuery: String,
    hasPermission: Boolean,
    refreshTick: Int,
    strings: UiStrings,
    onActivate: () -> Unit,
    onRequestPermission: () -> Unit,
    onDragStart: (List<FileEntry>, Offset) -> Unit,
    onDragMove: (Offset) -> Unit,
    onDragEnd: () -> Unit,
    onNavigate: (String) -> Unit,
    onToggleSelect: (String) -> Unit,
    onOpenFile: (FileEntry) -> Unit
) {
    val context = LocalContext.current
    var entries by remember { mutableStateOf<List<FileEntry>>(emptyList()) }
    var loadError by remember { mutableStateOf<String?>(null) }
    var isLoading by remember { mutableStateOf(false) }
    var pathHistory by remember(source.id) { mutableStateOf<List<String>>(emptyList()) }
    val currentOnDragStart by rememberUpdatedState(onDragStart)
    val currentOnDragMove by rememberUpdatedState(onDragMove)
    val currentOnDragEnd by rememberUpdatedState(onDragEnd)
    val currentOnNavigate by rememberUpdatedState(onNavigate)

    val canNavigateBack = (source.kind == StorageKind.LOCAL && currentPath != source.rootPath && File(currentPath).parentFile != null) || pathHistory.isNotEmpty()
    if (isActive) {
        BackHandler(enabled = canNavigateBack) {
            if (pathHistory.isNotEmpty()) {
                val prev = pathHistory.last()
                pathHistory = pathHistory.dropLast(1)
                currentOnNavigate(prev)
            } else if (source.kind == StorageKind.LOCAL) {
                File(currentPath).parentFile?.absolutePath?.let(currentOnNavigate)
            }
        }
    }

    LaunchedEffect(source.id, currentPath, refreshTick, hasPermission) {
        isLoading = true
        loadError = null
        val res = withContext(Dispatchers.IO) {
            when (source.kind) {
                StorageKind.LOCAL -> {
                    if (!hasPermission) DirResult()
                    else DirResult(entries = listLocalDirectory(File(currentPath)))
                }
                StorageKind.SAF_CLOUD -> listSafDirectory(context, currentPath)
                StorageKind.WEBDAV -> listWebDavDirectory(source, currentPath)
                StorageKind.SMB -> listSmbDirectory(source, currentPath)
                StorageKind.FTP -> listFtpDirectory(source, currentPath)
            }
        }
        entries = res.entries
        loadError = res.error
        isLoading = false
    }

    val filtered = remember(entries, searchQuery) {
        if (searchQuery.isBlank()) entries
        else entries.filter { it.name.contains(searchQuery, ignoreCase = true) }
    }

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .clickable { onActivate() },
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(
            width = if (isDropTarget) 2.5.dp else if (isActive) 1.5.dp else 1.dp,
            color = when {
                isDropTarget -> BrandYellow
                isActive -> MaterialTheme.colorScheme.primary
                else -> MaterialTheme.colorScheme.outlineVariant
            }
        )
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "${source.title}: $currentPath",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = source.kind.badge,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
            }

            if (source.kind == StorageKind.LOCAL && !hasPermission) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(strings.permissionTitle, fontSize = 13.sp)
                        Spacer(modifier = Modifier.height(10.dp))
                        Button(onClick = onRequestPermission) {
                            Text(strings.permissionBtn)
                        }
                    }
                }
            } else if (isLoading) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        CircularProgressIndicator(modifier = Modifier.size(28.dp))
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(strings.loadingMsg, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            } else if (loadError != null) {
                Box(modifier = Modifier.fillMaxSize().padding(16.dp), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(loadError ?: "Error", fontSize = 12.sp, color = MaterialTheme.colorScheme.error)
                        if (pathHistory.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(8.dp))
                            OutlinedButton(onClick = {
                                val prev = pathHistory.last()
                                pathHistory = pathHistory.dropLast(1)
                                onNavigate(prev)
                            }) { Text(strings.upDir) }
                        }
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .pointerInput(source.id, currentPath, pathHistory) {
                            var totalX = 0f
                            detectHorizontalDragGestures(
                                onDragStart = { totalX = 0f },
                                onHorizontalDrag = { _, dragAmount -> totalX += dragAmount },
                                onDragEnd = {
                                    if (totalX < -100f && canNavigateBack) {
                                        if (pathHistory.isNotEmpty()) {
                                            val prev = pathHistory.last()
                                            pathHistory = pathHistory.dropLast(1)
                                            currentOnNavigate(prev)
                                        } else if (source.kind == StorageKind.LOCAL) {
                                            File(currentPath).parentFile?.absolutePath?.let(currentOnNavigate)
                                        }
                                    }
                                }
                            )
                        }
                ) {
                    val canGoUp = (source.kind == StorageKind.LOCAL && currentPath != source.rootPath && File(currentPath).parentFile != null) || pathHistory.isNotEmpty()
                    if (canGoUp) {
                        item(key = "up_dir") {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        if (pathHistory.isNotEmpty()) {
                                            val prev = pathHistory.last()
                                            pathHistory = pathHistory.dropLast(1)
                                            onNavigate(prev)
                                        } else {
                                            File(currentPath).parentFile?.absolutePath?.let(onNavigate)
                                        }
                                    }
                                    .padding(horizontal = 10.dp, vertical = 5.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.Folder, contentDescription = null, tint = BrandYellow)
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(strings.upDir, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                            }
                            HorizontalDivider(thickness = 0.5.dp)
                        }
                    }

                    if (filtered.isEmpty()) {
                        item(key = "empty") {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(24.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(strings.emptyDir, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    } else {
                        items(filtered, key = { it.id }) { item ->
                            val isSel = item.id in selectedIds
                            var rowBounds by remember(item.id) { mutableStateOf<Rect?>(null) }
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .onGloballyPositioned { rowBounds = it.boundsInRoot() }
                                    .pointerInput(dualPane, item.id, selectedIds, filtered) {
                                        if (!dualPane) return@pointerInput
                                        detectDragGesturesAfterLongPress(
                                            onDragStart = { localOffset ->
                                                val rootTopLeft = rowBounds?.topLeft ?: Offset.Zero
                                                val itemsToDrag = if (isSel) {
                                                    filtered.filter { it.id in selectedIds }
                                                } else {
                                                    listOf(item)
                                                }
                                                currentOnDragStart(itemsToDrag, rootTopLeft + localOffset)
                                            },
                                            onDrag = { change, dragAmount ->
                                                change.consume()
                                                currentOnDragMove(dragAmount)
                                            },
                                            onDragEnd = { currentOnDragEnd() },
                                            onDragCancel = { currentOnDragEnd() }
                                        )
                                    }
                                    .background(if (isSel) MaterialTheme.colorScheme.primary.copy(alpha = 0.12f) else Color.Transparent)
                                    .clickable {
                                        if (item.isDirectory) {
                                            pathHistory = pathHistory + currentPath
                                            onNavigate(item.path)
                                        } else {
                                            onOpenFile(item)
                                        }
                                    }
                                    .padding(horizontal = 8.dp, vertical = 3.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(18.dp)
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(if (isSel) MaterialTheme.colorScheme.primary else Color.Transparent)
                                        .clickable { onToggleSelect(item.id) },
                                    contentAlignment = Alignment.Center
                                ) {
                                    if (isSel) {
                                        Icon(
                                            imageVector = Icons.Default.Check,
                                            contentDescription = null,
                                            tint = Color.White,
                                            modifier = Modifier.size(13.dp)
                                        )
                                    } else {
                                        Surface(
                                            modifier = Modifier.fillMaxSize(),
                                            shape = RoundedCornerShape(4.dp),
                                            color = Color.Transparent,
                                            border = BorderStroke(1.2.dp, MaterialTheme.colorScheme.outline)
                                        ) {}
                                    }
                                }
                                Spacer(modifier = Modifier.width(7.dp))
                                Icon(
                                    imageVector = if (item.isDirectory) Icons.Default.Folder else Icons.Default.InsertDriveFile,
                                    contentDescription = null,
                                    tint = if (item.isDirectory) Color(0xFFEAB308) else MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(7.dp))
                                Row(
                                    modifier = Modifier.weight(1f),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = item.name,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Medium,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        modifier = Modifier.weight(1f)
                                    )
                                    if (item.subtitle.isNotBlank()) {
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = item.subtitle,
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            maxLines = 1
                                        )
                                    }
                                }
                            }
                            HorizontalDivider(thickness = 0.5.dp)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun KomandirBottomBar(
    strings: UiStrings,
    selectedCount: Int,
    onCopy: () -> Unit,
    onMove: () -> Unit,
    onNewFolder: () -> Unit,
    onZip: () -> Unit,
    onRename: () -> Unit,
    onDelete: () -> Unit
) {
    Surface(
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 3.dp
    ) {
        Column(modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)) {
            Text(
                text = if (selectedCount > 0) strings.selectedCount(selectedCount) else strings.nothingSelected,
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                ActionChip(Modifier.weight(1f), Icons.Default.ContentCopy, strings.actCopy, onCopy)
                ActionChip(Modifier.weight(1f), Icons.Default.DriveFileMove, strings.actMove, onMove)
                ActionChip(Modifier.weight(1f), Icons.Default.CreateNewFolder, strings.actNewFolder, onNewFolder)
                ActionChip(Modifier.weight(1f), Icons.Default.Archive, strings.actZip, onZip)
                ActionChip(Modifier.weight(1f), Icons.Default.Edit, strings.actRename, onRename)
                ActionChip(Modifier.weight(1f), Icons.Default.Delete, strings.actDelete, onDelete, isDanger = true)
            }
        }
    }
}

@Composable
private fun ActionChip(
    modifier: Modifier,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    onClick: () -> Unit,
    isDanger: Boolean = false
) {
    Surface(
        modifier = modifier
            .heightIn(min = 44.dp)
            .clip(RoundedCornerShape(10.dp))
            .clickable { onClick() },
        shape = RoundedCornerShape(10.dp),
        color = MaterialTheme.colorScheme.surfaceVariant
    ) {
        Column(
            modifier = Modifier.padding(vertical = 6.dp, horizontal = 2.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = if (isDanger) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = label,
                fontSize = 10.sp,
                fontWeight = FontWeight.Medium,
                color = if (isDanger) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface,
                maxLines = 1
            )
        }
    }
}
