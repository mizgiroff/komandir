package com.mizgiroff.komandir

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlin.math.abs

enum class SyncMode {
    ONE_WAY_LR,
    ONE_WAY_RL,
    TWO_WAY,
    MIRROR_LR
}

enum class SyncItemStatus {
    ONLY_LEFT,
    ONLY_RIGHT,
    LEFT_NEWER,
    RIGHT_NEWER,
    DIFF_SIZE,
    SAME
}

data class SyncDiffItem(
    val name: String,
    val left: FileEntry?,
    val right: FileEntry?,
    val status: SyncItemStatus
)

fun computeSyncDiff(
    leftEntries: List<FileEntry>,
    rightEntries: List<FileEntry>,
    skipSameSize: Boolean = true
): List<SyncDiffItem> {
    val leftMap = leftEntries.associateBy { it.name }
    val rightMap = rightEntries.associateBy { it.name }
    val allNames = (leftMap.keys + rightMap.keys).distinct().sortedBy { it.lowercase() }
    val result = mutableListOf<SyncDiffItem>()
    for (name in allNames) {
        val l = leftMap[name]
        val r = rightMap[name]
        when {
            l != null && r == null -> result.add(SyncDiffItem(name, l, null, SyncItemStatus.ONLY_LEFT))
            l == null && r != null -> result.add(SyncDiffItem(name, null, r, SyncItemStatus.ONLY_RIGHT))
            l != null && r != null -> {
                if (l.isDirectory && r.isDirectory) {
                    result.add(SyncDiffItem(name, l, r, SyncItemStatus.SAME))
                } else if (l.sizeBytes == r.sizeBytes && (skipSameSize || l.lastModified == 0L || r.lastModified == 0L || abs(l.lastModified - r.lastModified) <= 2000L)) {
                    result.add(SyncDiffItem(name, l, r, SyncItemStatus.SAME))
                } else if (l.lastModified > 0L && r.lastModified > 0L && l.lastModified > r.lastModified + 2000L) {
                    result.add(SyncDiffItem(name, l, r, SyncItemStatus.LEFT_NEWER))
                } else if (l.lastModified > 0L && r.lastModified > 0L && r.lastModified > l.lastModified + 2000L) {
                    result.add(SyncDiffItem(name, l, r, SyncItemStatus.RIGHT_NEWER))
                } else {
                    result.add(SyncDiffItem(name, l, r, SyncItemStatus.DIFF_SIZE))
                }
            }
        }
    }
    return result
}

@Composable
internal fun FolderSyncDialog(
    leftSource: StorageSource,
    rightSource: StorageSource,
    leftPath: String,
    rightPath: String,
    leftEntries: List<FileEntry>,
    rightEntries: List<FileEntry>,
    strings: UiStrings,
    onDismiss: () -> Unit,
    onSaveRule: ((SyncMode) -> Unit)? = null,
    onRunSync: (mode: SyncMode, copyLR: List<FileEntry>, copyRL: List<FileEntry>, deleteR: List<FileEntry>) -> Unit
) {
    var mode by remember { mutableStateOf(SyncMode.ONE_WAY_LR) }
    var skipSameSize by remember { mutableStateOf(true) }
    val diffItems = remember(leftEntries, rightEntries, skipSameSize) {
        computeSyncDiff(leftEntries, rightEntries, skipSameSize)
    }

    val copyLR = remember(diffItems, mode) {
        diffItems.mapNotNull { d ->
            when (mode) {
                SyncMode.ONE_WAY_LR, SyncMode.MIRROR_LR, SyncMode.TWO_WAY -> when (d.status) {
                    SyncItemStatus.ONLY_LEFT, SyncItemStatus.LEFT_NEWER, SyncItemStatus.DIFF_SIZE -> d.left
                    else -> null
                }
                SyncMode.ONE_WAY_RL -> null
            }
        }
    }
    val copyRL = remember(diffItems, mode) {
        when (mode) {
            SyncMode.TWO_WAY -> diffItems.mapNotNull { d ->
                when (d.status) {
                    SyncItemStatus.ONLY_RIGHT, SyncItemStatus.RIGHT_NEWER -> d.right
                    else -> null
                }
            }
            SyncMode.ONE_WAY_RL -> diffItems.mapNotNull { d ->
                when (d.status) {
                    SyncItemStatus.ONLY_RIGHT, SyncItemStatus.RIGHT_NEWER, SyncItemStatus.DIFF_SIZE -> d.right
                    else -> null
                }
            }
            else -> emptyList()
        }
    }
    val deleteR = remember(diffItems, mode) {
        if (mode == SyncMode.MIRROR_LR) {
            diffItems.mapNotNull { d ->
                if (d.status == SyncItemStatus.ONLY_RIGHT) d.right else null
            }
        } else emptyList()
    }

    val sameCount = diffItems.count { it.status == SyncItemStatus.SAME }
    val newCount = diffItems.count {
        (mode != SyncMode.ONE_WAY_RL && it.status == SyncItemStatus.ONLY_LEFT) ||
            ((mode == SyncMode.TWO_WAY || mode == SyncMode.ONE_WAY_RL) && it.status == SyncItemStatus.ONLY_RIGHT)
    }
    val updateCount = diffItems.count {
        (mode != SyncMode.ONE_WAY_RL && it.status == SyncItemStatus.LEFT_NEWER) ||
            it.status == SyncItemStatus.DIFF_SIZE ||
            ((mode == SyncMode.TWO_WAY || mode == SyncMode.ONE_WAY_RL) && it.status == SyncItemStatus.RIGHT_NEWER)
    }
    val visibleDiff = remember(diffItems) {
        diffItems.filter { it.status != SyncItemStatus.SAME }
    }
    val hasActions = copyLR.isNotEmpty() || copyRL.isNotEmpty() || deleteR.isNotEmpty()

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = MaterialTheme.colorScheme.surface
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .systemBarsPadding()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(strings.syncTitle, fontWeight = FontWeight.Bold, fontSize = 19.sp)
                    TextButton(onClick = onDismiss) {
                        Text(strings.cancelBtn, fontSize = 14.sp)
                    }
                }
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(
                            text = "${leftSource.title}: $leftPath",
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurface,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = "↔ ${rightSource.title}: $rightPath",
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(
                        listOf(SyncMode.ONE_WAY_LR to strings.syncModeOneWay, SyncMode.ONE_WAY_RL to strings.syncModeOneWayRL),
                        listOf(SyncMode.TWO_WAY to strings.syncModeTwoWay, SyncMode.MIRROR_LR to strings.syncModeMirror)
                    ).forEach { pair ->
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            pair.forEach { (m, label) ->
                                val active = mode == m
                                OutlinedButton(
                                    onClick = { mode = m },
                                    modifier = Modifier.weight(1f),
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 8.dp),
                                    colors = ButtonDefaults.outlinedButtonColors(
                                        containerColor = if (active) MaterialTheme.colorScheme.primary else Color.Transparent,
                                        contentColor = if (active) Color.White else MaterialTheme.colorScheme.onSurface
                                    )
                                ) {
                                    Text(label, fontSize = 13.sp, maxLines = 1)
                                }
                            }
                        }
                    }
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = strings.syncSummaryMsg(newCount, updateCount, sameCount),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.weight(1f)
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(
                            checked = skipSameSize,
                            onCheckedChange = { skipSameSize = it },
                            modifier = Modifier.size(32.dp)
                        )
                        Text(
                            text = strings.skipSameSizeLabel,
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                if (mode == SyncMode.MIRROR_LR && deleteR.isNotEmpty()) {
                    Surface(
                        color = MaterialTheme.colorScheme.errorContainer,
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = strings.syncMirrorWarn,
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onErrorContainer,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        )
                    }
                }
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(10.dp))
                ) {
                    if (visibleDiff.isEmpty()) {
                        Box(modifier = Modifier.fillMaxSize().padding(20.dp), contentAlignment = Alignment.Center) {
                            Text(strings.syncNoDiffMsg, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFF2E7D32))
                        }
                    } else {
                        LazyColumn(modifier = Modifier.fillMaxSize()) {
                            items(visibleDiff, key = { it.name }) { item ->
                                val (badge, badgeColor) = when (item.status) {
                                    SyncItemStatus.ONLY_LEFT -> (if (mode == SyncMode.ONE_WAY_RL) "·" else "+") to Color(0xFF2E7D32)
                                    SyncItemStatus.ONLY_RIGHT -> when (mode) {
                                        SyncMode.MIRROR_LR -> "✕" to MaterialTheme.colorScheme.error
                                        SyncMode.TWO_WAY, SyncMode.ONE_WAY_RL -> "+←" to Color(0xFF1565C0)
                                        SyncMode.ONE_WAY_LR -> "·" to Color.Gray
                                        else -> "·" to Color.Gray
                                    }
                                    SyncItemStatus.LEFT_NEWER -> (if (mode == SyncMode.ONE_WAY_RL) "·" else "→") to Color(0xFF1565C0)
                                    SyncItemStatus.RIGHT_NEWER -> (if (mode == SyncMode.TWO_WAY || mode == SyncMode.ONE_WAY_RL) "←" else "·") to Color(0xFF1565C0)
                                    SyncItemStatus.DIFF_SIZE -> "≠" to Color(0xFFEF6C00)
                                    SyncItemStatus.SAME -> "=" to Color.Gray
                                }
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 10.dp, vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .width(30.dp)
                                            .clip(RoundedCornerShape(6.dp))
                                            .background(badgeColor.copy(alpha = 0.15f))
                                            .padding(vertical = 4.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(badge, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = badgeColor)
                                    }
                                    Spacer(Modifier.width(10.dp))
                                    Text(
                                        text = item.name,
                                        fontSize = 14.sp,
                                        lineHeight = 18.sp,
                                        maxLines = 2,
                                        overflow = TextOverflow.Ellipsis,
                                        modifier = Modifier.weight(1f)
                                    )
                                    Spacer(Modifier.width(8.dp))
                                    val sizeTxt = (item.left ?: item.right)?.let {
                                        if (it.isDirectory) "dir" else formatFileSize(it.sizeBytes)
                                    } ?: ""
                                    Text(sizeTxt, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                HorizontalDivider(thickness = 0.5.dp)
                            }
                        }
                    }
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (onSaveRule != null) {
                        OutlinedButton(
                            onClick = { onSaveRule(mode) },
                            modifier = Modifier.weight(1f),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 10.dp)
                        ) {
                            Text(strings.saveSyncRuleBtn, fontSize = 13.sp, maxLines = 1)
                        }
                    }
                    Button(
                        enabled = hasActions,
                        onClick = { onRunSync(mode, copyLR, copyRL, deleteR) },
                        modifier = Modifier.weight(1f),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 10.dp)
                    ) {
                        Text(strings.syncBtn, fontSize = 13.sp, maxLines = 1)
                    }
                }
            }
        }
    }
}


@Composable
internal fun SyncProfilesDialog(
    profiles: List<SyncProfile>,
    strings: UiStrings,
    onUpdateProfiles: (List<SyncProfile>) -> Unit,
    onRunNow: (SyncProfile) -> Unit,
    onDismiss: () -> Unit
) {
    val intervals = listOf(0, 15, 60, 360, 1440)
    fun intervalLabel(mins: Int): String = when (mins) {
        0 -> strings.manualIntervalLabel
        15 -> "15m"
        60 -> "1h"
        360 -> "6h"
        1440 -> "24h"
        else -> "${mins}m"
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = MaterialTheme.colorScheme.background
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .statusBarsPadding()
                    .navigationBarsPadding()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(strings.syncProfilesTitle, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                    Button(onClick = onDismiss) {
                        Text(strings.done, fontSize = 14.sp)
                    }
                }

                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = strings.syncProfilesGuide,
                        fontSize = 12.sp,
                        lineHeight = 17.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(12.dp)
                    )
                }

                if (profiles.isEmpty()) {
                    Box(
                        modifier = Modifier.fillMaxWidth().weight(1f),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = strings.noSyncProfilesMsg,
                            fontSize = 14.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.fillMaxWidth().weight(1f),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(profiles, key = { it.id }) { p ->
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant,
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                            ) {
                                Column(
                                    modifier = Modifier.fillMaxWidth().padding(14.dp),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(
                                            text = p.name.replace(" ↔ ", "\n↔ "),
                                            fontSize = 13.sp,
                                            lineHeight = 18.sp,
                                            fontWeight = FontWeight.Bold,
                                            maxLines = 3,
                                            overflow = TextOverflow.Ellipsis,
                                            modifier = Modifier.weight(1f).padding(end = 8.dp)
                                        )
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(
                                                text = if (p.enabled) strings.syncStateOnLabel else strings.syncStateOffLabel,
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.SemiBold,
                                                color = if (p.enabled) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                                                modifier = Modifier.padding(end = 6.dp)
                                            )
                                            Switch(
                                                checked = p.enabled,
                                                onCheckedChange = { chk ->
                                                    onUpdateProfiles(profiles.map { if (it.id == p.id) it.copy(enabled = chk) else it })
                                                }
                                            )
                                        }
                                    }

                                    val modeHuman = when (p.modeName) {
                                        "ONE_WAY_LR" -> strings.syncModeOneWay
                                        "ONE_WAY_RL" -> strings.syncModeOneWayRL
                                        "TWO_WAY" -> strings.syncModeTwoWay
                                        "MIRROR_LR" -> strings.syncModeMirror
                                        else -> p.modeName
                                    }
                                    val lastRunTxt = p.lastResult.ifBlank { strings.syncNeverRunLabel }
                                    Text(
                                        text = "${strings.syncModeLabel}: $modeHuman · ${strings.syncLastRunLabel}: $lastRunTxt",
                                        fontSize = 12.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )

                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                                        OutlinedButton(
                                            onClick = {
                                                val nextIdx = (intervals.indexOf(p.intervalMinutes) + 1) % intervals.size
                                                onUpdateProfiles(profiles.map { if (it.id == p.id) it.copy(intervalMinutes = intervals[nextIdx]) else it })
                                            },
                                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp),
                                            modifier = Modifier.weight(1f)
                                        ) {
                                            Text("${strings.syncScheduleLabel}: ${intervalLabel(p.intervalMinutes)}", fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                        }
                                        OutlinedButton(
                                            onClick = {
                                                onUpdateProfiles(profiles.map { if (it.id == p.id) it.copy(wifiOnly = !it.wifiOnly) else it })
                                            },
                                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 6.dp),
                                            colors = ButtonDefaults.outlinedButtonColors(
                                                containerColor = if (p.wifiOnly) MaterialTheme.colorScheme.primary else Color.Transparent,
                                                contentColor = if (p.wifiOnly) Color.White else MaterialTheme.colorScheme.onSurface
                                            ),
                                            modifier = Modifier.weight(1f)
                                        ) {
                                            val netLabel = if (p.wifiOnly) strings.wifiOnlyLabel else strings.syncWifiOrMobileLabel
                                            Text("${strings.syncNetworkLabel}: $netLabel", fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                        }
                                    }

                                    OutlinedButton(
                                        onClick = {
                                            onUpdateProfiles(profiles.map { if (it.id == p.id) it.copy(onChange = !it.onChange) else it })
                                        },
                                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                                        colors = ButtonDefaults.outlinedButtonColors(
                                            containerColor = if (p.onChange) MaterialTheme.colorScheme.primary else Color.Transparent,
                                            contentColor = if (p.onChange) Color.White else MaterialTheme.colorScheme.onSurface
                                        ),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        val onChgStatus = if (p.onChange) strings.syncStateOnLabel else strings.syncStateOffLabel
                                        Text("${strings.onChangeLabel}: $onChgStatus", fontSize = 12.sp, maxLines = 1)
                                    }

                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                                        Button(
                                            onClick = { onRunNow(p) },
                                            modifier = Modifier.weight(1f)
                                        ) { Text(strings.runNowBtn, fontSize = 13.sp, maxLines = 1) }
                                        OutlinedButton(
                                            onClick = { onUpdateProfiles(profiles.filterNot { it.id == p.id }) },
                                            colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error)
                                        ) { Text(strings.actDelete, fontSize = 13.sp) }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
